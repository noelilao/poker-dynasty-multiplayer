POKER DYNASTY V84.0H — DENO DEPLOY PACKAGE

Upload the CONTENTS of this folder to the ROOT of the GitHub repository.
Required root files: main.ts, deno.json, mp-engine/

Deno app configuration:
  Entrypoint: main.ts
  Free Regions: selected
  Install command: none
  Build command: none

Persistence:
  The adapter uses Deno.openKv(). Assign a Deno KV database to the app if the dashboard asks for a database binding.

API compatibility:
  /api/meta and /api/room/... -> ordinary Multiplayer
  /api/career84/meta and /api/career84/... -> Multiplayer Career

Port notes:
  The existing poker and Career reducers are retained. SQLite/file persistence and the Node HTTP wrapper are replaced by Deno KV and Deno.serve(). Large immutable Career snapshots are chunked in KV.

Important migration note:
  This package creates a NEW Deno KV datastore. It does not import an existing rooms.sqlite production database. Do not delete the old database or backup if old worlds must later be migrated.
