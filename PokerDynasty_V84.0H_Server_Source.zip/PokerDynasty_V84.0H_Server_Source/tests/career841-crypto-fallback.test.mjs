import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {createHash,createHmac,pbkdf2Sync,webcrypto} from 'node:crypto';
import vm from 'node:vm';
import {fileURLToPath} from 'node:url';

// Test the functions actually shipped in game.html. PD841_CLIENT_SOURCE is a
// build-only override for verifying the extracted client before final assembly.
const sourceFile=process.env.PD841_CLIENT_SOURCE||fileURLToPath(new URL('../mp-engine/game.html',import.meta.url));
const raw=readFileSync(sourceFile,'utf8');
const match=raw.match(/<script\b(?=[^>]*\bid=["']pd84-multiplayer-career["'])[^>]*>([\s\S]*?)<\/script>/i);
const source=match?match[1]:raw;
const first=source.indexOf('function bytes(n)'),last=source.indexOf('function message(',first);
assert.ok(first>=0&&last>first,'Packaged V84.1 client cryptography section is present');
const context=vm.createContext({TextEncoder,Uint8Array,ArrayBuffer,DataView,setTimeout,crypto:{getRandomValues:a=>webcrypto.getRandomValues(a)}});
vm.runInContext('const enc=new TextEncoder();\n'+source.slice(first,last)+'\nglobalThis.testCrypto={sha,derive,proof,credential,sha256Raw,hmacMaker,hex};',context,{timeout:1000});
const fallback=context.testCrypto;
assert.equal(vm.runInContext('crypto.subtle',context),undefined,'The test must exercise plain-JavaScript fallback paths');

test('LAN JavaScript SHA-256 fallback matches known answers and native reference across block boundaries',async()=>{
 assert.equal(await fallback.sha(''),'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855');
 assert.equal(await fallback.sha('abc'),'ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad');
 for(const input of ['a'.repeat(55),'a'.repeat(56),'a'.repeat(63),'a'.repeat(64),'a'.repeat(65),'a'.repeat(1000),'Poker Dynasty — 日本語 / Pilipinas ♠♥♦♣ 🔒','null\0separator'])assert.equal(await fallback.sha(input),createHash('sha256').update(input).digest('hex'));
});

test('LAN JavaScript HMAC-SHA256 fallback matches RFC 4231 and long-key/native references',async()=>{
 const key1=Uint8Array.from({length:20},()=>0x0b),key2=new TextEncoder().encode('Jefe');
 assert.equal(fallback.hex(fallback.hmacMaker(key1)(new TextEncoder().encode('Hi There'))),'b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7');
 assert.equal(fallback.hex(fallback.hmacMaker(key2)(new TextEncoder().encode('what do ya want for nothing?'))),'5bdcc146bf60754e6a042426089575c75a003f089d2739839dec58b964ec3843');
 for(const count of [0,1,32,64,65,131]){const key=Uint8Array.from({length:count},(_,i)=>(i*13+17)%256),msg=new TextEncoder().encode('A signed shared-world request 🔒');assert.equal(fallback.hex(fallback.hmacMaker(key)(msg)),createHmac('sha256',key).update(msg).digest('hex'));}
 const verifier='11'.repeat(32),message='pd84-login|ABCDEFGH|00000000-0000-4000-8000-000000000000|'+'ab'.repeat(32);assert.equal(await fallback.proof(verifier,message),createHmac('sha256',Buffer.from(verifier,'hex')).update(message).digest('hex'));
});

test('LAN PBKDF2-SHA256 fallback matches known answers and both deployed iteration counts',async()=>{
 assert.equal(await fallback.derive('password','73616c74',1),'120fb6cffcf8b32c43e7225256c4f837a86548c92ccc35480805987cb70be17b');
 assert.equal(await fallback.derive('password','73616c74',2),'ae4d0c95af6b46d32d0adff928f06dd02a303f8ef3c251dfd6e2d85a95474c43');
 for(const iterations of [4096,100000,250000]){const password='Pässword\0poker🔒',salt='0123456789abcdef'.repeat(4);assert.equal(await fallback.derive(password,salt,iterations),pbkdf2Sync(password,Buffer.from(salt,'hex'),iterations,32,'sha256').toString('hex'));}
 const c=await fallback.credential('valid-password','42'.repeat(16));assert.equal(c.iterations,100000);assert.equal(c.verifier,pbkdf2Sync('valid-password',Buffer.from(c.salt,'hex'),100000,32,'sha256').toString('hex'));await assert.rejects(fallback.credential('short','42'.repeat(16)),/at least 8/);
});
