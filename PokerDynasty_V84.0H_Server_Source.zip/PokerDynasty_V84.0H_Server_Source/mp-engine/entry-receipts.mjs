/* Safe create/join replay. World mutation and encrypted receipt commit together.
 * The caller serializes ALL operations using this SQLite connection. */
import {createHash,createCipheriv,createDecipheriv,randomBytes,timingSafeEqual} from 'node:crypto';
import {readFileSync,writeFileSync,existsSync} from 'node:fs';
import path from 'node:path';
export const CORS={'Access-Control-Allow-Origin':'*','Access-Control-Allow-Methods':'GET, POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Max-Age':'600','Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Content-Type':'application/json; charset=utf-8'};
const response=(error,code,status=409)=>new Response(JSON.stringify({error,code}),{status,headers:CORS});
const sha=s=>createHash('sha256').update(s).digest('hex');
function stable(x){if(Array.isArray(x))return x.map(stable);if(x&&typeof x==='object')return Object.fromEntries(Object.keys(x).sort().map(k=>[k,stable(x[k])]));return x;}
export function entryReceipts(db,dataDir,store){
 const keyPath=path.join(dataDir,'entry-receipt.key');if(!existsSync(keyPath))writeFileSync(keyPath,randomBytes(32),{mode:0o600,flag:'wx'});
 const key=readFileSync(keyPath);if(key.length!==32)throw Error('The entry-receipt key is invalid. Restore the original data folder, not a new empty key.');
 db.exec('CREATE TABLE IF NOT EXISTS career_entry_receipts (key_hash TEXT PRIMARY KEY, fingerprint TEXT NOT NULL, operation TEXT NOT NULL, world_code TEXT NOT NULL, player_uuid TEXT NOT NULL, envelope TEXT NOT NULL, created_at INTEGER NOT NULL)');
 const get=db.prepare('SELECT * FROM career_entry_receipts WHERE key_hash=?'),put=db.prepare('INSERT INTO career_entry_receipts VALUES(?,?,?,?,?,?,?)');
 function encrypt(text,aad){const iv=randomBytes(12),c=createCipheriv('aes-256-gcm',key,iv);c.setAAD(Buffer.from(aad));return JSON.stringify({iv:iv.toString('base64'),tag:(()=>{const encrypted=Buffer.concat([c.update(text,'utf8'),c.final()]);return {cipher:encrypted.toString('base64'),auth:c.getAuthTag().toString('base64')};})()});}
 function decrypt(text,aad){const e=JSON.parse(text),d=createDecipheriv('aes-256-gcm',key,Buffer.from(e.iv,'base64'));d.setAAD(Buffer.from(aad));d.setAuthTag(Buffer.from(e.tag.auth,'base64'));return Buffer.concat([d.update(Buffer.from(e.tag.cipher,'base64')),d.final()]).toString('utf8');}
 return async(request,handler)=>{
  const op=new URL(request.url).pathname;if(request.method!=='POST'||!['/api/career84/create','/api/career84/join'].includes(op))return handler(request);
  let body;try{body=await request.clone().json();}catch(_){return handler(request);}
  if(body.entryKey==null)return handler(request); // Original client protocol remains accepted.
  if(!/^[a-f0-9]{64}$/.test(body.entryKey))return response('A 256-bit entry recovery key is required.','invalid_entry_key',400);
  const keyHash=sha('pd84e-entry|'+body.entryKey),fingerprint=sha(op+'|'+JSON.stringify(stable(body))),previous=get.get(keyHash);
  if(previous){
   if(previous.fingerprint!==fingerprint||previous.operation!==op)return response('This recovery key already belongs to a different request. Do not change the pending request.','entry_conflict');
   const w=await store.careerLoad(previous.world_code),p=w?.players?.find(x=>x.playerUuid===previous.player_uuid);
   if(!p)return response('This entry already completed, but the original world is no longer available. No replacement world was created.','entry_world_unavailable',410);
   const cached=JSON.parse(decrypt(previous.envelope,keyHash));
   const expected=sha('pd84-session|'+cached.body.sessionToken);
   if(!p.sessionHash||!timingSafeEqual(Buffer.from(p.sessionHash),Buffer.from(expected))||p.sessionExpiresAt<Date.now()||p.status!=='active')return response('Your world and player already exist. Sign in to that World Code and Player UUID; the old entry cannot replace a newer session.','entry_session_replaced');
   // Return a fresh projection; do not let a cached revision overwrite current progress.
   const fresh=await handler(new Request(request.url.replace(/\/(create|join)$/,'/world/'+previous.world_code),{method:'POST',headers:{...CORS,Authorization:'Bearer '+cached.body.sessionToken},body:JSON.stringify({type:'poll'})}));
   if(!fresh.ok)return fresh;const data=await fresh.json();cached.body.view=data.view;cached.body.entryReplayed=true;
   return new Response(JSON.stringify(cached.body),{status:200,headers:CORS});
  }
  db.exec('BEGIN IMMEDIATE');
  try{
   const result=await handler(request);
   if(!result.ok){db.exec('ROLLBACK');return result;}
   const body=await result.clone().json();if(!body.worldCode||!body.playerUuid||!body.sessionToken)throw Error('The entry did not return a complete identity.');
   put.run(keyHash,fingerprint,op,body.worldCode,body.playerUuid,encrypt(JSON.stringify({status:result.status,body}),keyHash),Date.now());
   db.exec('COMMIT');return result;
  }catch(e){try{db.exec('ROLLBACK');}catch(_){}throw e;}
 };
}
