Inherited Node tests: npm test
Optional new real-HTTP/SQLite restart test: python tests/entry_http_tests.py
The optional Python test requires httpx, starts its own localhost:8890 server with a temporary empty data directory, and never uses your game data. Stop another development process on port 8890 first. It writes its results under verification/.
