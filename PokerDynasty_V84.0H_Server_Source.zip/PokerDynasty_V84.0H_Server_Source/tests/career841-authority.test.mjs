import test from 'node:test';
import assert from 'node:assert/strict';
import {handleCareer,CAREER_VERSION} from '../mp-engine/career84.mjs';
import {nativeChecksum,founderBankroll} from '../mp-engine/career84-integrity.mjs';

const enc=new TextEncoder();
const hex=a=>Array.from(a,x=>x.toString(16).padStart(2,'0')).join('');
const unhex=s=>Uint8Array.from(s.match(/../g),x=>Number.parseInt(x,16));
const hash=async s=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(s))));
const cred={salt:'11'.repeat(16),iterations:100000,verifier:'22'.repeat(32)};
async function proof(nonce,player,world){const key=await crypto.subtle.importKey('raw',unhex(cred.verifier),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode(`pd84-login|${world}|${player}|${nonce}`))));}
function storage(){const worlds=new Map(),blobs=new Map();return{worlds,blobs,failNext:0,async health(){},async prune(){},async careerLoad(code){return structuredClone(worlds.get(code)||null)},async careerCreate(w){if(worlds.has(w.worldCode))return false;worlds.set(w.worldCode,structuredClone(w));return true},async careerCas(w,rev){if(this.failNext){this.failNext--;return false;}if(worlds.get(w.worldCode)?.revision!==rev)return false;worlds.set(w.worldCode,structuredClone(w));return true},async careerSnapshotPut(ref,text){assert.ok(!blobs.has(ref)||blobs.get(ref)===text);blobs.set(ref,text)},async careerSnapshotGet(ref){return blobs.get(ref)||null}};}
function environment(){const st=storage();let now=Date.UTC(2026,9,7,12);const call=async(path,body,token,handler=handleCareer)=>{const headers={'Content-Type':'application/json'};if(token)headers.Authorization='Bearer '+token;const r=await handler(new Request('http://local'+path,{method:body===undefined?'GET':'POST',headers,...(body===undefined?{}:{body:JSON.stringify(body)})}),st,()=>now);return{status:r.status,data:await r.json()}};return{st,call,get now(){return now},advance(ms){now+=ms},setNow(ms){now=ms}};}
async function create(e,settings={}){const r=await e.call('/api/career84/create',{worldName:'Authority Test',playerName:'Host',credential:cred,recoveryKey:'aa'.repeat(32),worldSettings:{startYear:2026,startMonth:10,startDay:7,startHour:18,startMinute:0,startingCity:'vegas',...settings}});assert.equal(r.status,201,r.data.error);return{...r.data,token:r.data.sessionToken};}
async function join(e,host,name='Guest'){const r=await e.call('/api/career84/join',{worldCode:host.worldCode,playerName:name,credential:cred,recoveryKey:'bb'.repeat(32)});assert.equal(r.status,201,r.data.error);return{...r.data,token:r.data.sessionToken};}
async function poll(e,p,snapshot=false){const r=await e.call('/api/career84/world/'+p.worldCode,{type:'poll',includeSnapshot:snapshot},p.token);if(r.status===200)p.view=r.data.view;return r;}
async function cmd(e,p,type,fields={},id){await poll(e,p);const r=await e.call('/api/career84/world/'+p.worldCode,{type,...fields,expectedRevision:p.view.world.revision,requestId:id||'test_'+crypto.randomUUID().replaceAll('-','')},p.token);if(r.status===200){p.view=r.data.view;if(r.data.sessionToken)p.token=r.data.sessionToken;}return r;}
function character(p){const q=p.view.own.character,d=new Date(q.createdMinute*60000);return{isCreated:true,_saveSchema:221,_dynastyId:q.characterUuid,activeName:p.view.own.name,founderName:p.view.own.name,generation:1,startingYear:d.getUTCFullYear(),currentYear:d.getUTCFullYear(),currentMonth:d.getUTCMonth()+1,day:d.getUTCDate(),bankroll:q.startingBankroll,debt:0,bankDebt:0,world:{seed:p.view.world.seed,current:q.startingCity},dailyLife55:{schema:1,minuteOfDay:d.getUTCHours()*60+d.getUTCMinutes()},multiplayerCareer84:{schema:1,worldUuid:p.worldUuid,playerUuid:p.playerUuid,characterUuid:q.characterUuid,worldSeed:p.view.world.seed,createdMinute:q.createdMinute,appliedAvailabilityIds:[],appliedWalletIds:[]}};}
function atMinute(c,minute){const d=new Date(minute*60000);c.currentYear=d.getUTCFullYear();c.currentMonth=d.getUTCMonth()+1;c.day=d.getUTCDate();c.dailyLife55.minuteOfDay=d.getUTCHours()*60+d.getUTCMinutes();return c;}
function backup(c){const payload=JSON.stringify(c);return JSON.stringify({game:'Poker Dynasty',backupVersion:1,snapshot:{format:'PokerDynastySnapshot',formatVersion:1,seq:1,identity:c._dynastyId,checksum:nativeChecksum(payload),payload}});}
async function save(e,p,c=character(p),extra={}){await poll(e,p);const base=p.view.own.snapshotRevision;c.multiplayerCareer84.snapshotRevision=base+1;const text=backup(c);const r=await cmd(e,p,'sync_snapshot',{snapshot:{text,checksum:await hash(text),baseRevision:base,revision:base+1,slot:1},...extra});return{...r,career:c,text};}

test('host timeline validates exact date and inherited city chronology; initial player blueprints agree',async()=>{
 const e=environment(),meta=await e.call('/api/career84/meta');assert.equal(meta.data.version,CAREER_VERSION);assert.equal(meta.data.protocol,2);assert.equal(meta.data.catalog.cities.length,256);assert.ok(meta.data.tournaments.variants.length>=11);
 const host=await create(e,{startYear:1829,startMonth:2,startDay:28,startHour:9,startMinute:15,startingCity:'us_la_neworleans'}),guest=await join(e,host);
 assert.match(host.worldUuid,/^[0-9a-f-]{36}$/);assert.notEqual(host.playerUuid,guest.playerUuid);assert.equal(guest.view.world.seed,host.view.world.seed);assert.equal(host.view.clock.minute,Math.floor(Date.UTC(1829,1,28,9,15)/60000));assert.equal(guest.view.own.location.city,'us_la_neworleans');assert.equal(guest.view.own.character.startingBankroll,founderBankroll(1829));
 for(const worldSettings of [{startYear:2026,startMonth:2,startDay:29,startingCity:'vegas'},{startYear:1829,startingCity:'vegas'},{startYear:2026,startingCity:'imaginary'}]){const r=await e.call('/api/career84/create',{playerName:'Bad',credential:cred,recoveryKey:'aa'.repeat(32),worldSettings});assert.equal(r.status,400,r.data.error);}
 const r=await cmd(e,host,'settings_update',{settings:{startYear:1971}});assert.equal(r.status,409);assert.equal(r.data.code,'timeline_immutable');
});

test('password challenges survive module restart and CAS collision; replay and replaced tokens fail',async()=>{
 const e=environment(),host=await create(e),old=host.token;
 let r=await e.call('/api/career84/auth/challenge',{worldCode:host.worldCode,playerUuid:host.playerUuid});assert.equal(r.status,200);const nonce=r.data.nonce;
 const restarted=await import('../mp-engine/career84.mjs?restart='+crypto.randomUUID());e.st.failNext=1;
 r=await e.call('/api/career84/auth/login',{worldCode:host.worldCode,playerUuid:host.playerUuid,nonce,proof:await proof(nonce,host.playerUuid,host.worldCode)},null,restarted.handleCareer);assert.equal(r.status,200,r.data.error);host.token=r.data.sessionToken;
 assert.equal((await e.call('/api/career84/world/'+host.worldCode,{type:'poll'},old)).status,401);
 assert.equal((await e.call('/api/career84/auth/login',{worldCode:host.worldCode,playerUuid:host.playerUuid,nonce,proof:await proof(nonce,host.playerUuid,host.worldCode)})).data.code,'challenge_expired');
 const raw=JSON.stringify(e.st.worlds.get(host.worldCode));assert.ok(!raw.includes(host.token));assert.ok(!raw.includes('aa'.repeat(32)));assert.ok(!raw.includes('sessionToken'));
 const token=host.token;r=await cmd(e,host,'change_credential',{credential:{...cred,salt:'33'.repeat(16)}});assert.equal(r.status,200);assert.notEqual(host.token,token);assert.equal((await e.call('/api/career84/world/'+host.worldCode,{type:'poll'},token)).status,401);
 r=await cmd(e,host,'logout');assert.equal(r.status,200);assert.equal(r.data.signedOut,true);assert.equal((await poll(e,host)).status,401);
});

test('persisted poll heartbeats prevent false host loss; explicit cohost failover is deterministic',async()=>{
 const e=environment(),host=await create(e),guest=await join(e,host);
 for(let i=0;i<8;i++){e.advance(15000);assert.equal((await poll(e,host)).status,200);await poll(e,guest);assert.equal(guest.view.clock.paused,false);}
 assert.equal(e.st.worlds.get(host.worldCode).players.find(x=>x.playerUuid===host.playerUuid).lastSeen,e.now);
 e.advance(95000);await poll(e,guest);assert.equal(guest.view.clock.paused,true);assert.equal(guest.view.clock.pauseReason,'host-disconnected');
 await poll(e,host);assert.equal(host.view.clock.paused,false);assert.equal((await cmd(e,host,'cohost_set',{targetPlayerUuid:guest.playerUuid,enabled:true})).status,200);
 e.advance(95000);await poll(e,guest);assert.equal(guest.view.world.hostPlayerUuid,guest.playerUuid);assert.equal(guest.view.clock.paused,false);assert.equal(guest.view.own.role,'host');
 assert.equal((await cmd(e,guest,'world_pause',{paused:true})).status,200);await poll(e,host);assert.equal(host.view.clock.pauseReason,'host-paused');
});

test('owner-bound native snapshots reject malformed saves, another player, forged start and rewinds; blobs stay separate',async()=>{
 const e=environment(),host=await create(e),guest=await join(e,host);const c=character(host),g=character(guest);
 let r=await save(e,host,c);assert.equal(r.status,200,r.data.error);assert.equal(host.view.own.character.bound,true);assert.equal(e.st.blobs.size,1);assert.equal(e.st.worlds.get(host.worldCode).players[0].snapshot.text,undefined);
 const wrong=structuredClone(c);wrong.multiplayerCareer84.playerUuid=guest.playerUuid;r=await save(e,host,wrong);assert.equal(r.data.code,'snapshot_owner_mismatch');
 g.bankroll+=1;r=await save(e,guest,g);assert.equal(r.data.code,'fresh_character_required');g.bankroll-=1;
 r=await save(e,guest,g);assert.equal(r.status,200,r.data.error);
 const missingMoney=structuredClone(c);delete missingMoney.bankroll;r=await save(e,host,missingMoney);assert.equal(r.data.code,'native_snapshot_invalid');
 const future=structuredClone(c);atMinute(future,host.view.clock.minute+1);r=await save(e,host,future);assert.equal(r.data.code,'snapshot_clock_ahead');
 await poll(e,host);const staleText=backup(c);r=await cmd(e,host,'sync_snapshot',{snapshot:{text:staleText,checksum:await hash(staleText),baseRevision:0,revision:1,slot:1}});assert.equal(r.data.code,'stale_snapshot');
 let malformed=JSON.parse(backup(c));malformed.snapshot.payload+=' ';const str=JSON.stringify(malformed);r=await cmd(e,host,'sync_snapshot',{snapshot:{text:str,checksum:await hash(str),baseRevision:1,revision:2,slot:1}});assert.equal(r.data.code,'native_snapshot_invalid');
 r=await poll(e,host,true);assert.equal(r.data.view.own.snapshot.text,backup(c));assert.equal(r.data.view.players.find(x=>x.playerUuid===guest.playerUuid).snapshot,undefined);assert.ok(!JSON.stringify(r.data).includes(cred.verifier));
});

test('shared sleep uses earliest wake; durable completions survive device loss and atomically acknowledge with saved effects',async()=>{
 const e=environment(),host=await create(e),guest=await join(e,host),hc=character(host),gc=character(guest);
 assert.equal((await cmd(e,host,'sleep',{minutes:480})).data.code,'departure_snapshot_required');
 assert.equal((await save(e,host,hc)).status,200);assert.equal((await save(e,guest,gc)).status,200);
 const start=host.view.clock.minute;let r=await cmd(e,host,'sleep',{minutes:480});assert.equal(r.status,200);assert.equal(host.view.clock.minute,start);
 r=await cmd(e,guest,'sleep',{minutes:300});assert.equal(r.status,200);assert.equal(guest.view.clock.minute,start+300);assert.equal(guest.view.own.availability,null);assert.equal(guest.view.players.find(x=>x.playerUuid===host.playerUuid).availability.until,start+480);
 const completion=guest.view.own.completions[0];assert.equal(completion.completion.hours,5);
 const old=guest.token;r=await e.call('/api/career84/recover-key',{worldCode:guest.worldCode,playerUuid:guest.playerUuid,recoveryKey:'bb'.repeat(32)});assert.equal(r.status,200);guest.token=r.data.sessionToken;guest.view=r.data.view;assert.equal((await e.call('/api/career84/world/'+guest.worldCode,{type:'poll'},old)).status,401);
 r=await poll(e,guest,true);assert.equal(r.data.view.own.completions[0].id,completion.id);assert.equal(JSON.parse(JSON.parse(r.data.view.own.snapshot.text).snapshot.payload).dailyLife55.minuteOfDay,1080);
 atMinute(gc,start+300);r=await save(e,guest,gc,{availabilityAck:completion.id});assert.equal(r.data.code,'completion_not_saved');gc.multiplayerCareer84.appliedAvailabilityIds.push(completion.id);r=await save(e,guest,gc,{availabilityAck:completion.id});assert.equal(r.status,200,r.data.error);assert.equal(guest.view.own.completions.length,0);
 r=await cmd(e,guest,'wait',{minutes:180});assert.equal(r.status,200);assert.equal(guest.view.clock.minute,start+480);await poll(e,host);assert.equal(host.view.own.availability,null);assert.equal(host.view.own.completions[0].completion.hours,8);
});

test('one player activity cannot skip active players; travel retains server quote/destination and cannot be cancelled',async()=>{
 const e=environment(),host=await create(e),guest=await join(e,host),hc=character(host);assert.equal((await save(e,host,hc)).status,200);await save(e,guest);
 const start=host.view.clock.minute;let r=await cmd(e,host,'activity_span',{minutes:1440,label:'Work'});assert.equal(r.status,200);assert.equal(host.view.clock.minute,start);assert.equal(host.view.own.availability.kind,'activity');
 assert.equal((await cmd(e,host,'cancel_activity')).status,200);
 const quote={from:'vegas',to:'manila',days:1,total:0,key:'native_quote_test'};
 r=await cmd(e,host,'travel',{minutes:1440,destination:{city:'manila'},completion:{adapter:'legacy',quote},travelKey:quote.key});assert.equal(r.status,200,r.data.error);assert.equal(host.view.clock.minute,start);assert.equal(host.view.own.location.city,'vegas');
 assert.equal((await cmd(e,host,'cancel_activity')).data.code,'travel_in_progress');
 r=await cmd(e,guest,'wait',{minutes:1440});assert.equal(r.status,200);assert.equal(guest.view.clock.minute,start+1440);
 await poll(e,host);assert.equal(host.view.own.location.city,'manila');const completion=host.view.own.completions.find(x=>x.kind==='travel');assert.deepEqual(completion.completion.quote,quote);assert.equal(completion.departureSnapshotRevision,1);
 hc.world.current='manila';atMinute(hc,start+1440);hc.multiplayerCareer84.appliedAvailabilityIds.push(completion.id);r=await save(e,host,hc,{availabilityAck:completion.id});assert.equal(r.status,200,r.data.error);
});

test('mutation request IDs prevent duplicates and conflicting reuse without storing session secrets',async()=>{
 const e=environment(),host=await create(e),guest=await join(e,host);const id='idempotency_test_123';let r=await cmd(e,host,'chat',{message:'Test message'},id);assert.equal(r.status,200);const revision=r.data.view.world.revision;
 r=await e.call('/api/career84/world/'+host.worldCode,{type:'chat',message:'Test message',expectedRevision:0,requestId:id},host.token);assert.equal(r.status,200);assert.equal(r.data.duplicate,true);assert.equal(r.data.view.world.revision,revision);assert.equal(r.data.view.chat.length,1);
 r=await e.call('/api/career84/world/'+host.worldCode,{type:'chat',message:'Changed message',expectedRevision:revision,requestId:id},host.token);assert.equal(r.data.code,'request_id_conflict');
 r=await e.call('/api/career84/world/'+host.worldCode,{type:'chat',message:'stale',expectedRevision:0,requestId:'different_request_123'},host.token);assert.equal(r.data.code,'stale_revision');
 await cmd(e,guest,'player_block',{targetPlayerUuid:host.playerUuid,blocked:true});assert.equal(guest.view.chat.length,0);r=await cmd(e,host,'chat',{message:'DM',recipientPlayerUuid:guest.playerUuid});assert.equal(r.data.code,'chat_blocked');
});

test('host recovery requires the claim secret even while pending; suspension preserves saves and revokes access',async()=>{
 const e=environment(),host=await create(e),guest=await join(e,host);await save(e,guest);
 let r=await e.call('/api/career84/recovery/request',{worldCode:guest.worldCode,playerUuid:guest.playerUuid});assert.equal(r.status,200);const recovery=r.data;
 r=await e.call('/api/career84/recovery/claim',{worldCode:guest.worldCode,requestId:recovery.requestId,claimToken:'11'.repeat(32)});assert.equal(r.status,401);
 r=await cmd(e,host,'recovery_approve',{recoveryRequestId:recovery.requestId});assert.equal(r.status,200,r.data.error);
 const old=guest.token;r=await e.call('/api/career84/recovery/claim',{worldCode:guest.worldCode,requestId:recovery.requestId,claimToken:recovery.claimToken});assert.equal(r.status,200);guest.token=r.data.sessionToken;guest.view=r.data.view;assert.equal(guest.playerUuid,r.data.playerUuid);assert.equal(guest.view.own.snapshotRevision,1);assert.equal((await e.call('/api/career84/world/'+guest.worldCode,{type:'poll'},old)).status,401);
 r=await e.call('/api/career84/recovery/claim',{worldCode:guest.worldCode,requestId:recovery.requestId,claimToken:recovery.claimToken});assert.equal(r.data.code,'recovery_closed');
 r=await cmd(e,host,'player_suspend',{targetPlayerUuid:guest.playerUuid,suspended:true});assert.equal(r.status,200);assert.equal((await poll(e,guest)).status,401);assert.equal(e.st.worlds.get(host.worldCode).players.find(x=>x.playerUuid===guest.playerUuid).snapshot.revision,1);
 r=await cmd(e,host,'player_suspend',{targetPlayerUuid:guest.playerUuid,suspended:false});assert.equal(r.status,200);r=await e.call('/api/career84/recover-key',{worldCode:guest.worldCode,playerUuid:guest.playerUuid,recoveryKey:'bb'.repeat(32)});assert.equal(r.status,200);assert.equal(r.data.view.own.snapshotRevision,1);
});

test('explicit migration binds only the original V84 server save and preserves its Dynasty/assets',async()=>{
 const e=environment(),host=await create(e),oldCareer=character(host);delete oldCareer.multiplayerCareer84;oldCareer._dynastyId='original_native_dynasty_77';oldCareer.world.seed='older_native_world_seed';oldCareer.assets=[{id:'preserved_property',owned:true,value:12000}];oldCareer.bankroll=4567.89;
 const w=e.st.worlds.get(host.worldCode);w.version='84.0.0';delete w.players[0].character;delete w.players[0].wallet;const original=backup(oldCareer);w.players[0].snapshot={text:original,checksum:await hash(original),bytes:original.length,revision:7,slot:2,summary:{name:'Host'}};
 await poll(e,host,true);assert.equal(host.view.own.character.legacy,true);assert.equal(host.view.own.character.bound,false);
 let r=await cmd(e,host,'migrate_legacy_snapshot',{includeSnapshot:true});assert.equal(r.status,200,r.data.error);assert.equal(r.data.migrated,true);assert.equal(host.view.own.snapshotRevision,8);assert.equal(host.view.own.character.dynastyId,'original_native_dynasty_77');
 await poll(e,host,true);const saved=JSON.parse(JSON.parse(host.view.own.snapshot.text).snapshot.payload);assert.equal(saved._dynastyId,'original_native_dynasty_77');assert.deepEqual(saved.assets,oldCareer.assets);assert.equal(saved.bankroll,4567.89);assert.equal(saved.world.seed,host.view.world.seed);assert.equal(saved.multiplayerCareer84.playerUuid,host.playerUuid);
 r=await save(e,host,saved);assert.equal(r.status,200,r.data.error);r=await cmd(e,host,'migrate_legacy_snapshot');assert.equal(r.data.code,'legacy_migration_unavailable');
});

test('Career API runs actual shared tournament tables, preserves wallet receipts and automatic day barriers',async()=>{
 const e=environment(),host=await create(e),guest=await join(e,host),hc=character(host),gc=character(guest);
 await save(e,host,hc);await save(e,guest,gc);
 const tid='tour_core_integration';let r=await cmd(e,host,'tournament_create',{tournamentId:tid,name:'Core Shared Event',settings:{fieldSize:4,maxSeats:2,buyIn:5,startingStack:1000,sb:1,bb:2,blindMode:'hands',blindEvery:1,levelsPerDay:1,breakEveryLevels:0}});assert.equal(r.status,200,r.data.error);
 for(const p of [host,guest]){r=await cmd(e,p,'tournament_join',{tournamentId:tid,stack:999999,seat:9});assert.equal(r.status,200,r.data.error);assert.equal(p.view.own.wallet.balance,995);assert.equal(p.view.own.wallet.ledger.length,1);assert.equal(p.view.tournaments.find(x=>x.id===tid).participants.find(x=>x.playerUuid===p.playerUuid).stack,1000);}
 const dupe=await cmd(e,host,'tournament_join',{tournamentId:tid});assert.equal(dupe.status,200);assert.equal(host.view.own.wallet.ledger.length,1);
 for(const [p,c] of [[host,hc],[guest,gc]]){for(const entry of p.view.own.wallet.ledger){c.bankroll+=entry.amount;c.multiplayerCareer84.appliedWalletIds.push(entry.id);}assert.equal((await save(e,p,c)).status,200);}
 r=await cmd(e,host,'tournament_start',{tournamentId:tid});assert.equal(r.status,200,r.data.error);r=await cmd(e,host,'tournament_table',{tournamentId:tid});assert.equal(r.status,200);assert.ok(r.data.roomView?.table);assert.equal(r.data.roomView.careerTournament.id,tid);
 assert.equal((await cmd(e,guest,'tournament_progress',{tournamentId:tid,stack:999999,barrier:{type:'day',value:99}})).data.code,'server_tournament_authority');
 const start=host.view.clock.minute;let reached=false;
 for(let n=0;n<120;n++){
  for(const p of [host,guest]){
   await poll(e,p);const tv=p.view.tournaments.find(x=>x.id===tid);if(tv.dayNo>=2){reached=true;break;}
   const room=tv.roomView;if(!room?.table?.legal?.length)continue;
   const types=room.table.legal.map(x=>typeof x==='string'?x:x.type);const type=types.includes('check')?'check':types.includes('fold')?'fold':types.includes('call')?'call':null;if(!type)continue;
   const res=await cmd(e,p,'tournament_action',{tournamentId:tid,tableId:room.careerTournament.tableId,turnId:room.table.turnId,action:{type}});assert.ok([200,409].includes(res.status),res.data.error);
  }
  if(reached)break;e.advance(1000);
 }
 assert.equal(reached,true,'Automatic day barrier must release at canonical next-day time');await poll(e,host);const t=host.view.tournaments.find(x=>x.id===tid);assert.ok(t.dayNo>=2);assert.ok(host.view.clock.minute>start);assert.equal(t.startingChips,4000);assert.equal(t.fieldSize,4);assert.equal(t.prizePool,20);
 const state=e.st.worlds.get(host.worldCode).tournaments[tid];const chipTotal=Object.values(state.participants).reduce((n,p)=>n+p.stack,0)+Object.values(state.tables).reduce((n,t)=>n+(t.active!==false?t.game?.pot||0:0),0);assert.equal(chipTotal,4000);
});
