import test from 'node:test';
import assert from 'node:assert/strict';
import { handle } from '../mp-engine/rooms.mjs';

class MemoryStore {
  rooms = new Map();
  async load(code) { return structuredClone(this.rooms.get(code) ?? null); }
  async create(room) { this.rooms.set(room.code, structuredClone(room)); return true; }
  async cas(room, revision) {
    if (this.rooms.get(room.code)?.revision !== revision) return false;
    this.rooms.set(room.code, structuredClone(room)); return true;
  }
}

let sequence = 0;
const raw = ctx => ctx.store.rooms.get(ctx.code);
async function request(ctx, path, body, client, status = 200) {
  const headers = { 'Content-Type': 'application/json' };
  if (client) headers.Authorization = 'Bearer ' + client.token;
  const response = await handle(new Request('https://poker.test' + path, {
    method: 'POST', headers, body: JSON.stringify({ requestId: 'rotation_' + ++sequence, ...body }),
  }), ctx.store, () => 1_000_000_000);
  const data = await response.json();
  assert.equal(response.status, status, JSON.stringify(data));
  return data;
}
const command = (ctx, client, body) => request(ctx, '/api/room/' + ctx.code, body, client);
async function join(ctx, name) {
  const answer = await request(ctx, '/api/join', { roomCode: ctx.code, name });
  const client = { id: answer.playerId, token: answer.token, name };
  ctx.clients.push(client);
  await command(ctx, client, { type: 'ready', ready: true });
  return client;
}
async function deal(ctx) {
  const old = raw(ctx).game;
  const host = ctx.clients.find(c => c.id === raw(ctx).hostId);
  await command(ctx, host, { type: old ? 'next' : 'start' });
  assert.equal(raw(ctx).game.handNo, (old?.handNo ?? 0) + 1);
  assert.ok(raw(ctx).game.turnId > (old?.turnId ?? 0));
}
async function room(n = 4) {
  const ctx = { store: new MemoryStore(), clients: [] };
  const created = await request(ctx, '/api/create', { name: 'A', settings: {
    variant: 'holdem_nl', maxSeats: n, sb: 1, bb: 2, ante: 0, buyin: 200, turnSeconds: 180, autoFillBots: false,
  } }, null, 201);
  ctx.code = created.roomCode;
  ctx.clients.push({ id: created.playerId, token: created.token, name: 'A' });
  await command(ctx, ctx.clients[0], { type: 'ready', ready: true });
  for (let i = 1; i < n; i++) await join(ctx, String.fromCharCode(65 + i));
  await deal(ctx);
  return ctx;
}
async function finish(ctx) {
  let actions = 0;
  while (raw(ctx).game.phase !== 'complete') {
    assert.ok(++actions < 10, 'Folding must finish this preflop hand');
    const r = raw(ctx), client = ctx.clients.find(c => c.id === r.game.seats[r.game.actor].id);
    await command(ctx, client, { type: 'action', turnId: `${r.handEpoch}:${r.game.turnId}`, action: { type: 'fold' } });
  }
}
async function previousDealer(ctx, name) {
  for (let i = 0; raw(ctx).game.seats[raw(ctx).game.button].name !== name; i++) {
    assert.ok(i < ctx.clients.length);
    await finish(ctx); await deal(ctx);
  }
  await finish(ctx);
}
async function leave(ctx, names) {
  for (const name of names) await command(ctx, ctx.clients.find(c => c.name === name), { type: 'leave' });
}
function eliminate(ctx, names) {
  const r = raw(ctx);
  assert.equal(r.game.phase, 'complete');
  // Seed a completed hand's eliminated balances, preserving the total chips.
  // This regression concerns next-hand seating, independent of random showdown ranks.
  const recipient = r.members.find(m => !m.left && !names.includes(m.name));
  for (const name of names) {
    const member = r.members.find(m => m.name === name);
    recipient.stack += member.stack; member.stack = 0;
  }
  for (const p of r.game.seats) p.stack = r.members.find(m => m.id === p.id).stack;
}
function assertPositions(ctx, name) {
  const g = raw(ctx).game, live = g.seats.flatMap((p, i) => p.inHand ? [i] : []);
  assert.equal(g.seats[g.button].name, name, 'Next dealer must follow the previous dealer clockwise');
  const next = i => live[(live.indexOf(i) + 1) % live.length];
  assert.equal(g.sbSeat, live.length === 2 ? g.button : next(g.button), 'Heads-up dealer posts the small blind');
  assert.equal(g.bbSeat, next(g.sbSeat), 'Big blind follows the small blind');
  assert.equal(g.actor, next(g.bbSeat), 'Preflop action follows the big blind');
  for (const p of g.seats) if (p.sittingOut) assert.equal(p.inHand, false);
}

test('dealer rotation and heads-up positions remain correct without roster changes', async () => {
  for (const n of [2, 4]) {
    const ctx = await room(n);
    for (let i = 0; i <= n; i++) {
      assertPositions(ctx, String.fromCharCode(65 + i % n));
      if (i < n) { await finish(ctx); await deal(ctx); }
    }
  }
});

test('removed dealers rotate to the next surviving identity across compacted seats', async t => {
  for (const [dealer, removed, expected] of [
    ['A', ['A'], 'B'], ['C', ['C'], 'D'], ['D', ['D'], 'A'],
    ['A', ['A', 'B'], 'C'], ['C', ['A', 'C'], 'D'],
    ['B', ['A'], 'C'], ['D', ['A', 'B'], 'C'],
  ]) await t.test(`${dealer} dealt, ${removed.join('/')} left: next ${expected}`, async () => {
    const ctx = await room(); await previousDealer(ctx, dealer); await leave(ctx, removed);
    await deal(ctx); assertPositions(ctx, expected);
  });
});

test('dealer rotation skips zero-stack sitting-out seats after departures and wraparound', async t => {
  for (const [dealer, removed, broke, expected] of [
    ['A', [], ['A'], 'B'], ['A', ['A'], ['B'], 'C'],
    ['D', ['D'], ['A'], 'B'], ['C', [], ['C', 'D'], 'A'],
  ]) await t.test(`${dealer} dealt, removed ${removed.join('/') || 'none'}, broke ${broke.join('/')}: next ${expected}`, async () => {
    const ctx = await room(); await previousDealer(ctx, dealer); await leave(ctx, removed); eliminate(ctx, broke);
    await deal(ctx); assertPositions(ctx, expected);
    for (const name of broke) assert.ok(raw(ctx).game.seats.find(p => p.name === name).sittingOut);
  });
});

test('retained dealer rotation still includes a new player occupying the next seat', async () => {
  const ctx = await room(); await previousDealer(ctx, 'A'); await leave(ctx, ['B']);
  await join(ctx, 'E'); await deal(ctx); assertPositions(ctx, 'E');
});

test('a wholly replaced roster starts with its first funded seat', async () => {
  const ctx = await room(); await previousDealer(ctx, 'C'); await leave(ctx, ['A', 'B', 'C', 'D']);
  await join(ctx, 'E'); await join(ctx, 'F'); await deal(ctx); assertPositions(ctx, 'E');
});
