import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { VARIANTS, getVariant, createDeck, shuffle, card, evaluate, compare, exposedRank, secureInt } from './cards.mjs';

const cards = value => value.split(/\s+/).filter(Boolean).map(card);
const draw = (id, hand) => evaluate(id, cards(hand)).high;
const community = (id, hand, board) => evaluate(id, cards(hand), cards(board));
const better = (a, b) => assert.equal(compare(a, b), 1);

test('all 25 native registered games carry complete, immutable physical specs', () => {
  const expected = 'holdem_nl holdem_fl plo plo8 omaha8_fl plo5 plo6 big_o courchevel courchevel8 pineapple crazy_pineapple shortdeck stud7 stud7_hilo stud5 razz draw5 deuce_single deuce_triple ace5_triple badugi early20 straight52 draw5_early'.split(' ').sort();
  assert.deepEqual(Object.keys(VARIANTS).sort(), expected);
  for (const [id, spec] of Object.entries(VARIANTS)) {
    assert.equal(getVariant(id), spec);
    assert.equal(spec.deckSize, id === 'early20' ? 20 : id === 'shortdeck' ? 36 : 52);
    assert.equal(spec.seatCap, spec.maxSeats);
    assert.ok(spec.initialCards <= spec.holeCount);
    assert.ok(spec.initialCards * spec.seatCap <= spec.deckSize);
    assert.ok(Object.isFrozen(spec));
    assert.ok(Object.isFrozen(spec.streets));
    const deck = createDeck(id);
    assert.equal(deck.length, spec.deckSize);
    assert.equal(new Set(deck.map(c => c.text)).size, spec.deckSize);
    assert.ok(deck.every(c => c.val >= 2 && c.val <= 14 && c.text === c.rank + c.suit));
    if (spec.family === 'community') {
      assert.equal(spec.streets.reduce((n, street) => n + street.boardCards, 0), 5);
      assert.ok(spec.holeCount * spec.seatCap + 5 + 3 <= spec.deckSize);
    }
    for (const street of spec.drawAfter) assert.ok(spec.streets.some(s => s.id === street));
    if (spec.bigBetFrom) assert.ok(spec.streets.some(s => s.id === spec.bigBetFrom));
  }
  assert.equal(VARIANTS.courchevel.streets[0].boardCards, 1);
  assert.equal(VARIANTS.courchevel8.streets[1].boardCards, 2);
  assert.equal(VARIANTS.pineapple.discardAfter, 'PREFLOP');
  assert.equal(VARIANTS.crazy_pineapple.discardAfter, 'FLOP');
  assert.equal(VARIANTS.deuce_triple.bigBetFrom, 'DRAW2');
  assert.equal(VARIANTS.stud5.bigBetFrom, 'FOURTH');
  assert.throws(() => getVariant('__proto__'), /Unknown/);
});

test('standard high categories and kicker ordering', () => {
  const hands = [
    'As Kd 9c 7h 3d',
    '2s 2d Ac Kh 9d',
    '2s 2d 3c 3h Ad',
    '2s 2d 2c Kh Ad',
    'As 2d 3c 4h 5d',
    'As Js 8s 4s 2s',
    '2s 2d 2c Ah Ad',
    '2s 2d 2c 2h Ad',
    'As 2s 3s 4s 5s',
  ].map(hand => draw('draw5', hand));
  hands.forEach((rank, i) => assert.equal(rank[0], i));
  for (let i = 1; i < hands.length; i++) better(hands[i], hands[i - 1]);
  better(draw('draw5', 'As Kd Qc Jh 9d'), draw('draw5', 'Ah Kc Qd Js 8h'));
  better(draw('draw5', 'As Ad Kc Qh Jd'), draw('draw5', 'Ah Ac Ks Qd Th'));
  better(draw('draw5', 'As Ad Kc Kh Qd'), draw('draw5', 'Ah Ac Ks Kd Jh'));
  better(draw('draw5', 'As Ad Ac 2h 2d'), draw('draw5', 'Ks Kd Kc Ah Ad'));
  better(draw('draw5', '2s 3h 4d 5c 6s'), draw('draw5', 'As 2h 3d 4c 5s'));
  assert.equal(compare(draw('draw5', 'As Kd Qc Jh 9d'), draw('draw5', 'Ah Ks Qd Jc 9h')), 0);
  assert.equal(compare([1, 14], [1, 14, 0, 0]), 0);
  assert.equal(compare(null, null), 0);
  assert.equal(compare([0], null), 1);
});

test('holdem may play the board, every Omaha-family game must use exactly two plus three', () => {
  const royalBoard = 'As Ks Qs Js Ts';
  assert.deepEqual(community('holdem_nl', '2c 3d', royalBoard).high, [8, 14]);
  assert.equal(compare(community('holdem_nl', '2c 3d', royalBoard).high, community('holdem_nl', '7h 8d', royalBoard).high), 0);
  for (const id of ['plo', 'plo8', 'omaha8_fl', 'plo5', 'plo6', 'big_o', 'courchevel', 'courchevel8']) {
    const h = ['2c', '3d', '4h', '5c', '6d', '7h'].slice(0, VARIANTS[id].holeCount).join(' ');
    const rank = community(id, h, royalBoard).high;
    assert.notEqual(rank[0], 8, id + ' illegally played the board');
    assert.notEqual(rank[0], 5, id + ' illegally made a flush with fewer than two suited private cards');
    const quadsInHole = ['As', 'Ah', 'Ad', 'Ac', '2s', '3h'].slice(0, VARIANTS[id].holeCount).join(' ');
    assert.notEqual(community(id, quadsInHole, 'Kh Qc Jd 7s 8h').high[0], 7, id + ' illegally used four private cards');
    const royalHole = ['As', 'Ks', '2c', '3d', '4h', '5c'].slice(0, VARIANTS[id].holeCount).join(' ');
    assert.deepEqual(community(id, royalHole, 'Qs Js Ts 7h 8d').high, [8, 14]);
  }
  assert.deepEqual(community('plo', 'Qs Qh Tc Jd', 'As Ah Ad Ac Kh').high, [6, 14, 12]);
});

test('split hands choose independent high and low, distinct eight-or-better qualification', () => {
  const scoop = community('plo8', 'As 2s Kc Kd', '3h 4d 5c Ks Kh');
  assert.deepEqual(scoop.high, [7, 13, 5]);
  assert.deepEqual(scoop.low, [10, 11, 12, 13, 14]);
  assert.equal(scoop.lowLabel, '5-4-3-2-A low');
  const pairedLow = community('plo8', 'As Ah Kd Qc', '2c 3d 4h 8s 9d');
  assert.equal(pairedLow.low, null, 'one usable low private rank cannot qualify');
  assert.equal(community('plo8', 'As 2h Kd Qc', '3c 4d 9h Js Th').low, null);
  assert.equal(community('plo8', 'As 2h Kd Qc', '3c 3d 4h Js Th').low, null);
  const low8 = community('plo8', 'As 2h Kd Qc', '3c 4d 8h Js Th').low;
  assert.deepEqual(low8, [7, 11, 12, 13, 14]);
  better(scoop.low, low8);
  assert.equal(compare(low8, community('plo8', 'Ah 2s Kc Qd', '3h 4c 8d Jc Ts').low), 0);
  const stud = evaluate('stud7_hilo', cards('As 2s 3s 4s 5s Kh Qd'));
  assert.deepEqual(stud.high, [8, 5]);
  assert.deepEqual(stud.low, [10, 11, 12, 13, 14]);
});

test('short deck ranking, wheel, and omitted ranks', () => {
  const flush = community('shortdeck', 'As Js', '9s 8s 6s Kd Qh').high;
  const fullHouse = community('shortdeck', 'Ah Ad', 'Ac Kh Kd 7s 8h').high;
  assert.equal(flush[0], 6);
  assert.equal(fullHouse[0], 5);
  better(flush, fullHouse);
  assert.deepEqual(community('shortdeck', 'Ah 9d', '6c 7h 8s Kc Kd').high, [4, 9]);
  assert.deepEqual(community('shortdeck', 'As 9s', '6s 7s 8s Kh Kd').high, [8, 9]);
  const straight = community('shortdeck', 'Ts 9h', '8d 7c 6s Ah Kd').high;
  better(straight, community('shortdeck', 'As Ah', 'Ac 9d 8s 7c 6h').high);
  assert.throws(() => community('shortdeck', 'As 2d', '6h 7c 8s Kh Qd'), /deck/);
});

test('A-to-5 and Razz ignore straights and flushes; pairs remain penalties', () => {
  const wheel = draw('ace5_triple', 'As 2s 3s 4s 5s');
  assert.deepEqual(wheel, [5, 10, 11, 12, 13, 14]);
  better(wheel, draw('ace5_triple', 'Ah 2d 3c 4h 6s'));
  better(draw('ace5_triple', 'Kh Qd Jc Th 9s'), draw('ace5_triple', 'As Ah 2c 3d 4s'));
  better(draw('ace5_triple', 'As Ah Kc Qd Js'), draw('ace5_triple', '2s 2h 3c 4d 5s'));
  const r = evaluate('razz', cards('As 2s 3s 4s 5s Kh Qd'));
  assert.deepEqual(r.high, wheel);
  assert.equal(r.low, null);
  assert.equal(r.highLabel, '5-4-3-2-A low');
  assert.deepEqual(evaluate('razz', cards('As 2d 3c 4h Kh Qd'), cards('5s')).high, wheel);
});

test('deuce-to-seven ace-high and straight/flush penalties order correctly', () => {
  const nuts = draw('deuce_single', '7s 5h 4d 3c 2s');
  assert.deepEqual(nuts, [8, 8, 10, 11, 12, 13]);
  better(nuts, draw('deuce_single', '7s 6h 4d 3c 2s'));
  better(draw('deuce_single', 'Kh Qd Jc 9h 8s'), draw('deuce_single', 'As 5h 4d 3c 2s'));
  assert.equal(draw('deuce_single', 'As 5h 4d 3c 2s')[0], 8, 'wheel is ace-high in deuce-to-seven');
  const fromWorst = [
    'Ts Js Qs Ks As', 'As Ah Ad Ac 2s', 'As Ah Ad 2c 2s', 'As 9s 7s 4s 2s',
    '2s 3h 4d 5c 6s', 'As Ah Ad 3c 2s', 'As Ah Kd Kc 2s', 'As Ah 4d 3c 2s', 'Ks Qh Jd 9c 8s',
  ].map(hand => draw('deuce_triple', hand));
  fromWorst.forEach((rank, i) => assert.equal(rank[0], i));
  for (let i = 1; i < fromWorst.length; i++) better(fromWorst[i], fromWorst[i - 1]);
  better(draw('deuce_single', '2s 2h 7d 5c 3s'), draw('deuce_single', '3s 3h 5d 4c 2s'));
});

test('Badugi searches subsets with distinct ranks and suits before rank comparison', () => {
  const nuts = draw('badugi', 'As 2h 3d 4c');
  assert.deepEqual(nuts, [4, 11, 12, 13, 14]);
  const fourHigh = draw('badugi', 'Ks Qh Jd Tc');
  const threeLow = draw('badugi', 'As 2h 3d 4d');
  assert.deepEqual(threeLow, [3, 12, 13, 14]);
  better(fourHigh, threeLow);
  better(nuts, fourHigh);
  assert.deepEqual(draw('badugi', 'As Ah 2s 3d'), [3, 12, 13, 14], 'choose Ah and 2s instead of a greedy As');
  assert.deepEqual(draw('badugi', 'As 2s 3s 4s'), [1, 14]);
  assert.deepEqual(draw('badugi', 'As Ah Ad Ac'), [1, 14]);
  assert.equal(compare(nuts, draw('badugi', 'Ah 2d 3c 4s')), 0);
});

test('historical house rules never introduce modern straights or 20-card flushes', () => {
  assert.equal(draw('early20', 'As Ks Qs Js Ts')[0], 0);
  assert.equal(draw('straight52', 'As Ks Qs Js Ts')[0], 5);
  assert.equal(draw('straight52', 'As Kh Qd Jc Ts')[0], 0);
  assert.equal(draw('draw5_early', '2s 3h 4d 5c 6s')[0], 0);
  better(draw('draw5_early', '2s 2h 2d 3c 3s'), draw('draw5_early', 'As Ks Qs Js Ts'));
  assert.equal(VARIANTS.early20.drawAfter.length, 0);
  assert.equal(VARIANTS.straight52.drawAfter.length, 0);
  assert.equal(VARIANTS.draw5_early.drawAfter.length, 1);
  assert.throws(() => draw('early20', 'As Ah Kd Qc 9s'), /deck/);
});

test('Stud upcard comparison ignores suits, four-card straights/flushes; low reverses ranks', () => {
  better(exposedRank(cards('2s 2h')), exposedRank(cards('As Kh')));
  assert.equal(compare(exposedRank(cards('As Kh')), exposedRank(cards('Ah Ks'))), 0);
  better(exposedRank(cards('As 2h'), true), exposedRank(cards('3s 2d'), true));
  better(exposedRank(cards('Ks Qh'), true), exposedRank(cards('As Ah'), true));
  assert.equal(exposedRank(cards('2s 3s 4s 5s'))[0], 0);
  better(exposedRank(cards('As Ah'), true), exposedRank(cards('2s 2h'), true));
});

test('showdown validation rejects stale Pineapple, incomplete Stud, duplicates and forged cards', () => {
  assert.throws(() => community('pineapple', 'As Kh Qd', '2c 3h 4s 5d 6c'), /requires 2/);
  assert.throws(() => evaluate('stud7', cards('As Kh Qd Jc Ts 2h')), /incomplete/);
  assert.throws(() => evaluate('stud5', cards('As Kh Qd Jc'), cards('Ts')), /invalid/);
  assert.throws(() => community('holdem_nl', 'As As', '2c 3h 4s 5d 6c'), /Duplicate/);
  assert.throws(() => community('holdem_nl', 'As Kh', 'As 3h 4s 5d 6c'), /Duplicate/);
  const h = cards('As Kh'); h[0].val = 2;
  assert.throws(() => evaluate('holdem_nl', h, cards('2c 3h 4s 5d 6c')), /mismatch/);
  assert.throws(() => draw('badugi', 'As 2h 3d'), /exactly 4/);
  assert.deepEqual(card('10h'), card('T♥'));
  assert.throws(() => card('joker'), /Invalid/);
  assert.throws(() => compare([NaN], [1]), /Invalid/);
});

test('secure shuffle preserves every physical card and uses rejection for biased tails', () => {
  const deck = createDeck('holdem_nl'), original = deck.map(c => c.text).sort();
  assert.equal(shuffle(deck), deck);
  assert.deepEqual(deck.map(c => c.text).sort(), original);
  assert.throws(() => secureInt(0), /Invalid/);
  const descriptor = Object.getOwnPropertyDescriptor(globalThis, 'crypto');
  let reads = 0;
  try {
    Object.defineProperty(globalThis, 'crypto', { configurable: true, value: { getRandomValues(sample) { sample[0] = reads++ === 0 ? 0xffffffff : 7; return sample; } } });
    assert.equal(secureInt(10), 7);
    assert.equal(reads, 2, '0xffffffff lies in the rejected tail for bound ten');
    Object.defineProperty(globalThis, 'crypto', { configurable: true, value: undefined });
    assert.throws(() => shuffle([1, 2]), /Secure randomness/);
  } finally { Object.defineProperty(globalThis, 'crypto', descriptor); }
});

test('every variant evaluates complete randomized hands and is invariant to card order', () => {
  let count = 0;
  for (const spec of Object.values(VARIANTS)) for (let i = 0; i < 32; i++) {
    const deck = shuffle(createDeck(spec.id));
    const holeCount = spec.discardAfter ? 2 : spec.holeCount;
    const h = deck.splice(0, holeCount), b = spec.family === 'community' ? deck.splice(0, 5) : [];
    const first = evaluate(spec.id, h, b), permuted = evaluate(spec.id, h.slice().reverse(), b.slice().reverse());
    assert.deepEqual(first, permuted, spec.id);
    assert.ok(first.high.every(Number.isFinite));
    assert.ok(first.highLabel.length > 0);
    if (!spec.split) assert.equal(first.low, null);
    if (spec.split && first.low) {
      assert.equal(first.low.length, 5);
      assert.ok(first.low.every(n => n >= 7 && n <= 14));
    }
    count++;
  }
  assert.equal(count, 800);
});

test('portable evaluators exactly match independent bundled native rank functions on 5,000 deals', () => {
  const source = readFileSync(new URL('./game.html', import.meta.url), 'utf8');
  const functionText = name => {
    const prefix = 'function ' + name + '(';
    let begin = source.indexOf(prefix);
    if (begin < 0) throw new Error('Native function missing: ' + name);
    let start = source.indexOf('{', begin), depth = 0;
    for (let i = start; i < source.length; i++) {
      if (source[i] === '{') depth++;
      if (source[i] === '}' && --depth === 0) return source.slice(begin, i + 1);
      // These compact native numeric functions contain no braces in strings.
    }
    throw new Error('Unclosed native function: ' + name);
  };
  // Whole native functions are evaluated independently. No portable helper is
  // supplied to them, so agreement tests do not merely call our own evaluator.
  const context = vm.createContext({});
  vm.runInContext([
    'const desc = a => a.slice().sort((x,y)=>y-x);',
    'const counts = a => { const r={}; for(const c of a) r[c.val]=(r[c.val]||0)+1; return r; };',
    functionText('compareRankArrays'), functionText('evaluateFive'), functionText('evaluateHandRank'),
    functionText('shortFive'), functionText('groupRank'), functionText('deuceRank'), functionText('ace5Rank'),
  ].join('\n'), context);
  const nativeFunctions = {
    draw5: h => context.evaluateFive(h),
    deuce_single: h => context.deuceRank(h),
    ace5_triple: h => context.ace5Rank(h),
    straight52: h => context.groupRank(h, true),
    early20: h => context.groupRank(h, false),
  };
  for (const [id, oracle] of Object.entries(nativeFunctions)) for (let i = 0; i < 1000; i++) {
    const hand = shuffle(createDeck(id)).slice(0, 5);
    assert.deepEqual(evaluate(id, hand).high, Array.from(oracle(hand)), id + ' disagreed with parent');
  }
});
