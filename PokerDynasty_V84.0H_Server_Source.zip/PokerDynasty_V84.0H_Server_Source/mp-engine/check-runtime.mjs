import {existsSync} from 'node:fs';
const [major,minor]=process.versions.node.split('.').map(Number);
if(major<22||(major===22&&minor<13)){
 console.error('Poker Dynasty V84.0E needs Node.js 22.13.0 or newer. Current runtime: '+process.version+'. Install a current supported Node.js release and run this launcher again.');
 process.exit(1);
}
if(!existsSync(new URL('./game.html',import.meta.url))){
 console.error('mp-engine/game.html is missing. Extract the complete Poker Dynasty V84.0E server package before starting or testing.');
 process.exit(1);
}
