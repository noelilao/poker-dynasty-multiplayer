/* Operator-side SQLite pre-migration backup. Not a client export and not a D1/R2 backup.
 * Run before schema changes. Fail closed: a failed backup must abort server startup.
 * VACUUM INTO includes committed WAL data; entry replay's encryption key is included.
 */
import {DatabaseSync} from 'node:sqlite';
import {existsSync, mkdirSync, readFileSync, copyFileSync, chmodSync, writeFileSync, statSync} from 'node:fs';
import {createHash, randomBytes} from 'node:crypto';
import path from 'node:path';
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
export function backupBeforeSchema(dataDir) {
  const source = path.join(dataDir, 'rooms.sqlite');
  if (!existsSync(source) || statSync(source).size === 0) return null;
  const keyPath = path.join(dataDir, 'entry-receipt.key');
  const keyBefore = existsSync(keyPath) ? readFileSync(keyPath) : null;
  const stamp = new Date().toISOString().replace(/[:.]/g, '-');
  const dir = path.join(dataDir, 'backups', `pre-V84.0H-${stamp}-${randomBytes(4).toString('hex')}`);
  mkdirSync(dir, {recursive:true, mode:0o700});
  const dest = path.join(dir, 'rooms.sqlite');
  let db, verify;
  try {
    db = new DatabaseSync(source, {readOnly:true});
    db.exec('PRAGMA busy_timeout=5000');
    db.prepare('VACUUM INTO ?').run(dest);
    db.close(); db=null;
    chmodSync(dest, 0o600);
    verify = new DatabaseSync(dest, {readOnly:true});
    const check=verify.prepare('PRAGMA quick_check').all();
    if (check.length !== 1 || check[0].quick_check !== 'ok') throw new Error('Snapshot SQLite integrity check failed.');
    const tables = verify.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name").all().map(x=>x.name);
    const counts=Object.fromEntries(tables.map(name=>[name,verify.prepare('SELECT count(*) AS n FROM "'+name.replaceAll('"','""')+'"').get().n]));
    verify.close();verify=null;
    const hasReceipts=tables.includes('career_entry_receipts') && counts.career_entry_receipts>0;
    if (hasReceipts && !keyBefore) throw new Error('Entry receipt key is missing; refusing a non-restorable backup.');
    if ((existsSync(keyPath) ? sha(readFileSync(keyPath)) : null) !== (keyBefore ? sha(keyBefore) : null)) throw new Error('Receipt key changed during backup; stop the other server before retrying.');
    const files={'rooms.sqlite':{bytes:statSync(dest).size,sha256:sha(readFileSync(dest))}};
    if(keyBefore){copyFileSync(keyPath,path.join(dir,'entry-receipt.key'));chmodSync(path.join(dir,'entry-receipt.key'),0o600);files['entry-receipt.key']={bytes:keyBefore.length,sha256:sha(keyBefore)};}
    const manifest={format:'PokerDynastySQLitePreMigration',version:1,createdAt:new Date().toISOString(),targetBuild:'84.0H',sqliteIntegrity:'ok',tables:counts,files};
    writeFileSync(path.join(dir,'manifest.json'),JSON.stringify(manifest,null,2),{mode:0o600});
    return {directory:dir,manifest};
  } catch(e) {
    throw new Error('Pre-migration backup failed; no schema update performed. '+e.message, {cause:e});
  } finally { try{db?.close();}catch{} try{verify?.close();}catch{} }
}
