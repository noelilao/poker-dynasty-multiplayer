import './check-runtime.mjs';
import {spawn} from 'node:child_process';
import {fileURLToPath} from 'node:url';
const cwd=fileURLToPath(new URL('../',import.meta.url));
const suites=[
 ['--test','mp-engine/cards.test.mjs','tests/security.test.mjs','tests/dealer-rotation.test.mjs','tests/room-profiles.test.mjs','tests/room-autofill.test.mjs','tests/career841-authority.test.mjs','tests/career84-tournaments.test.mjs','tests/career841-persistence.test.mjs','tests/career841-crypto-fallback.test.mjs','tests/life842-core.test.mjs','tests/life842-authority.test.mjs','tests/life842-homegames.test.mjs','tests/startup-backup.test.mjs'],
 ['mp-engine/engine.test.mjs'],
 ['mp-engine/engine-rooms.test.mjs']
];
for(const args of suites){
 const code=await new Promise((resolve,reject)=>{const child=spawn(process.execPath,args,{cwd,env:process.env,stdio:'inherit'});child.once('error',reject);child.once('exit',(code,signal)=>resolve(signal?1:code??1));});
 if(code!==0)process.exit(code);
}
console.log('All packaged Poker Dynasty V84.2 test groups passed.');
