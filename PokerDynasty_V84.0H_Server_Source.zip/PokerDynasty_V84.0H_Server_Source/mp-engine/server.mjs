/* Standalone Poker Dynasty room server. Node 22.13+; no npm packages. */
import http from 'node:http';
import { DatabaseSync } from 'node:sqlite';
import { readFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import { handle } from './rooms.mjs';
import { handleCareer } from './career84.mjs';
import {backupBeforeSchema} from './startup-backup.mjs';
import {entryReceipts,CORS} from './entry-receipts.mjs';

const root=path.dirname(fileURLToPath(import.meta.url));
const data=process.env.PD83_DATA_DIR||path.join(root,'data');mkdirSync(data,{recursive:true});
const startupBackup=backupBeforeSchema(data);
if(startupBackup)console.log('Verified pre-migration backup:',startupBackup.directory);
const db=new DatabaseSync(path.join(data,'rooms.sqlite'));
db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS poker_rooms(code TEXT PRIMARY KEY,revision INTEGER NOT NULL,state TEXT NOT NULL,expires_at INTEGER NOT NULL); CREATE INDEX IF NOT EXISTS poker_rooms_expiry ON poker_rooms(expires_at); CREATE TABLE IF NOT EXISTS poker_request_limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL,expires_at INTEGER NOT NULL); CREATE INDEX IF NOT EXISTS poker_request_limits_expiry ON poker_request_limits(expires_at); CREATE TABLE IF NOT EXISTS career_worlds(code TEXT PRIMARY KEY,revision INTEGER NOT NULL,state TEXT NOT NULL,expires_at INTEGER NOT NULL); CREATE INDEX IF NOT EXISTS career_worlds_expiry ON career_worlds(expires_at); CREATE TABLE IF NOT EXISTS career_snapshots(ref TEXT PRIMARY KEY,text TEXT NOT NULL,created_at INTEGER NOT NULL);');
const store={
 async health(){db.prepare('SELECT code FROM poker_rooms LIMIT 1').get();},
 async load(code){const r=db.prepare('SELECT state FROM poker_rooms WHERE code=?').get(code);return r?JSON.parse(r.state):null;},
 async create(r){return db.prepare('INSERT OR IGNORE INTO poker_rooms(code,revision,state,expires_at) VALUES(?,?,?,?)').run(r.code,r.revision,JSON.stringify(r),r.expiresAt).changes===1;},
 async cas(r,rev){return db.prepare('UPDATE poker_rooms SET revision=?,state=?,expires_at=? WHERE code=? AND revision=?').run(r.revision,JSON.stringify(r),r.expiresAt,r.code,rev).changes===1;},
 async rate(key,max,expires){return db.prepare('INSERT INTO poker_request_limits(key,count,expires_at) VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1 RETURNING count').get(key,expires).count<=max;},
 async careerLoad(code){const r=db.prepare('SELECT state FROM career_worlds WHERE code=?').get(code);return r?JSON.parse(r.state):null;},
 async careerCreate(w){return db.prepare('INSERT OR IGNORE INTO career_worlds(code,revision,state,expires_at) VALUES(?,?,?,?)').run(w.worldCode,w.revision,JSON.stringify(w),w.expiresAt).changes===1;},
 async careerSnapshotPut(ref,text){const old=db.prepare('SELECT text FROM career_snapshots WHERE ref=?').get(ref);if(old&&old.text!==text)throw new Error('Immutable snapshot reference conflict');if(!old)db.prepare('INSERT INTO career_snapshots(ref,text,created_at) VALUES(?,?,?)').run(ref,text,Date.now());},
 async careerSnapshotGet(ref){return db.prepare('SELECT text FROM career_snapshots WHERE ref=?').get(ref)?.text||null;},
 async careerCas(w,rev){return db.prepare('UPDATE career_worlds SET revision=?,state=?,expires_at=? WHERE code=? AND revision=?').run(w.revision,JSON.stringify(w),w.expiresAt,w.worldCode,rev).changes===1;},
 async prune(now){db.prepare('DELETE FROM poker_rooms WHERE expires_at<?').run(now);db.prepare('DELETE FROM career_worlds WHERE expires_at<?').run(now);db.prepare('DELETE FROM poker_request_limits WHERE expires_at<?').run(now);}
};
const withEntryReceipt=entryReceipts(db,data,store);store.entryReplay=true;
let requestQueue=Promise.resolve();
const serialize=fn=>{const p=requestQueue.catch(()=>{}).then(fn);requestQueue=p.catch(()=>{});return p;};
const html=readFileSync(path.join(root,'game.html'));
const port=Number(process.env.PORT||process.env.PD83_PORT||8080),host=process.env.PD83_BIND||'0.0.0.0';
if(!Number.isInteger(port)||port<1||port>65535)throw new Error('PD83_PORT must be a valid port.');
const server=http.createServer(async(req,res)=>{
 try{
  const pathname=new URL(req.url,'http://localhost').pathname;
  if(req.method==='OPTIONS'&&(pathname.startsWith('/api/')||pathname==='/health')){res.writeHead(204,CORS);res.end();return;}
  if((req.method==='GET'||req.method==='HEAD')&&['/','/game.html','/index.html'].includes(pathname)){
   res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer','Permissions-Policy':'web-share=(self)','Cross-Origin-Resource-Policy':'same-origin'});res.end(req.method==='HEAD'?undefined:html);return;
  }
  if(!pathname.startsWith('/api/')&&pathname!=='/health'){res.writeHead(404,{'Content-Type':'text/plain'});res.end('Not found');return;}
  const bodyLimit=pathname.startsWith('/api/career84/')?17*1024*1024:16384;let length=0;const chunks=[];for await(const part of req){length+=part.length;if(length>bodyLimit){res.writeHead(413,CORS);res.end('{"error":"Request is too large."}');return;}chunks.push(part);}
  const headers=new Headers();for(const [key,value] of Object.entries(req.headers))if(value!==undefined)headers.set(key,Array.isArray(value)?value.join(','):value);
  headers.delete('cf-connecting-ip');headers.set('x-real-ip',req.socket.remoteAddress||'local');
  const request=new Request(`http://localhost${req.url}`,{method:req.method,headers,...(!['GET','HEAD'].includes(req.method)?{body:Buffer.concat(chunks)}:{})});
  const result=await serialize(()=>pathname.startsWith('/api/career84/')?withEntryReceipt(request,r=>handleCareer(r,store)):handle(request,store));res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));
 }catch(error){console.error('Request failed:',error?.message||error);if(!res.headersSent)res.writeHead(503,CORS);res.end('{"error":"Room service temporarily unavailable."}');}
});
server.requestTimeout=30000;server.headersTimeout=15000;
server.listen(port,host,()=>{
 console.log(`Poker Dynasty V84.0H service listening on ${host}:${port}.`);
 console.log('Players use the published HTTPS website. No player-side server installation is required.');
 console.log('Keep the existing persistent data directory and receipt key. Run one authority process per database.');
});
function stop(){server.close(()=>{db.close();process.exit(0);});}
process.on('SIGINT',stop);process.on('SIGTERM',stop);
