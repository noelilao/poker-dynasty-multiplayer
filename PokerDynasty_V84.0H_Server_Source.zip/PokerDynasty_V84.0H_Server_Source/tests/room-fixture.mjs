import assert from 'node:assert/strict';
import { handle } from '../mp-engine/rooms.mjs';
import { legal, assertGame } from '../mp-engine/engine.mjs';
import { VARIANTS } from '../mp-engine/cards.mjs';

export const receipts = { requests: 0, hands: 0, botDecisions: 0, humanDecisions: 0, timeouts: 0, privacyChecks: 0, custodyChecks: 0, conflicts: 0 };
export class MemoryStore {
  rooms = new Map();
  conflicts = 0;
  collideNextLoads(count) {
    let release;
    const waiting = new Promise(resolve => { release = resolve; });
    this.barrier = { remaining: count, waiting, release };
  }
  async load(code) {
    const value = structuredClone(this.rooms.get(code) ?? null), barrier = this.barrier;
    if (barrier) {
      if (--barrier.remaining === 0) { this.barrier = null; barrier.release(); }
      else await barrier.waiting;
    }
    return value;
  }
  async create(room) {
    if (this.rooms.has(room.code)) return false;
    this.rooms.set(room.code, structuredClone(room)); return true;
  }
  async cas(room, revision) {
    if (this.rooms.get(room.code)?.revision !== revision) { this.conflicts++; receipts.conflicts++; return false; }
    this.rooms.set(room.code, structuredClone(room)); return true;
  }
}

let sequence = 0;
export const raw = ctx => ctx.store.rooms.get(ctx.code);
export const live = ctx => raw(ctx).members.filter(m => !m.left && !m.kicked);
export const host = ctx => ctx.clients.find(c => c.id === raw(ctx).hostId);
export function assertCustody(ctx) {
  const r = raw(ctx);
  assert.ok(r.members.every(m => Number.isSafeInteger(m.stack) && m.stack >= 0));
  assert.equal(new Set(r.members.map(m => m.id)).size, r.members.length);
  const humans = live(ctx).filter(m => !m.bot && !m.spectator);
  assert.ok(humans.length <= r.settings.maxSeats, 'Seated and queued humans cannot overbook a room');
  const seated = live(ctx).filter(m => !m.spectator && !m.waiting);
  assert.ok(seated.length <= r.settings.maxSeats);
  assert.equal(new Set(seated.map(m => m.seat)).size, seated.length, 'No occupied seat has two owners');
  for (const m of live(ctx).filter(m => m.waiting)) {
    assert.equal(m.seat, -1); assert.equal(m.bot, false); assert.equal(m.spectator, false);
    assert.ok(!r.game?.seats.some(p => p.id === m.id), 'A waiter never owns a current-hand seat');
  }
  if (r.game) assertGame(r.game);
  receipts.custodyChecks++;
}
export function assertPrivacy(ctx, payload, client) {
  const r = raw(ctx), g = r.game;
  if (!g) return;
  const member = r.members.find(m => m.id === client?.id);
  const ownId = member && !member.waiting && !member.spectator ? member.id : null;
  const allowed = new Set(g.board.map(c => c.text));
  const open = g.settings.allowCheats && g.revealedAll;
  for (const p of g.seats) p.hole.forEach((c, i) => {
    if (p.id === ownId || open || p.up[i] || (g.settlement?.showdown && p.inHand && !p.folded)) allowed.add(c.text);
  });
  const serialized = JSON.stringify(payload);
  for (const c of [...g.deck, ...g.discards, ...g.burned, ...g.seats.flatMap(p => p.hole)]) {
    if (!allowed.has(c.text)) assert.ok(!serialized.includes(c.text), 'Private card text leaked: ' + c.text);
  }
  const forbidden = new Set(['deck', 'discards', 'burned', 'hole', 'tokenHash', 'handEpoch', 'startStacks']);
  function walk(value) {
    if (!value || typeof value !== 'object') return;
    if ('rank' in value && 'suit' in value) assert.ok(allowed.has(value.rank + value.suit), 'Private card object leaked');
    for (const [key, child] of Object.entries(value)) { assert.ok(!forbidden.has(key), 'Custody field leaked: ' + key); walk(child); }
  }
  walk(payload);
  if (member?.waiting) {
    assert.equal(payload.view.table.canAct, false); assert.deepEqual(payload.view.table.legal, []);
    assert.equal(payload.view.table.youSeat, -1); assert.equal(payload.view.youSeat, -1);
  }
  receipts.privacyChecks++;
}
export async function request(ctx, path, body, client, expected = 200) {
  const headers = { 'Content-Type': 'application/json' };
  if (client) headers.Authorization = 'Bearer ' + client.token;
  const response = await handle(new Request('https://poker.test' + path, {
    method: 'POST', headers, body: JSON.stringify({ requestId: 'fixture_' + ++sequence, ...body }),
  }), ctx.store, () => ctx.now);
  receipts.requests++;
  const data = { status: response.status, ...await response.json() };
  if (expected !== null) assert.equal(response.status, expected, JSON.stringify(data));
  if (ctx.code && raw(ctx)) assertCustody(ctx);
  if (data.view && client) assertPrivacy(ctx, data, client);
  return data;
}
export const command = (ctx, client, body, expected = 200) => request(ctx, '/api/room/' + ctx.code, body, client, expected);
export const poll = (ctx, client = host(ctx)) => command(ctx, client, { type: 'poll' });
export const ready = (ctx, client = host(ctx), value = true) => command(ctx, client, { type: 'ready', ready: value });
export async function join(ctx, name, body = {}, expected = 200) {
  const data = await request(ctx, '/api/join', { roomCode: ctx.code, name, ...body }, null, expected);
  if (data.status !== 200) return data;
  const client = { id: data.playerId, token: data.token, name };
  ctx.clients.push(client); assertPrivacy(ctx, data, client);
  return { ...data, client };
}
export async function room(options = {}) {
  const variant = options.variant || 'holdem_nl';
  const ctx = { store: new MemoryStore(), now: 1_000_000_000, clients: [] };
  const created = await request(ctx, '/api/create', { name: 'Host', settings: {
    variant, maxSeats: options.maxSeats || 6, sb: 1, bb: 2, ante: VARIANTS[variant].family === 'stud' || VARIANTS[variant].anteOnly ? 1 : 0,
    buyin: 200, turnSeconds: 180, ...options.settings,
  }, ...options.body }, null, 201);
  ctx.code = created.roomCode;
  ctx.clients.push({ id: created.playerId, token: created.token, name: 'Host' });
  await ready(ctx); return ctx;
}
export async function start(ctx) {
  return command(ctx, host(ctx), { type: raw(ctx).game ? 'next' : 'start' });
}
export async function finish(ctx, options = {}) {
  const bank = raw(ctx).game.bankTotal;
  let steps = 0;
  while (raw(ctx).game.phase !== 'complete') {
    assert.ok(++steps <= 400, 'A hand must terminate within the decision budget');
    const r = raw(ctx), g = r.game, p = g.seats[g.actor];
    if (steps % 15 === 0) for (const client of ctx.clients) if (live(ctx).some(m => m.id === client.id)) await poll(ctx, client);
    const current = raw(ctx).game;
    if (current.turnId !== g.turnId || current.phase === 'complete') continue;
    if (options.timeouts && steps % 11 === 0) {
      ctx.now = g.deadline + 1; await poll(ctx); receipts.timeouts++;
    } else if (p.bot) {
      await poll(ctx); ctx.now += 610; await poll(ctx); receipts.botDecisions++;
    } else if (r.members.find(m => m.id === p.id)?.left) {
      await poll(ctx);
    } else {
      const client = ctx.clients.find(c => c.id === p.id), actions = legal(g, g.actor);
      assert.ok(client, 'Human decisions need a bearer owner');
      const choice = actions.find(a => a.type === 'draw' || a.type === 'discard')
        || (options.fold ? actions.find(a => a.type === 'fold') : null)
        || actions.find(a => a.type === 'check') || actions.find(a => a.type === 'call') || actions[0];
      const action = { type: choice.type };
      if (choice.type === 'draw') action.indices = options.drawAll ? p.hole.map((_, i) => i) : [];
      if (choice.type === 'discard') action.indices = [p.hole.length - 1];
      if (choice.type === 'raise') action.target = choice.targets?.[0] ?? choice.minTo;
      await command(ctx, client, { type: 'action', turnId: `${r.handEpoch}:${g.turnId}`, action });
      receipts.humanDecisions++;
    }
    assert.equal(raw(ctx).game.bankTotal, bank, 'Roster activity cannot alter the active hand bankroll');
  }
  assert.equal(raw(ctx).game.seats.reduce((sum, p) => sum + p.stack, 0), bank);
  receipts.hands++;
}

