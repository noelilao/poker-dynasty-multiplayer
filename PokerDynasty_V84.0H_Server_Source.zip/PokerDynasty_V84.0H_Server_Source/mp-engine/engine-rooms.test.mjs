import assert from 'node:assert/strict';
import { handle } from './rooms.mjs';
import { VARIANTS, evaluate } from './cards.mjs';
import { act, legal, assertGame } from './engine.mjs';

const clone = x => JSON.parse(JSON.stringify(x));
class MemoryStore {
  rows = new Map();
  async load(code) { return this.rows.has(code) ? clone(this.rows.get(code)) : null; }
  async create(room) { if (this.rows.has(room.code)) return false; this.rows.set(room.code, clone(room)); return true; }
  async cas(room, version) { if (this.rows.get(room.code)?.revision !== version) return false; this.rows.set(room.code, clone(room)); return true; }
  async rate() { return true; }
  async prune() {}
  put(room) { this.rows.set(room.code, clone(room)); }
}
let checks = 0, requests = 0, ids = 0;
const ok = (value, message) => { assert.ok(value, message); checks++; };
const eq = (actual, expected, message) => { assert.deepEqual(actual, expected, message); checks++; };
function fixture() {
  return { store: new MemoryStore(), now: 1_000_000, clients: [] };
}
async function request(f, path, body, client = null) {
  const headers = { 'Content-Type': 'application/json' };
  if (client) headers.Authorization = `Bearer ${client.token}`;
  const response = await handle(new Request(`https://multiplayer.test${path}`, { method: 'POST', headers, body: JSON.stringify(body) }), f.store, () => f.now);
  requests++;
  const data = await response.json();
  return { status: response.status, ...data };
}
async function command(f, client, body, success = true) {
  f.now++;
  const result = await request(f, `/api/room/${client.roomCode}`, { ...body, ...(body.type !== 'poll' ? { requestId: `test_command_${++ids}` } : {}) }, client);
  if (success) eq(result.status, 200, `${body.type}: ${result.error || 'accepted'}`);
  if (result.view) client.view = result.view;
  return result;
}
async function room(variant = 'holdem_nl', humans = 2, bots = 1, options = {}) {
  const f = fixture();
  const created = await request(f, '/api/create', { name: 'Host', settings: { variant, maxSeats: humans + bots, sb: 5, bb: 10, buyin: 200, turnSeconds: 10, ...options } });
  eq(created.status, 201, 'room created');
  const host = { token: created.token, roomCode: created.roomCode, id: created.playerId, view: created.view };
  f.clients.push(host);
  for (let i = 1; i < humans; i++) {
    const joined = await request(f, '/api/join', { roomCode: host.roomCode, name: `Human${i}` });
    eq(joined.status, 200, 'human joined');
    f.clients.push({ token: joined.token, roomCode: joined.roomCode, id: joined.playerId, view: joined.view });
  }
  for (let i = 0; i < bots; i++) await command(f, host, { type: 'addBot' });
  for (const client of f.clients) await command(f, client, { type: 'ready', ready: true });
  await command(f, host, { type: 'start' });
  return f;
}
async function playerAct(f, action) {
  const host = f.clients[0], raw = await f.store.load(host.roomCode), player = raw.game.seats[raw.game.actor];
  const owner = f.clients.find(c => c.id === player.id);
  assert.ok(owner, 'current actor must be a human');
  const polled = await command(f, owner, { type: 'poll' });
  return command(f, owner, { type: 'action', turnId: polled.view.table.turnId, action });
}

// Regression: overdue bots must time out before the room tries an ordinary bot action.
for (const owes of [false, true]) {
  const f = await room();
  await playerAct(f, owes ? { type: 'raise', target: 20 } : { type: 'call' });
  await playerAct(f, { type: 'call' });
  let r = await f.store.load(f.clients[0].roomCode);
  ok(r.game.seats[r.game.actor].bot, 'bot owns pending BB decision');
  const actor = r.game.actor, before = r.game.turnId;
  await command(f, f.clients[0], { type: 'poll' }); // Arms normal bot delay.
  f.now = r.game.deadline + 70_000;
  const after = await command(f, f.clients[0], { type: 'poll' });
  r = await f.store.load(f.clients[0].roomCode);
  ok(r.game.turnId > before, 'overdue bot advances the decision');
  ok(r.game.events.some(e => e.type === 'timeout' && e.seat === actor && e.action === (owes ? 'fold' : 'check')), 'overdue bot uses authoritative timeout choice');
  eq(after.status, 200, 'overdue bot poll never becomes a rule-error loop');
  assertGame(r.game);
}

// Regression: a player leaving while owing a call does not block recovery after a long gap.
{
  const f = await room('holdem_nl', 2, 0);
  await playerAct(f, { type: 'raise', target: 20 });
  const old = await f.store.load(f.clients[0].roomCode);
  eq(old.game.actor, 1, 'guest owes the response');
  await command(f, f.clients[1], { type: 'leave' });
  f.now = old.game.deadline + 70_000;
  const response = await command(f, f.clients[0], { type: 'poll' });
  const r = await f.store.load(f.clients[0].roomCode);
  eq(r.game.phase, 'complete', 'expired leaver folds and the pot settles');
  eq(r.game.seats.reduce((n, p) => n + p.stack, 0), 400, 'leaver payout conserves both stacks');
  ok(response.view.table.events.some(e => e.type === 'timeout'), 'leaver timeout stays in public hand history');
}

// Regression: bot draw/discard deadlines use pat/default selection, never an invalid bet.
for (const variant of ['draw5', 'deuce_triple', 'badugi', 'pineapple', 'crazy_pineapple']) {
  const f = await room(variant, 2, 1), host = f.clients[0];
  const r = await f.store.load(host.roomCode);
  // Establish a valid pending card decision directly through the same authoritative
  // engine, then persist it. This avoids relying on a random bot choosing to call.
  let guard = 0;
  while (!(r.game.seats[r.game.actor]?.bot && ['draw', 'discard'].includes(r.game.phase)) && r.game.phase !== 'complete' && guard++ < 60) {
    const g = r.game, a = legal(g, g.actor), c = a.find(x => x.type === 'check') || a.find(x => x.type === 'call') || a[0];
    act(g, g.actor, { type: c.type, ...(c.type === 'draw' ? { indices: [] } : c.type === 'discard' ? { indices: [0] } : {}) }, f.now);
  }
  ok(guard < 60 && ['draw', 'discard'].includes(r.game.phase), `${variant}: pending bot card choice prepared`);
  const actor = r.game.actor, phase = r.game.phase;
  const count = r.game.seats[actor].hole.length;
  r.botTurn = null;
  f.store.put(r);
  f.now = r.game.deadline + 90_000;
  await command(f, host, { type: 'poll' });
  const after = await f.store.load(host.roomCode);
  ok(after.game.events.some(e => e.type === 'timeout' && e.seat === actor && e.action === phase), `${variant}: timeout logged for correct choice`);
  eq(after.game.seats[actor].hole.length, phase === 'discard' ? count - 1 : count, 'card count remains valid');
  assertGame(after.game);
}

// All 25 variants through the room API with two human owners and a scheduled bot.
// Several complete hands exercise bot ranges and exact Stud discrete targets.
let mixedHands = 0, botDecisions = 0, humanDecisions = 0, timedOutDecisions = 0;
let seed = 831337;
const random = () => { seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0; return seed / 4294967296; };
for (const variant of Object.values(VARIANTS)) for (let iteration = 0; iteration < 6; iteration++) {
  const f = await room(variant.id, 2, 1), host = f.clients[0];
  let steps = 0;
  while (steps++ < 250) {
    const r = await f.store.load(host.roomCode), g = r.game;
    assertGame(g);
    if (g.phase === 'complete') {
      eq(g.seats.reduce((n, p) => n + p.stack, 0), 600, `${variant.id}: mixed room preserves chips`);
      if (g.settlement.showdown) for (let i = 0; i < g.seats.length; i++) if (!g.seats[i].folded) {
        const result = evaluate(g.settings.variant, g.seats[i].hole, g.board);
        eq(g.settlement.handRanks[i].high, result.highLabel, `${variant.id}: exact showdown label`);
        if (variant.lowOnly) eq(g.settlement.handRanks[i].low, null, `${variant.id}: low-only is a single payout channel`);
      }
      mixedHands++;
      break;
    }
    const p = g.seats[g.actor];
    if (p.bot) {
      if (random() < .12) { f.now = g.deadline + 1; timedOutDecisions++; }
      else { await command(f, host, { type: 'poll' }); f.now += 700; }
      await command(f, host, { type: 'poll' });
      botDecisions++;
    } else {
      const choices = legal(g, g.actor), raise = choices.find(a => a.type === 'raise');
      let selected = choices.find(a => a.type === 'check') || choices.find(a => a.type === 'call') || choices[0];
      if (raise && random() < .18) selected = raise;
      const action = { type: selected.type };
      if (selected.type === 'raise') action.target = selected.targets ? selected.targets[Math.floor(random() * selected.targets.length)] : selected.minTo;
      if (selected.type === 'draw') action.indices = p.hole.flatMap((_, i) => random() < .7 ? [i] : []);
      if (selected.type === 'discard') action.indices = [Math.floor(random() * p.hole.length)];
      await playerAct(f, action);
      humanDecisions++;
    }
  }
  ok(steps < 250, `${variant.id}: API room hand completes`);
}

console.log(JSON.stringify({ ok: true, checks, requests, variants: Object.keys(VARIANTS).length, mixedHands, botDecisions, humanDecisions, timedOutDecisions }, null, 2));
