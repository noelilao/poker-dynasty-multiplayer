#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")"
if ! command -v node >/dev/null 2>&1; then
  echo "Install Node.js 22.13.0 or newer, then run this launcher again."
  exit 1
fi
exec node mp-engine/run-tests.mjs
