@echo off
setlocal
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Install Node.js 22.13.0 or newer, then run this launcher again.
  pause
  exit /b 1
)
node mp-engine/run-tests.mjs
set "pdExitCode=%errorlevel%"
pause
exit /b %pdExitCode%
