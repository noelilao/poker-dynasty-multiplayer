
import test from 'node:test';
import assert from 'node:assert/strict';
import {environment,create,join,poll,cmd,save,character,atMinute} from './life842-server-fixture.mjs';
import {handleCareer} from '../mp-engine/career84.mjs';
import C from '../mp-engine/life842-core.cjs';
async function setup(){const e=environment(),a=await create(e),b=await join(e,a);assert.equal((await save(e,a)).status,200);assert.equal((await save(e,b)).status,200);return{e,a,b};}
async function life(e,p,action,payload={},id){await poll(e,p);return cmd(e,p,'life842',{action,...payload,lifeSequence:(p.view.own.life842Sequence||0)+1},id);}
function state(e,p){return e.st.worlds.get(p.worldCode);}
test('V84.2 meta advertises its backend; player projections do not expose another safe or inventory',async()=>{
 const {e,a,b}=await setup();const meta=await e.call('/api/career84/meta');assert.equal(meta.data.version,'84.2.0');
 let r=await life(e,a,'buy_furniture',{kind:'safe'});assert.equal(r.status,200,r.data.error);
 r=await poll(e,b);assert.equal(r.data.view.life.furniture.length,0);assert.equal(r.data.view.life.own.safeCents,0);
 assert.equal(JSON.stringify(r.data.view).includes(a.sessionToken),false);
});
test('failed contract mutations and injected money fields do not alter server wallets or seq',async()=>{
 const {e,a,b}=await setup();const before=state(e,a).players.find(p=>p.playerUuid===a.playerUuid).wallet.balanceCents;
 let r=await life(e,a,'buy',{propertyId:'vegas~villa',balanceCents:999999999999,price:0});assert.equal(r.status,409);
 assert.equal(state(e,a).players.find(p=>p.playerUuid===a.playerUuid).wallet.balanceCents,before);
 assert.equal(state(e,a).players.find(p=>p.playerUuid===a.playerUuid).life842Sequence,0);
 r=await life(e,a,'use',{itemId:'__proto__',amount:999999999999,withdraw:true});assert.equal(r.status,409);
 assert.equal(state(e,a).players.find(p=>p.playerUuid===a.playerUuid).wallet.balanceCents,before);
});
test('CAS retries still charge one purchase; exact command replay does not charge again',async()=>{
 const {e,a}=await setup();await poll(e,a);const request={type:'life842',action:'gym_pass',lifeSequence:1,expectedRevision:a.view.world.revision,requestId:'life_842_fixed_replay'};
 e.st.failNext=3;let r=await e.call('/api/career84/world/'+a.worldCode,request,a.token);assert.equal(r.status,200,r.data.error);
 const balance=r.data.view.own.wallet.balance,seq=r.data.view.own.life842Sequence;
 r=await e.call('/api/career84/world/'+a.worldCode,request,a.token);assert.equal(r.status,200,r.data.error);assert.equal(r.data.view.own.wallet.balance,balance);assert.equal(r.data.view.own.life842Sequence,seq);
 r=await e.call('/api/career84/world/'+a.worldCode,{...request,action:'gym_join'},a.token);assert.equal(r.status,409);
});
test('durable life sequence rejects ancient replay even when generic seen cache was pruned',async()=>{
 const {e,a}=await setup();let r=await life(e,a,'gym_pass',{},'life_842_ancient');assert.equal(r.status,200);
 const w=state(e,a);w.players.find(p=>p.playerUuid===a.playerUuid).seen=[];await poll(e,a);const before=a.view.own.wallet.balance;
 r=await cmd(e,a,'life842',{action:'gym_pass',lifeSequence:1},'life_842_ancient');
 assert.equal(r.status,409);assert.equal(r.data.code,'stale_life_sequence');await poll(e,a);assert.equal(a.view.own.wallet.balance,before);
});
test('concurrent distinct commands from two tabs cannot consume one sequence twice',async()=>{
 const {e,a}=await setup();await poll(e,a);
 const base={type:'life842',action:'gym_pass',lifeSequence:1,expectedRevision:a.view.world.revision};
 const results=await Promise.all([1,2].map(i=>e.call('/api/career84/world/'+a.worldCode,{...base,requestId:'life_parallel_'+i},a.token)));
 assert.equal(results.filter(r=>r.status===200).length,1);assert.equal(results.filter(r=>r.status===409).length,1);
 await poll(e,a);assert.equal(a.view.own.wallet.balance,992);
});
test('adopted native deed and two-player lease update both wallets and escrow in one commit',async()=>{
 const {e,a,b}=await setup();const c=character(a);
 c.physicalProperties57={holdings:[{id:'native_title',owned:true,building:'home',city:'vegas',name:'Existing home',basis:1000,invested:0}]};
 assert.equal((await save(e,a,c)).status,200);
 let r=await life(e,a,'adopt_native',{nativeId:'native_title'});assert.equal(r.status,200,r.data.error);const propertyId=r.data.lifeResult.propertyId;
 r=await life(e,a,'offer',{propertyId,unit:1,targetPlayerUuid:b.playerUuid,rent:50,deposit:100,months:3,roommates:1});assert.equal(r.status,200,r.data.error);const o=r.data.lifeResult.offer;
 r=await life(e,a,'accept',{offerId:o.id});assert.equal(r.status,409);
 e.st.failNext=2;r=await life(e,b,'accept',{offerId:o.id});assert.equal(r.status,200,r.data.error);
 await poll(e,a);assert.equal(a.view.own.wallet.balance,1050);assert.equal(b.view.own.wallet.balance,850);
 const l=Object.values(state(e,a).life842.leases)[0];assert.equal(l.depositCents,10000);assert.equal(l.tenant,b.playerUuid);
});
test('workout time does not fast-forward an available peer and survives handler reload',async()=>{
 const {e,a,b}=await setup();const start=a.view.clock.minute;
 let r=await life(e,a,'workout',{kind:'cardio',source:'outdoor'});assert.equal(r.status,200,r.data.error);assert.equal(r.data.view.life.own.fitness.sessions,0);
 assert.equal(r.data.view.clock.minute,start);assert.equal(r.data.view.own.availability.life842,true);
 const restarted=await import('../mp-engine/career84.mjs?life842restart='+Date.now());
 const row=await e.call('/api/career84/world/'+a.worldCode,{type:'poll'},a.token,restarted.handleCareer);assert.equal(row.status,200);assert.equal(row.data.view.own.availability.until,start+45);
 r=await cmd(e,a,'cancel_activity');assert.equal(r.status,409);
 r=await cmd(e,b,'wait',{minutes:45,label:'Wait with training player'});assert.equal(r.status,200,r.data.error);
 await poll(e,a);assert.equal(a.view.life.own.fitness.sessions,1);assert.equal(a.view.clock.minute,start+45);
 await poll(e,a);assert.equal(a.view.life.own.fitness.sessions,1);assert.ok(a.view.own.completions.some(c=>c.completion.kind==='life842'));
});
test('native snapshot cannot acknowledge unseen household receipts or overwrite server life state',async()=>{
 const {e,a}=await setup();const c=character(a);assert.equal((await life(e,a,'gym_pass')).status,200);
 const r=await save(e,a,c);assert.equal(r.status,409);assert.equal(r.data.code,'wallet_receipts_pending');
 await poll(e,a);assert.equal(a.view.own.wallet.balance,992);
 // The caller can only project canonical life state; an altered mirror is never server authority.
 c.bankroll=992;c.multiplayerCareer84.appliedWalletIds=a.view.own.wallet.ledger.map(r=>r.id);c.life842Mirror={schema:1,fitness:{sessions:1000000}};
 const result=await save(e,a,c);assert.equal(result.status,200,result.data.error);await poll(e,a);assert.equal(a.view.life.own.fitness.sessions,0);
});
test('pending delivery and fitness persist in serialized server world without reading native mirror',async()=>{
 const {e,a}=await setup();let r=await life(e,a,'buy_furniture',{kind:'bed'});assert.equal(r.status,200);const id=r.data.lifeResult.itemId;
 const w=JSON.parse(JSON.stringify(state(e,a)));assert.equal(w.life842.furniture[id].status,'delivery');
 e.st.worlds.set(a.worldCode,w);await poll(e,a);assert.equal(a.view.life.furniture.find(f=>f.id===id).status,'delivery');
});
