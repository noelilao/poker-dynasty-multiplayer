POKER DYNASTY V84.0H — HOSTED SERVICE MAINTAINER SOURCE

STATUS: Prepared and tested locally. NOT PUBLISHED to the existing ChatGPT Site.
The downloadable HTML is updated; the public-server repair is still unverified.
The existing address remains https://poker-dynasty-multiplayer.jobilao.chatgpt.site.

PLAYERS: Use the published HTTPS website. Do not install Node, run localhost,
or start a server on a phone or PC. This archive is for the service maintainer.

WHAT IS INCLUDED
The supplied Node 22.13+ authority, original poker/Career/Life engines, original
identity and immutable checkpoint protocols, V84.0H client, and tests. The visual
update does not change world UUIDs, credential algorithms, saves, game rules or
payout authority. Both modes share the listener and existing persistent data dir.

DATA SAFETY
On Node startup, an existing rooms.sqlite is backed up via SQLite VACUUM INTO
before schema setup. The matching entry-receipt.key is included. The backup is
integrity-checked and SHA-256 recorded under DATA_DIR/backups/pre-V84.0H-... .
Startup fails rather than migrating when a usable backup cannot be made. Retain
PD83_DATA_DIR and the original receipt key; never generate a replacement key
for an existing database. No automatic pruning of backup archives was added.
Use one authority process per database and the provider's persistent volume.
A platform HTTPS reverse proxy must expose the same origin for client and APIs.

CHATGPT SITE / WORKER DEPLOYMENT BLOCKER
The existing Site's publisher and current Worker source were unavailable in this
session. This SQLite/Node archive is NOT a drop-in D1/R2 migration. Its startup
backup code does not back up the production Site's D1 or R2 bindings. Recover the
existing Site source/bindings via the authorized publisher before adapting or
publishing. Keep the existing URL, D1 tables, R2 snapshot references and keys.
Do not create a replacement Site or overwrite the database with test data.

RELEASE VALIDATION
Use the attached verification JSON. npm test runs the packaged source suites;
python tests/entry_http_tests.py runs isolated HTTP/SQLite/restart tests (httpx
required for that optional test runner). This is maintainer-side validation, not
an instruction for players to install or run anything.
After authorized deployment, verify public /api/meta and /api/career84/meta,
then create/join two independent native Careers, save/restore checkpoints,
reauthenticate, and play shared hands and ordinary rooms over HTTPS.
No production data or production credentials are included here.
