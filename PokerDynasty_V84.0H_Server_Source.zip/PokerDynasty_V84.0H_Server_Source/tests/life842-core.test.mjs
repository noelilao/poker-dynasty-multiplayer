
import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture,C,minute,assertHomeGame} from './life842-fixture.mjs';
const iso=m=>new Date(m*60000).toISOString().slice(0,10);
test('calendar month anchors retain Jan 31 and handle leap years',()=>{
 assert.equal(iso(C.addMonths(minute('2026-01-31'),1)),'2026-02-28');
 assert.equal(iso(C.addMonths(minute('2026-01-31'),2)),'2026-03-31');
 assert.equal(iso(C.addMonths(minute('2024-01-31'),1)),'2024-02-29');
 assert.equal(iso(C.addMonths(minute('2024-02-29'),12)),'2025-02-28');
});
test('own titles, stale purchase, city and prototype tampering are rejected atomically',()=>{
 const f=fixture(),start=f.balance('a'),r=f.buy();assert.equal(f.balance('a'),start-1800000);assert.equal(f.w.life842.properties[r].owner,'a');
 for(const [action,args]of[['buy',{propertyId:r,propertyVersion:0}],['buy',{propertyId:'__proto__'}],['buy',{propertyId:'constructor~cottage'}],['sell_npc',{propertyId:r}],['mortgage_pay',{propertyId:r,amount:1}]]){
  const before=JSON.stringify(f.w);assert.throws(()=>f.run('b',action,args));assert.equal(JSON.stringify(f.w),before);
 }
});
test('first rent transfers between human wallets and deposit is escrow, not landlord income',()=>{
 const f=fixture();f.buy();const a=f.balance('a'),b=f.balance('b'),l=f.lease();
 assert.equal(f.balance('a')-a,20000);assert.equal(b-f.balance('b'),60000);assert.equal(l.depositCents,40000);
 assert.equal(f.balance('a')+f.balance('b')+l.depositCents,a+b);assert.equal(f.q('a').home,null);assert.equal(f.q('b').home.leaseId,l.id);
});
test('monthly rent survives serialized restart and repeated ticks without double charging',()=>{
 let f=fixture();f.buy();const l=f.lease(),before=f.balance('b');f.advanceTo(l.nextDue);const after=f.balance('b');
 assert.equal(before-after,20000);const snapshot=JSON.parse(JSON.stringify(f.w));C.tick(snapshot,f.ctx);assert.deepEqual(snapshot.players,f.w.players);
 f.tick();f.tick();assert.equal(f.balance('b'),after);assert.equal(f.w.life842.leases[l.id].paidCents,40000);
});
test('same rental unit cannot be accepted twice; only recipient may accept',()=>{
 const f=fixture();f.buy();const b=f.offer(),c=f.offer('a','c');assert.throws(()=>f.run('c','accept',{offerId:b.id}),/invited/);f.run('b','accept',{offerId:b.id});
 const before=JSON.stringify(f.w);assert.throws(()=>f.run('c','accept',{offerId:c.id}),/changed/);assert.equal(JSON.stringify(f.w),before);
});
test('counteroffer replaces old terms, cannot be accepted by original recipient or replayed',()=>{
 const f=fixture();f.buy();const o=f.offer(),c=f.run('b','counter',{offerId:o.id,rent:175,deposit:175,months:6,roommates:1}).offer;
 assert.throws(()=>f.run('b','accept',{offerId:o.id}));f.run('a','accept',{offerId:c.id});const l=Object.values(f.w.life842.leases)[0];
 assert.equal(l.rentCents,17500);assert.equal(l.depositCents,17500);assert.throws(()=>f.run('a','accept',{offerId:c.id}));
});
test('offer expiration, deposit bounds and unsigned rent changes are rejected',()=>{
 const f=fixture();f.buy();assert.throws(()=>f.offer('a','b','vegas~cottage',{deposit:601}));
 assert.throws(()=>f.offer('a','a'));const o=f.offer();f.advanceTo(o.expires);assert.throws(()=>f.run('b','accept',{offerId:o.id}));
 assert.equal(Object.keys(f.w.life842.leases).length,0);
});
test('renewal fixes existing rent until boundary then collects new signed rent and deposit difference',()=>{
 const f=fixture();f.buy();const l=f.lease('a','b','vegas~cottage',{months:1}),o=f.offer('b','a',l.propertyId,{kind:'renewal',leaseId:l.id,rent:250,deposit:500,months:3});
 f.run('a','accept',{offerId:o.id});assert.equal(f.w.life842.leases[l.id].rentCents,20000);const before=f.balance('b');
 f.advanceTo(l.end);assert.equal(before-f.balance('b'),35000);assert.equal(f.w.life842.leases[l.id].rentCents,25000);assert.equal(f.w.life842.leases[l.id].depositCents,50000);assert.equal(f.w.life842.leases[l.id].status,'active');
 f.tick();assert.equal(before-f.balance('b'),35000);
});
test('lease expiry refunds unused deposit exactly once and releases property access',()=>{
 const f=fixture();f.buy();const l=f.lease('a','b','vegas~cottage',{months:1}),before=f.balance('b');
 f.advanceTo(l.end);assert.equal(f.balance('b')-before,40000);assert.equal(f.q('b').home,null);assert.equal(f.w.life842.leases[l.id].status,'ended');
 f.tick();assert.equal(f.balance('b')-before,40000);
});
test('arrears retain tenancy, cure clears notice, eviction requires full notice',()=>{
 const f=fixture();f.buy();const l=f.lease(),due=l.nextDue;f.setBalance('b',0);f.advanceTo(due);
 assert.equal(f.w.life842.leases[l.id].status,'active');assert.equal(f.w.life842.leases[l.id].arrearsCents,20000);
 assert.throws(()=>f.run('a','evict',{leaseId:l.id}));f.run('a','lease_notice',{leaseId:l.id});assert.throws(()=>f.run('a','evict',{leaseId:l.id}));
 f.setBalance('b',20000);f.run('b','pay_rent',{leaseId:l.id});assert.equal(f.w.life842.leases[l.id].status,'active');
 assert.equal(f.w.life842.leases[l.id].noticeAt,null);assert.equal(f.w.life842.leases[l.id].arrearsCents,0);
});
test('eviction uses deposit for arrears, refunds remainder once and stores personal furniture',()=>{
 const f=fixture();f.buy();const l=f.lease(),bed=f.item('b','bed');f.deliver();f.place('b',bed,l.propertyId,'Bedroom');
 f.setBalance('b',0);f.advanceTo(l.nextDue);f.run('a','lease_notice',{leaseId:l.id});f.advanceTo(f.w.clock.minute+7*C.DAY);
 const a=f.balance('a');f.run('a','evict',{leaseId:l.id});assert.equal(f.balance('b'),20000);assert.equal(f.balance('a')-a,20000);
 assert.equal(f.w.life842.furniture[bed].status,'stored');assert.equal(f.w.life842.leases[l.id].depositCents,0);assert.throws(()=>f.run('a','evict',{leaseId:l.id}));
});
test('roommate share cannot exceed primary rent; shared access expires with primary lease',()=>{
 const f=fixture();f.buy();const l=f.lease(),o=f.offer('b','c',l.propertyId,{kind:'roommate',leaseId:l.id,rent:100,deposit:100,months:6});
 f.run('c','accept',{offerId:o.id});const child=Object.values(f.w.life842.leases).at(-1);
 assert.equal(child.end,l.end);assert.equal(child.landlord,'b');assert.equal(C.access(f.w,f.p('c'),f.w.life842.properties[l.propertyId],1),true);
 f.advanceTo(l.end);assert.equal(f.w.life842.leases[child.id].status,'ended');assert.equal(f.q('c').home,null);
});
test('sublease permission is enforced; another player cannot negotiate tenant rights',()=>{
 const f=fixture();f.buy();const l=f.lease('a','b','vegas~cottage',{allowSublet:false,roommates:0});
 for(const kind of ['sublease','roommate'])assert.throws(()=>f.offer('b','c',l.propertyId,{kind,leaseId:l.id,rent:100,deposit:0}));
 assert.throws(()=>f.offer('c','a',l.propertyId,{kind:'renewal',leaseId:l.id,rent:100,deposit:0}));
});
test('sale and sale counteroffers transfer one deed and preserve escrow and lease parties',()=>{
 const f=fixture();const r=f.buy(),l=f.lease();const a=f.balance('a'),c=f.balance('c');
 const o=f.offer('a','c',r,{kind:'sale',price:20000}),co=f.run('c','counter',{offerId:o.id,price:19000}).offer;
 f.run('a','accept',{offerId:co.id});assert.equal(f.w.life842.properties[r].owner,'c');assert.equal(f.balance('a')-a,1900000);assert.equal(c-f.balance('c'),1900000);
 assert.equal(f.w.life842.leases[l.id].landlord,'c');assert.equal(f.w.life842.leases[l.id].depositCents,40000);
});
test('mortgage starts with down payment, amortizes interest/principal and supports payoff',()=>{
 const f=fixture(),before=f.balance('a'),r=f.buy('a','cottage',{mortgage:true,downPercent:20,months:120}),m=f.w.life842.properties[r].mortgage;
 assert.equal(before-f.balance('a'),360000);assert.equal(m.principalCents,1440000);const payment=m.paymentCents;
 f.advanceTo(m.nextDue);const after=f.w.life842.properties[r].mortgage;assert.equal(after.principalCents,1440000+7200-payment);
 f.run('a','mortgage_pay',{propertyId:r,amount:C.mortgageDebt(after)/100});assert.equal(f.w.life842.properties[r].mortgage,null);
});
test('mortgage default has 90-day delinquency plus 30-day notice, not instant repossession',()=>{
 const f=fixture(),r=f.buy('a','cottage',{mortgage:true}),m=f.w.life842.properties[r].mortgage,first=m.nextDue;
 f.setBalance('a',0);f.advanceTo(first+89*C.DAY);assert.equal(f.w.life842.properties[r].owner,'a');assert.equal(f.w.life842.properties[r].mortgage.noticeAt,null);
 f.advanceTo(first+90*C.DAY);assert.notEqual(f.w.life842.properties[r].mortgage.noticeAt,null);
 f.advanceTo(first+119*C.DAY);assert.equal(f.w.life842.properties[r].owner,'a');
 f.advanceTo(first+120*C.DAY);assert.equal(f.w.life842.properties[r].owner,'npc');assert.equal(f.w.life842.properties[r].mortgage,null);
});
test('14-day renovation respects time and preserves signed rent',()=>{
 const f=fixture(),r=f.buy(),l=f.lease();f.run('a','renovate',{propertyId:r});const until=f.w.life842.properties[r].work.until;
 f.advanceTo(until-1);assert.ok(f.w.life842.properties[r].work);f.advanceTo(until);assert.equal(f.w.life842.properties[r].work,null);assert.equal(f.w.life842.properties[r].renovations,1);assert.equal(f.w.life842.leases[l.id].rentCents,20000);
});
test('native deed adoption retains basis without a second debit and cannot repeat',()=>{
 const f=fixture();f.ctx.nativeTitles=[{id:'native_1',city:'vegas',name:'Saved apartment',kind:'residence',valueCents:500000}];const start=f.balance('a'),r=f.run('a','adopt_native',{nativeId:'native_1'});
 assert.equal(f.balance('a'),start);assert.equal(f.w.life842.properties[r.propertyId].nativeId,'native_1');assert.throws(()=>f.run('a','adopt_native',{nativeId:'native_1'}));
});
test('furniture order is not usable until delivery and saved placement survives serialization',()=>{
 const f=fixture(),r=f.buy(),bed=f.item('a','bed');assert.throws(()=>f.place('a',bed,r,'Bedroom'));
 f.deliver();f.place('a',bed,r,'Bedroom',1,1,90);assert.deepEqual(f.w.life842.furniture[bed].place,{propertyId:r,unit:1,room:'Bedroom',x:1,y:1,rotation:90});
 const saved=C.cp(f.w);C.validate(saved);assert.equal(saved.life842.furniture[bed].status,'placed');
});
test('furniture collision, off-map, doorway, wrong room and unauthorized edits reject without state loss',()=>{
 const f=fixture(),r=f.buy(),bed=f.item('a','bed'),bed2=f.item('a','bed');f.deliver();f.place('a',bed,r,'Bedroom',0,0);
 for(const [who,itemId,room,x,y,rotation]of[['a',bed2,'Bedroom',0,0,0],['a',bed2,'Bedroom',11,8,0],['a',bed2,'Bedroom',5,7,0],['a',bed2,'Kitchen',1,1,0],['a',bed2,'Bedroom',4,1,45],['b',bed,'Bedroom',4,1,0]]){
  const before=JSON.stringify(f.w);assert.throws(()=>f.place(who,itemId,r,room,x,y,rotation));assert.equal(JSON.stringify(f.w),before);
 }
});
test('furniture shipping stores placement, locks in-transit sale, preserves item ownership',()=>{
 const f=fixture(),r=f.buy(),bed=f.item('a','bed');f.deliver();f.place('a',bed,r,'Bedroom');f.run('a','ship',{itemId:bed,toCity:'manila'});assert.equal(f.w.life842.furniture[bed].place,null);
 assert.throws(()=>f.run('a','sell_furniture',{itemId:bed}));f.advanceTo(f.w.life842.furniture[bed].arriveAt);f.p('a').location.city='manila';const before=f.balance('a'),paid=f.w.life842.furniture[bed].paidCents;
 f.run('a','sell_furniture',{itemId:bed});assert.equal(f.balance('a')-before,Math.floor(paid*.5));assert.throws(()=>f.run('a','sell_furniture',{itemId:bed}));
});
test('safe money is private, conserved, owner-authorized and not minted by replay',()=>{
 const f=fixture(),r=f.buy('a','rowhouse'),safe=f.item('a','safe');f.deliver();f.place('a',safe,r,'Study');const start=f.balance('a');
 f.run('a','use',{itemId:safe,amount:100});assert.equal(f.q('a').safeCents,10000);assert.equal(f.balance('a'),start-10000);
 assert.equal(f.view('b').own.safeCents,0);assert.equal(f.view('b').furniture.length,0);assert.throws(()=>f.run('b','use',{itemId:safe,amount:100,withdraw:true}));
 f.run('a','use',{itemId:safe,amount:100,withdraw:true});assert.equal(f.balance('a'),start);assert.equal(f.q('a').safeCents,0);assert.throws(()=>f.run('a','use',{itemId:safe,amount:1,withdraw:true}));
});
test('fridge and stove require actual food, shared cooking clock and meal cooldown',()=>{
 const f=fixture(),r=f.buy(),fridge=f.item('a','fridge'),stove=f.item('a','stove');f.deliver();f.place('a',fridge,r,'Kitchen',0,0);f.place('a',stove,r,'Kitchen',3,0);
 assert.throws(()=>f.run('a','use',{itemId:stove}));f.run('a','use',{itemId:fridge});assert.equal(f.q('a').food,8);
 f.run('a','use',{itemId:stove});assert.equal(f.q('a').food,6);assert.equal(f.p('a').availability.until-f.w.clock.minute,30);
 f.advanceTo(f.p('a').availability.until);assert.throws(()=>f.run('a','use',{itemId:stove}),/four/);
});
test('home bed schedules eight hours and completes once across restart',()=>{
 const f=fixture(),r=f.buy(),bed=f.item('a','bed');f.deliver();f.place('a',bed,r,'Bedroom');f.q('a').fitness.fatigue=70;f.run('a','use',{itemId:bed});
 const end=f.p('a').availability.until;assert.equal(end-f.w.clock.minute,480);assert.equal(f.q('a').effects.rest,0);
 f.advanceTo(end);assert.equal(f.q('a').effects.rest,1);assert.equal(f.q('a').lastRestKind,'sleep');f.tick();assert.equal(f.q('a').effects.rest,1);
});
test('membership opt-in renewal, missed renewal lapse and paid access on cancellation',()=>{
 const f=fixture();f.run('a','gym_join',{autoRenew:true});const next=f.q('a').membership.paidUntil,before=f.balance('a');
 f.advanceTo(next);assert.equal(before-f.balance('a'),4500);f.run('a','gym_cancel');assert.equal(f.q('a').membership.active,true);
 f.advanceTo(f.q('a').membership.paidUntil);assert.equal(f.q('a').membership.active,false);
 f.run('a','gym_join',{autoRenew:true});f.setBalance('a',0);f.advanceTo(f.q('a').membership.paidUntil);assert.equal(f.q('a').membership.lapsed,true);assert.equal(f.balance('a'),0);
});
test('workout rewards only follow completion; restart, duplicate tick and rapid training cannot farm gains',()=>{
 const f=fixture();assert.throws(()=>f.run('a','workout',{kind:'strength'}));f.run('a','gym_pass');f.run('a','workout',{kind:'strength'});
 const end=f.p('a').availability.until;assert.equal(f.q('a').fitness.sessions,0);assert.throws(()=>f.run('a','workout',{kind:'strength'}));
 f.advanceTo(end-1);assert.equal(f.q('a').fitness.sessions,0);f.advanceTo(end);assert.equal(f.q('a').fitness.sessions,1);assert.equal(f.q('a').fitness.strength,20.55);
 f.tick();assert.equal(f.q('a').fitness.sessions,1);assert.throws(()=>f.run('a','workout',{kind:'strength'}),/recovery/);
});
test('home workout requires placed corresponding equipment, outdoor alternatives remain free',()=>{
 const f=fixture(),r=f.buy('a','villa'),weights=f.item('a','weights');f.deliver();assert.throws(()=>f.run('a','workout',{kind:'strength',source:'home'}));
 f.place('a',weights,r,'Gym');f.run('a','workout',{kind:'strength',source:'home'});f.advanceTo(f.p('a').availability.until);assert.equal(f.q('a').fitness.sessions,1);
 f.advanceTo(f.w.clock.minute+18*60);const before=f.balance('a');f.run('a','workout',{kind:'cardio',source:'outdoor'});f.advanceTo(f.p('a').availability.until);assert.equal(f.balance('a'),before);
});
test('variant, housing, gym and electronic furnishings follow explicit era gates',()=>{
 const f=fixture('1829-03-01T12:00:00Z');for(const p of f.w.players)p.location.city='manila';f.w.settings.startingCity='manila';
 assert.throws(()=>f.buy('a','penthouse'));assert.throws(()=>f.item('a','computer'));assert.throws(()=>f.run('a','gym_pass'));
 f.run('a','workout',{kind:'cardio',source:'outdoor'});f.advanceTo(f.p('a').availability.until);assert.equal(f.q('a').fitness.sessions,1);
});
test('live tournament, pause and live home table block life mutations',()=>{
 const f=fixture();f.w.clock.paused=true;assert.throws(()=>f.run('a','gym_pass'));f.w.clock.paused=false;
 f.w.tournaments.x={status:'running',participants:{a:{status:'active'}}};assert.throws(()=>f.run('a','gym_pass'));delete f.w.tournaments.x;
 const r=f.buy('a','rowhouse'),table=f.item('a','poker_table');f.deliver();f.place('a',table,r);
 const g=f.home('a','create',{itemId:table,bb:2,buyin:100,maxSeats:6}).id;f.home('a','join',{gameId:g});assert.throws(()=>f.run('a','gym_pass'));
 f.home('a','leave',{gameId:g});f.run('a','gym_pass');
});
test('home cash game: two humans, legal turns, private cards, conservation, safe leave and cash-out',()=>{
 const f=fixture(),r=f.buy('a','rowhouse'),item=f.item('a','poker_table');f.deliver();f.place('a',item,r);const g=f.home('a','create',{itemId:item,bb:2,buyin:100,maxSeats:6}).id,initial=f.balance('a')+f.balance('b');
 f.home('a','join',{gameId:g});f.home('b','join',{gameId:g});f.touch();f.home('a','start',{gameId:g});assertHomeGame(f.w.life842.games[g]);
 const view=f.homeViews('a')[0].roomView;assert.equal(view.homeGame.chipValue,.01);assert.ok(view.table.seats.every(s=>s.id==='a'||!(s.cards||[]).some(c=>c&&c!=='??')));
 f.home('b','leave',{gameId:g});assert.equal(f.w.life842.games[g].members.b.seated,true);
 let steps=0;while(f.w.life842.games[g].game.phase!=='complete'&&steps++<200){const q=f.w.life842.games[g],s=q.game.seats[q.game.actor];const v=f.homeViews(s.id)[0].roomView;const legal=v.table.legal;const move=legal.includes('check')?{type:'check'}:legal.includes('call')?{type:'call'}:{type:'fold'};
  f.home(s.id,'act',{gameId:g,turnId:v.table.turnId,move});
 }
 assert.ok(steps<200);f.home('a','close',{gameId:g});assert.equal(f.balance('a')+f.balance('b'),initial);assertHomeGame(f.w.life842.games[g]);assert.equal(f.w.life842.games[g].status,'closed');
});
