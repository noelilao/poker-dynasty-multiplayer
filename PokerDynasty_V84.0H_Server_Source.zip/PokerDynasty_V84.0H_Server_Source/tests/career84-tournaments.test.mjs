import test from 'node:test';
import assert from 'node:assert/strict';
import { handleTournament, tickTournaments, tournamentViews, tournamentBlockers, tournamentNextEvent, assertTournament, tournamentMetadata, TOURNAMENT_LIMITS } from '../mp-engine/career84-tournaments.mjs';
import { assertGame, legal } from '../mp-engine/engine.mjs';
import { VARIANTS, createDeck } from '../mp-engine/cards.mjs';
import { tournamentEraGate, legendEraGate, WORLD_CITIES, LEGEND_ERAS } from '../mp-engine/career84-world-policy.mjs';
import { legendProfile } from '../mp-engine/legend-profiles.mjs';

const EPOCH=Date.UTC(2026,9,7,12),MINUTE=EPOCH/60000;
const clone=x=>JSON.parse(JSON.stringify(x));
function fixture(count=4,year=2026){
 const w={schema:1,version:'84.1.0',worldUuid:'world-test',worldCode:'ABCDEFGH',worldName:'Test World',revision:1,expiresAt:EPOCH+1e12,hostPlayerUuid:'human_0',seed:'test-seed',settings:{startingCity:'vegas'},clock:{minute:Date.UTC(year,9,7,12)/60000,paused:false,pauseReason:null},players:[],tournaments:{},events:[]};
 for(let i=0;i<count;i++)w.players.push({playerUuid:`human_${i}`,name:`Human ${i}`,location:{city:'vegas'},status:'active',lastSeen:EPOCH,availability:null,blocker:null,tournaments:{},wallet:{balanceCents:1000000,revision:0,ledger:[]}});
 const h={fail(message,status=400,code='rule'){const e=new Error(message);e.status=status;e.code=code;throw e;},event(w,type,message,at){w.events.push({type,message,at});},connected:(p,now)=>!!p&&p.status!=='removed'&&now-p.lastSeen<60000,
  debit:async(w,p,amount,reason,ref,now)=>money(p,-amount,reason,ref,now),credit:async(w,p,amount,reason,ref,now)=>money(p,amount,reason,ref,now)};
 function money(p,amount,reason,ref,now){if(p.wallet.ledger.some(x=>x.ref===ref))return;const change=Math.round(amount*100);if(p.wallet.balanceCents+change<0)h.fail('Insufficient bankroll',409,'insufficient_funds');p.wallet.balanceCents+=change;p.wallet.revision++;p.wallet.ledger.push({ref,amount,reason,at:now});}
 return{w,h,now:EPOCH};
}
function online(f,now=f.now){for(const p of f.w.players)p.lastSeen=now;}
async function make(f,{field=f.w.players.length,maxSeats=Math.min(6,field),variant='holdem_nl',humans=f.w.players.length,...settings}={}){
 await handleTournament(f.w,f.w.players[0],{type:'tournament_create',tournamentId:'tournament_test',name:'Shared Test',settings:{variant,maxSeats,fieldSize:field,startingStack:200,sb:1,bb:2,buyIn:10,blindEvery:10,levelsPerDay:8,breakEveryLevels:0,...settings}},f.now,f.h);
 const t=f.w.tournaments.tournament_test;
 for(const p of f.w.players.slice(0,humans))await handleTournament(f.w,p,{type:'tournament_join',tournamentId:t.id,stack:999999999,seat:99,tableId:'client-invention'},f.now,f.h);
 await handleTournament(f.w,f.w.players[0],{type:'tournament_start',tournamentId:t.id},f.now,f.h);
 return t;
}
async function action(f,t,tb,choice){
 const p=f.w.players.find(p=>p.playerUuid===tb.game.seats[tb.game.actor]?.id);assert.ok(p,'fixture actor is human');p.lastSeen=f.now;
 const rv=tournamentViews(f.w,p.playerUuid,f.now).find(x=>x.id===t.id).roomView;
 return handleTournament(f.w,p,{type:'tournament_action',tournamentId:t.id,tableId:tb.id,turnId:rv.table.turnId,action:choice},f.now,f.h);
}
function passive(g){const all=legal(g,g.actor),draw=all.find(a=>['draw','discard'].includes(a.type));if(draw)return{type:draw.type,indices:draw.type==='discard'?[g.seats[g.actor].hole.length-1]:[]};return{type:all.some(a=>a.type==='check')?'check':'call'};}
async function finishTable(f,t,tb,aggressive=false){
 let guard=0;
 while(tb.game.phase!=='complete'){
  assert.ok(++guard<200,'hand finishes within bounded legal decisions');
  const all=legal(tb.game,tb.game.actor),raise=aggressive&&all.find(a=>a.type==='raise');
  await action(f,t,tb,raise?{type:'raise',target:raise.maxTo}:passive(tb.game));f.now++;
 }
 return guard;
}
function swapCard(g,target,index,text){
 const arrays=[g.deck,g.discards,g.burned,g.board,...g.seats.map(p=>p.hole)];
 for(const a of arrays){const at=a.findIndex(c=>c.text===text);if(at>=0){[a[at],target[index]]=[target[index],a[at]];return;}}
 throw Error('Fixture card missing: '+text);
}
function rigHoldem(g){
 g.seats.forEach((p,i)=>{swapCard(g,p.hole,0,['A♠','K♠','Q♠'][i]);swapCard(g,p.hole,1,['A♥','K♥','Q♥'][i]);});
 const next=['J♣','2♣','3♦','7♥','T♣','9♠','8♣','4♦'];next.forEach((c,i)=>swapCard(g,g.deck,g.deck.length-1-i,c));assertGame(g);
}

test('native chronology catalog has 256 cities and rejects early/unknown/visit-only tournaments',async()=>{
 assert.equal(Object.keys(WORLD_CITIES).length,256);
 assert.equal(tournamentEraGate('holdem_nl','hongkong',MINUTE).ok,false);
 assert.equal(tournamentEraGate('holdem_nl','vegas',Date.UTC(1970,6,1)/60000).ok,false);
 assert.equal(tournamentEraGate('holdem_nl','vegas',Date.UTC(1971,6,1)/60000).ok,true);
 assert.equal(tournamentEraGate('holdem_nl','manila',Date.UTC(1917,6,1)/60000).ok,false);
 assert.equal(tournamentEraGate('holdem_nl','osaka',MINUTE).ok,false);
 assert.equal(tournamentEraGate('early20','us_la_neworleans',Date.UTC(1830,1,1)/60000).ok,false);
 assert.equal(tournamentEraGate('plo6','vegas',Date.UTC(2019,6,1)/60000).ok,false);
 assert.equal(tournamentEraGate('plo6','vegas',MINUTE).ok,true);
 const f=fixture(1,1917);await assert.rejects(make(f,{field:2,humans:1}),e=>e.code==='tournament_era');assert.deepEqual(f.w.tournaments,{});
});

test('Career Legends use all 78 exact native active-year ranges without restricting Quick Match',async()=>{
 assert.equal(Object.keys(LEGEND_ERAS).length,78);
 assert.deepEqual(LEGEND_ERAS.philivey,{startYear:1998,endYear:2026});
 assert.deepEqual(LEGEND_ERAS.doylebrunson,{startYear:1955,endYear:2023});
 assert.deepEqual(LEGEND_ERAS.bennyglaser,{startYear:2015,endYear:2026});
 const meta=tournamentMetadata();assert.equal(meta.legends.length,78);assert.equal(meta.allowFantasyLegends,false);
 assert.ok(meta.legends.every(p=>p.startYear===LEGEND_ERAS[p.id].startYear&&p.endYear===LEGEND_ERAS[p.id].endYear&&!p.fantasy));
 assert.ok(legendProfile('god_of_gamblers')?.fantasy,'Quick Match keeps its canonical fantasy roster');
 const settings={fieldSize:2,maxSeats:2,startingStack:200,sb:1,bb:2,buyIn:0};
 for(const [year,id]of [[1971,'philivey'],[1997,'philivey'],[2027,'philivey'],[2024,'doylebrunson'],[2014,'bennyglaser'],[2026,'god_of_gamblers']]){
  const f=fixture(1,year);
  await assert.rejects(handleTournament(f.w,f.w.players[0],{type:'tournament_create',settings,bots:[{legendId:id,startYear:1,endYear:9998}]},f.now,f.h),e=>e.code==='tournament_legend_era');
  assert.deepEqual(f.w.tournaments,{},'invalid selection never creates registration or charges an entry');
 }
 for(const [year,id]of [[1971,'doylebrunson'],[1998,'philivey'],[2026,'philivey'],[2023,'doylebrunson'],[2015,'bennyglaser']]){
  assert.equal(legendEraGate(id,year).ok,true);
  const f=fixture(1,year),p=f.w.players[0];
  await handleTournament(f.w,p,{type:'tournament_create',tournamentId:'era_boundary',settings,bots:[{legendId:id}]},f.now,f.h);
  await handleTournament(f.w,p,{type:'tournament_join',tournamentId:'era_boundary'},f.now,f.h);
  await handleTournament(f.w,p,{type:'tournament_start',tournamentId:'era_boundary'},f.now,f.h);
  const t=f.w.tournaments.era_boundary,legend=Object.values(t.participants).find(p=>p.kind==='legend');
  assert.equal(legend.legendId,id);assert.equal(legend.profile.year,year);assertTournament(t);
 }
});

test('scheduled and legacy registrations cannot seat an out-of-era Legend across a year boundary',async()=>{
 const settings={fieldSize:2,maxSeats:2,startingStack:200,sb:1,bb:2,buyIn:0};
 // The announced event year, not the current form year, controls creation.
 const before=fixture(1,1997);before.w.clock.minute=Date.UTC(1997,11,31,23,30)/60000;
 await handleTournament(before.w,before.w.players[0],{type:'tournament_create',tournamentId:'scheduled_era',settings,bots:[{legendId:'philivey'}],startMinute:Date.UTC(1998,0,1)/60000},before.now,before.h);
 assert.equal(before.w.tournaments.scheduled_era.year,1998);
 const after=fixture(1,2026);after.w.clock.minute=Date.UTC(2026,11,31,23,30)/60000;
 await assert.rejects(handleTournament(after.w,after.w.players[0],{type:'tournament_create',settings,bots:[{legendId:'philivey'}],startMinute:Date.UTC(2027,0,1)/60000},after.now,after.h),e=>e.code==='tournament_legend_era');
 // A permitted late start uses the actual starting year and keeps the seat
 // funded, substituting a generated opponent with a visible system notice.
 await handleTournament(after.w,after.w.players[0],{type:'tournament_create',tournamentId:'late_start_era',settings,bots:[{legendId:'philivey'}]},after.now,after.h);
 await handleTournament(after.w,after.w.players[0],{type:'tournament_join',tournamentId:'late_start_era'},after.now,after.h);
 after.w.clock.minute=Date.UTC(2027,0,1)/60000;
 await handleTournament(after.w,after.w.players[0],{type:'tournament_start',tournamentId:'late_start_era'},after.now,after.h);
 const late=after.w.tournaments.late_start_era;assert.equal(late.year,2027);
 assert.ok(Object.values(late.participants).every(p=>p.kind!=='legend'&&p.profile.year===2027));
 assert.ok(late.chat.some(m=>m.text.includes('unavailable in 2027')));assertTournament(late);
 const old=fixture(1,1971),p=old.w.players[0];
 await handleTournament(old.w,p,{type:'tournament_create',tournamentId:'legacy_selection',settings,autoStart:true},old.now,old.h);
 const legacy=old.w.tournaments.legacy_selection;legacy.botChoices=[{legendId:'philivey'}];
 await handleTournament(old.w,p,{type:'tournament_join',tournamentId:legacy.id},old.now,old.h);
 await tickTournaments(old.w,old.now,old.h);
 assert.equal(legacy.status,'running');assert.ok(Object.values(legacy.participants).every(p=>p.kind!=='legend'));
 assert.ok(legacy.chat.some(m=>m.text.includes('unavailable in 1971')));assertTournament(legacy);
});

test('server registration ignores invented stacks/seats; canonical Legends and all private projections are preserved',async()=>{
 const f=fixture(2),p=f.w.players[0];
 await handleTournament(f.w,p,{type:'tournament_create',tournamentId:'tournament_test',name:'Mixed Legends',settings:{fieldSize:6,maxSeats:6,startingStack:500,sb:2,bb:4,buyIn:20},bots:[{legendId:'philivey',name:'Forged name',vpip:100}]},f.now,f.h);
 const t=f.w.tournaments.tournament_test;
 for(const human of f.w.players){await handleTournament(f.w,human,{type:'tournament_join',tournamentId:t.id,stack:1e12,seat:99,tableId:'forged'},f.now,f.h);assert.equal(t.participants[human.playerUuid].stack,500);assert.equal(t.participants[human.playerUuid].tableId,null);}
 const balance=p.wallet.balanceCents;await handleTournament(f.w,p,{type:'tournament_join',tournamentId:t.id,stack:1e12},f.now,f.h);assert.equal(p.wallet.balanceCents,balance);
 await handleTournament(f.w,p,{type:'tournament_start',tournamentId:t.id},f.now,f.h);
 const ivey=Object.values(t.participants).find(x=>x.legendId==='philivey');assert.equal(ivey.name,'Phil Ivey');assert.equal(ivey.aiProfile.vpip,29);assert.equal(ivey.profile.year,2026);
 const rv=tournamentViews(f.w,p.playerUuid,f.now)[0].roomView;
 assert.equal(rv.table.seats.find(x=>x.id===p.playerUuid).cards.filter(Boolean).length,2);
 assert.ok(rv.table.seats.filter(x=>x.id!==p.playerUuid).every(x=>x.cards.every(c=>c===null)));
 assert.equal(JSON.stringify(rv).includes('"deck"'),false);assert.equal(rv.settings.allowCheats,false);assert.equal(rv.settings.allowRebuys,false);
 assert.equal(t.totalChips,3000);assertTournament(t);
 await assert.rejects(handleTournament(f.w,p,{type:'tournament_progress',tournamentId:t.id,stack:1e12,complete:true,barrier:{type:'day',value:99}},f.now,f.h),e=>e.code==='server_tournament_authority');
});

test('all-table barrier retains distinct stacks and cannot start Day 2 before the last table and scheduled world time',async()=>{
 const f=fixture(4),t=await make(f,{field:4,maxSeats:2,blindEvery:1,levelsPerDay:1});
 const [a,b]=Object.values(t.tables);await finishTable(f,t,a);await tickTournaments(f.w,f.now,f.h);
 assert.equal(a.game.phase,'complete');assert.notEqual(b.game.phase,'complete');assert.equal(t.waitingForTables,true);assert.equal(t.dayNo,1);assert.equal(t.blindLevel,1);assert.equal(t.readyAt,null);
 await finishTable(f,t,b);assert.equal(t.status,'day_break');assert.equal(t.dayNo,1);assert.equal(t.pendingDayNo,2);assert.equal(t.blindLevel,2);
 const stacks=Object.fromEntries(Object.values(t.participants).map(p=>[p.id,p.stack]));assert.equal(Object.values(stacks).reduce((a,b)=>a+b),800);
 const next=tournamentNextEvent(f.w);assert.equal(next,t.resumeMinute);f.now+=20000;online(f);await tickTournaments(f.w,f.now,f.h);assert.equal(t.dayNo,1);
 f.w.clock.minute=next;await tickTournaments(f.w,f.now,f.h);assert.equal(t.dayNo,2);assert.equal(t.status,'running');
 for(const tb of Object.values(t.tables))tb.game.seats.forEach((p,i)=>assert.equal(tb.game.startStacks[i],stacks[p.id]));
 assert.equal(t.handsCompleted,2);assertTournament(t);
});

test('host loss pauses exact cards, committed chips and decision timer then resumes the same hand',async()=>{
 const f=fixture(2),t=await make(f),tb=Object.values(t.tables)[0],before=clone(tb.game);
 f.w.clock.paused=true;f.w.clock.pauseReason='host-manual';await tickTournaments(f.w,f.now,f.h);
 const pausedAt=t.pausedAt;f.now+=300000;await tickTournaments(f.w,f.now,f.h);
 assert.deepEqual(tb.game,before);assert.equal(tournamentViews(f.w,f.w.players[0].playerUuid,f.now)[0].roomView.table.legal.length,0);
 f.w.clock.paused=false;f.w.clock.pauseReason=null;online(f);await tickTournaments(f.w,f.now,f.h);
 assert.equal(tb.game.deadline,before.deadline+f.now-pausedAt);assert.deepEqual(tb.game.deck,before.deck);assert.equal(tb.game.turnId,before.turnId);assert.equal(tb.game.pot,before.pot);assertTournament(t);
});

test('disconnect grace retains a funded seat, transitions to blind-away, and accepts the same identity after reconnect',async()=>{
 const f=fixture(3),t=await make(f,{field:3,maxSeats:3,turnSeconds:180}),tb=Object.values(t.tables)[0],id=tb.game.seats[tb.game.actor].id,p=f.w.players.find(p=>p.playerUuid===id),beforeSeat=t.participants[id].seat;
 f.now+=61000;for(const q of f.w.players)if(q!==p)q.lastSeen=f.now;p.lastSeen=f.now-61000;
 // Set a fresh observed disconnect to inspect its grace, independent of the
 // normal browser heartbeat's longer online indicator.
 t.participants[id].disconnectedAt=f.now-10000;
 await tickTournaments(f.w,f.now,f.h);assert.equal(t.participants[id].disconnectState,'RECONNECT_GRACE');assert.equal(tb.game.seats.find(x=>x.id===id).folded,false);
 f.now+=21000;for(const q of f.w.players)if(q!==p)q.lastSeen=f.now;await tickTournaments(f.w,f.now,f.h);await tickTournaments(f.w,f.now,f.h);
 assert.equal(t.participants[id].status,'active');assert.equal(t.participants[id].seat,beforeSeat);assert.ok(t.participants[id].stack>0);assert.equal(t.participants[id].timeoutActions,1);
 assert.equal(tournamentViews(f.w,id,f.now)[0].participants.find(x=>x.id===id).disconnectState,'BLIND_AWAY');
 p.lastSeen=f.now;await tickTournaments(f.w,f.now,f.h);assert.equal(t.participants[id].disconnectState,'RECONNECTED');assert.equal(t.participants[id].seat,beforeSeat);assertTournament(t);
});

test('a missed heartbeat enters real reconnect grace and extends an expiring first decision only through that grace',async()=>{
 const f=fixture(3),t=await make(f,{field:3,maxSeats:3,turnSeconds:30}),tb=Object.values(t.tables)[0],id=tb.game.seats[tb.game.actor].id,p=f.w.players.find(p=>p.playerUuid===id);
 const originalDeadline=tb.game.deadline;f.now+=11000;for(const q of f.w.players)if(q!==p)q.lastSeen=f.now;
 await tickTournaments(f.w,f.now,f.h);assert.equal(t.participants[id].disconnectState,'RECONNECT_GRACE');assert.equal(tb.game.seats[tb.game.actor].id,id);
 assert.equal(tb.game.deadline,EPOCH+(TOURNAMENT_LIMITS.heartbeatGraceSeconds+TOURNAMENT_LIMITS.disconnectGraceSeconds)*1000);assert.ok(tb.game.deadline>originalDeadline);
 f.now=originalDeadline+1;for(const q of f.w.players)if(q!==p)q.lastSeen=f.now;await tickTournaments(f.w,f.now,f.h);assert.equal(tb.game.seats[tb.game.actor].id,id);
 f.now=EPOCH+41000;for(const q of f.w.players)if(q!==p)q.lastSeen=f.now;await tickTournaments(f.w,f.now,f.h);assert.notEqual(tb.game.seats[tb.game.actor]?.id,id);assert.equal(t.participants[id].status,'active');assertTournament(t);
});

test('a disconnected all-in remains showdown eligible while other seats finish their decisions',async()=>{
 const f=fixture(3),t=await make(f,{field:3,maxSeats:3,turnSeconds:180}),tb=Object.values(t.tables)[0],at=tb.game.actor,id=tb.game.seats[at].id;
 const raise=legal(tb.game,at).find(a=>a.type==='raise');await action(f,t,tb,{type:'raise',target:raise.maxTo});assert.equal(tb.game.seats[at].allIn,true);
 f.now+=61000;for(const p of f.w.players)p.lastSeen=p.playerUuid===id?f.now-61000:f.now;await tickTournaments(f.w,f.now,f.h);
 assert.equal(tb.game.seats[at].folded,false);assert.equal(tb.game.seats[at].inHand,true);assert.equal(t.participants[id].status,'active');
 await finishTable(f,t,tb);assert.equal(tb.game.settlement.showdown,true);assert.ok(tb.game.settlement.pots.some(p=>p.eligible.includes(at)));
 assert.equal(tb.game.events.some(e=>e.type==='action'&&e.seat===at&&e.action==='fold'),false);assertTournament(t);
});

test('native engine handles simultaneous eliminations, final-table reseating, exact payouts and one result per entrant',async()=>{
 const f=fixture(6),t=await make(f,{field:6,maxSeats:3,buyIn:17.35,startingStack:100});
 const initial=Object.values(t.tables);for(const tb of initial){rigHoldem(tb.game);await finishTable(f,t,tb,true);}
 assert.equal(t.results.length,4);assert.equal(Object.keys(t.tables).length,1);assert.equal(t.stage,'heads_up');assert.equal(t.status,'running');assert.ok(t.finalTableAt);assertTournament(t);
 const survivors=Object.values(t.participants).filter(p=>p.status==='active');assert.deepEqual(survivors.map(p=>p.stack).sort((a,b)=>a-b),[300,300]);
 f.now+=3000;online(f);await tickTournaments(f.w,f.now,f.h);const final=Object.values(t.tables)[0];rigHoldem(final.game);await finishTable(f,t,final,true);
 assert.equal(t.status,'complete');assert.equal(t.results.length,6);assert.equal(new Set(t.results.map(r=>r.resultId)).size,6);assert.equal(t.results.reduce((n,r)=>n+r.payoutCents,0),6*1735);
 assert.equal(f.w.players.reduce((n,p)=>n+p.wallet.balanceCents,0),6*1000000);
 const receipts=f.w.players.map(p=>p.wallet.ledger.length),results=clone(t.results);for(let i=0;i<8;i++)await tickTournaments(f.w,f.now+i*100000,f.h);
 assert.deepEqual(f.w.players.map(p=>p.wallet.ledger.length),receipts);assert.deepEqual(t.results,results);assert.equal(f.w.players.reduce((n,p)=>n+(p.tournamentStats?.wins||0),0),1);
 assert.equal(tournamentBlockers(f.w).length,0);assertTournament(t);
});

test('reloaded engine checkpoint keeps hidden cards, action order and chips across a fresh object graph',async()=>{
 const f=fixture(4),t=await make(f,{field:4,maxSeats:4}),tb=Object.values(t.tables)[0];await action(f,t,tb,passive(tb.game));
 const restored={...f,w:clone(f.w)},rt=restored.w.tournaments[t.id],rb=rt.tables[tb.id];assert.deepEqual(clone(rb.game),clone(tb.game));
 const choice=passive(tb.game);await action(f,t,tb,choice);await action(restored,rt,rb,choice);
 assert.deepEqual(clone(rb.game),clone(tb.game));assertTournament(rt);assert.equal(rt.totalChips,800);
});

test('registration withdrawal/refund and re-registration have distinct idempotent funding references',async()=>{
 const f=fixture(1),p=f.w.players[0];
 await handleTournament(f.w,p,{type:'tournament_create',tournamentId:'tournament_test',settings:{fieldSize:2,maxSeats:2,buyIn:25}},f.now,f.h);const t=f.w.tournaments.tournament_test;
 for(let i=0;i<3;i++){
  await handleTournament(f.w,p,{type:'tournament_join',tournamentId:t.id},f.now,f.h);assert.equal(p.wallet.balanceCents,997500);
  await handleTournament(f.w,p,{type:'tournament_unregister',tournamentId:t.id},f.now,f.h);assert.equal(p.wallet.balanceCents,1000000);
 }
 assert.equal(new Set(p.wallet.ledger.map(x=>x.ref)).size,6);
 await handleTournament(f.w,p,{type:'tournament_join',tournamentId:t.id},f.now,f.h);f.w.clock.minute=t.closeMinute+1;await tickTournaments(f.w,f.now,f.h);
 assert.equal(t.status,'cancelled');assert.equal(p.wallet.balanceCents,1000000);await tickTournaments(f.w,f.now,f.h);assert.equal(p.wallet.ledger.length,8);
});

test('all 22 era-eligible variants complete authoritative multiplayer hands with retained card and chip custody',async()=>{
 const ids=Object.keys(VARIANTS).filter(id=>tournamentEraGate(id,'vegas',MINUTE).ok);assert.equal(ids.length,22);let decisions=0;
 for(const variant of ids){
  const f=fixture(3),t=await make(f,{field:3,maxSeats:3,variant,startingStack:1000,blindEvery:20}),tb=Object.values(t.tables)[0];
  decisions+=await finishTable(f,t,tb);assert.equal(tb.game.phase,'complete',variant);assert.equal(tb.game.settlement.showdown,true,variant);assertGame(tb.game);assertTournament(t);
  const cards=[...tb.game.deck,...tb.game.discards,...tb.game.burned,...tb.game.board,...tb.game.seats.flatMap(p=>p.hole)];assert.equal(cards.length,createDeck(variant).length,variant);
 }
 assert.ok(decisions>200);console.log(JSON.stringify({multiplayerTournamentVariants:ids.length,legalDecisions:decisions}));
});

test('mixed human/Legends/NPC fields finish through the restored information-limited AI, including a 90-player field',async()=>{
 let fullHands=0,fullRounds=0,decisions=0;
 for(const [variant,field]of [['holdem_nl',90],['plo8',12],['stud7_hilo',12],['deuce_triple',12],['crazy_pineapple',12]]){
  const f=fixture(1),p=f.w.players[0];
  await handleTournament(f.w,p,{type:'tournament_create',tournamentId:'tournament_test',name:'Mixed Field '+variant,
   settings:{variant,fieldSize:field,maxSeats:6,startingStack:40,sb:1,bb:2,buyIn:0,blindMode:'hands',blindEvery:1,blindPace:'turbo',levelsPerDay:24,breakEveryLevels:0},bots:[{legendId:'philivey'},{legendId:'philhellmuth'}]},f.now,f.h);
  const t=f.w.tournaments.tournament_test;await handleTournament(f.w,p,{type:'tournament_join',tournamentId:t.id},f.now,f.h);await handleTournament(f.w,p,{type:'tournament_start',tournamentId:t.id},f.now,f.h);
  let guard=0;
  while(t.status!=='complete'){
   assert.ok(++guard<15000,variant+' completes without a stuck seat or table');f.now+=600;online(f);
   if(t.status==='day_break'||t.status==='break'){f.w.clock.minute=t.resumeMinute;f.now=Math.max(f.now,t.readyAt);p.availability=null;}
   await tickTournaments(f.w,f.now,f.h);
   if(t.status==='running')for(const tb of Object.values(t.tables))if(tb.game?.actor>=0&&tb.game.seats[tb.game.actor].id===p.playerUuid){
    const all=legal(tb.game,tb.game.actor),raise=all.find(a=>a.type==='raise');await action(f,t,tb,raise?{type:'raise',target:raise.maxTo}:passive(tb.game));decisions++;
   }
   assertTournament(t);
  }
  assert.equal(t.aiFallbacks,0,variant+' uses its canonical AI policy without safety fallbacks');assert.equal(t.results.length,field);assert.equal(t.results.filter(x=>x.place===1).length,1);
  assert.ok(t.results.some(x=>x.kind==='legend'));fullHands+=t.handsCompleted;fullRounds+=t.roundNo;
 }
 console.log(JSON.stringify({completedMixedAITournaments:5,entrants:138,authoritativeHands:fullHands,synchronizedRounds:fullRounds,humanDecisions:decisions}));
});

test('completed tournaments archive immutably before bounded row history compacts, retaining exact final-engine custody',async()=>{
 const f=fixture(2),archives=new Map();f.h.archiveTournament=async(w,t)=>{const ref=`${w.worldUuid}/tournaments/${t.id}/complete-${t.checkpointNo}`;const data=clone(t);if(archives.has(ref))assert.deepEqual(archives.get(ref),data);else archives.set(ref,data);return ref;};
 for(let i=0;i<46;i++){
  const id='archived_tournament_'+i;
  await handleTournament(f.w,f.w.players[0],{type:'tournament_create',tournamentId:id,name:'Archive '+i,settings:{fieldSize:2,maxSeats:2,startingStack:100,sb:1,bb:2,buyIn:0,blindEvery:100}},f.now,f.h);
  const t=f.w.tournaments[id];for(const p of f.w.players)await handleTournament(f.w,p,{type:'tournament_join',tournamentId:id},f.now,f.h);
  await handleTournament(f.w,f.w.players[0],{type:'tournament_start',tournamentId:id},f.now,f.h);const tb=Object.values(t.tables)[0];rigHoldem(tb.game);await finishTable(f,t,tb,true);assert.equal(t.status,'complete');assertGame(tb.game);assert.ok(t.archiveRef);f.now+=1000;online(f);
 }
 assert.equal(archives.size,46);assert.equal(Object.keys(f.w.tournaments).length,TOURNAMENT_LIMITS.events);assert.equal(f.w.tournamentArchiveIndex.length,6);
 assert.equal(Object.values(f.w.tournaments).filter(t=>!t.historyCompacted).length,12);
 for(const t of archives.values()){assert.equal(t.results.length,2);assert.equal(t.results.filter(r=>r.place===1).length,1);for(const tb of Object.values(t.tables))assertGame(tb.game);}
 assert.equal(f.w.players.reduce((n,p)=>n+p.tournamentStats.entries,0),92);assert.equal(f.w.players.reduce((n,p)=>n+p.tournamentStats.wins,0),46);
 assert.ok(Buffer.byteLength(JSON.stringify(f.w))<500000);console.log(JSON.stringify({archivedCompletedTournaments:archives.size,rowBytes:Buffer.byteLength(JSON.stringify(f.w)),liveHistoryEntries:Object.keys(f.w.tournaments).length}));
});
