import assert from 'node:assert/strict';
import { createGame, startHand, legal, act, publicView, tick, assertGame } from './engine.mjs';
import { VARIANTS, createDeck, card, SUIT_ORDER } from './cards.mjs';

let checks = 0;
const ok = (condition, message) => { assert.ok(condition, message); checks++; };
const eq = (actual, expected, message) => { assert.deepEqual(actual, expected, message); checks++; };
const setup = (variant = 'holdem_nl', stacks = [1000, 1000], extra = {}) => {
  const game = createGame({ variant, sb: 5, bb: 10, turnSeconds: 30, ...extra }, stacks.map((stack, i) => ({ id: `person-${i}`, name: `P${i}`, stack })));
  startHand(game, 1000);
  return game;
};
const play = (game, action) => act(game, game.actor, { ...action, turnId: game.turnId, handNo: game.handNo }, game.decisionStarted + 1);
function checkCall(game, discardCount = 0) {
  const options = legal(game, game.actor);
  const chosen = options.find(a => a.type === 'check') || options.find(a => a.type === 'call') || options[0];
  const action = { type: chosen.type };
  if (chosen.type === 'discard') action.indices = [game.seats[game.actor].hole.length - 1];
  if (chosen.type === 'draw') action.indices = game.seats[game.actor].hole.map((_, i) => i).slice(0, discardCount);
  return play(game, action);
}
function finish(game, discardCount = 0) {
  let actions = 0;
  while (game.phase !== 'complete' && actions++ < 160) checkCall(game, discardCount);
  ok(actions < 160 && game.phase === 'complete', 'hand completes');
  assertGame(game);
  return game;
}
function installHands(game, hands, board = []) {
  const used = new Set(hands.flat().concat(board));
  game.seats.forEach((p, i) => { p.hole = hands[i].map(card); p.up = p.hole.map(() => false); });
  game.board = board.map(card);
  game.burned = []; game.discards = [];
  game.deck = createDeck(game.settings.variant).filter(c => !used.has(c.text));
}

// Heads-up blinds and postflop order, BB option after a limp.
{
  const g = setup();
  eq([g.button, g.sbSeat, g.bbSeat, g.actor, g.pot], [0, 0, 1, 0, 15], 'HU button is SB and acts first preflop');
  play(g, { type: 'call' });
  eq(g.actor, 1, 'BB retains its option');
  ok(legal(g, 1).some(a => a.type === 'raise'), 'BB can raise a limp');
  play(g, { type: 'check' });
  eq([g.street, g.actor], ['FLOP', 1], 'BB acts first postflop');
  finish(g);
  const stacks = g.seats.map(p => p.stack);
  startHand(g, 9000);
  eq([g.button, g.sbSeat, g.bbSeat], [1, 1, 0], 'HU button rotates');
  eq(g.bankTotal, stacks.reduce((a, b) => a + b, 0), 'new hand does not mint chips');
}

// Repeated short all-ins only reopen action after the full cumulative raise.
for (const [last, reopen] of [[160, false], [190, true]]) {
  const g = setup('holdem_nl', [1000, 125, last, 1000]);
  eq(g.actor, 3);
  play(g, { type: 'raise', target: 100 });
  play(g, { type: 'call' });
  play(g, { type: 'raise', target: 125 });
  play(g, { type: 'raise', target: last });
  eq(g.actor, 3);
  eq(legal(g, 3).some(a => a.type === 'raise'), reopen, 'cumulative short-allin reopening');
  finish(g);
}

// A checked player can raise a later incomplete all-in bet on that street.
{
  const g = setup('holdem_nl', [17, 1000, 1000]);
  play(g, { type: 'call' }); play(g, { type: 'call' }); play(g, { type: 'check' });
  eq([g.street, g.actor], ['FLOP', 1]);
  play(g, { type: 'check' }); play(g, { type: 'check' });
  play(g, { type: 'raise', target: 7 });
  const r = legal(g, g.actor).find(a => a.type === 'raise');
  eq(r?.minTo, 10, 'incomplete opening all-in can be completed');
  finish(g);
}

// Pot-limit is the pot after calling, plus the caller's total existing wager.
{
  const g = setup('plo', [1000, 1000, 1000]);
  const r = legal(g, 0).find(a => a.type === 'raise');
  eq([r.minTo, r.maxTo], [20, 35], 'three-handed PLO open maximum 3.5 BB');
  const before = JSON.stringify(g);
  assert.throws(() => play(g, { type: 'raise', target: 36 }), /Raise to/); checks++;
  eq(JSON.stringify(g), before, 'invalid raise is rejected without mutation');
  play(g, { type: 'raise', target: 35 });
  finish(g);
}

// Fixed-limit multiway cap (one bet plus three raises), no uncapped NL sizing.
{
  const g = setup('holdem_fl', [1000, 1000, 1000]);
  for (const to of [20, 30, 40]) {
    const r = legal(g, g.actor).find(a => a.type === 'raise');
    eq([r.minTo, r.maxTo], [to, to]);
    play(g, { type: 'raise', target: to });
  }
  ok(!legal(g, g.actor).some(a => a.type === 'raise'), 'four full wagers cap multiway FL');
  finish(g);
}

// Main and side pots, with shorter stack winning only its covered amount.
{
  const g = setup('holdem_nl', [50, 100, 200]);
  installHands(g, [['A♠', 'A♥'], ['K♠', 'K♥'], ['Q♠', 'Q♥']]);
  // Burn+board stock, specified from the end for pop(); full custody retained.
  const run = ['2♣', '3♦', '5♣', '7♦', '9♣'];
  const burns = ['4♥', '6♥', '8♥'];
  const reserved = new Set([...run, ...burns]);
  g.deck = g.deck.filter(c => !reserved.has(c.text)).concat([card(burns[2]), card(run[4]), card(burns[1]), card(run[3]), card(run[2]), card(run[1]), card(run[0]), card(burns[0])]);
  // Order is burn, flop3, burn, turn, burn, river.
  g.deck = g.deck.filter(c => !reserved.has(c.text)).concat([card(run[4]), card(burns[2]), card(run[3]), card(burns[1]), card(run[2]), card(run[1]), card(run[0]), card(burns[0])]);
  play(g, { type: 'raise', target: 50 });
  play(g, { type: 'raise', target: 100 });
  play(g, { type: 'call' });
  eq(g.phase, 'complete');
  eq(g.settlement.payouts, [150, 100, 0], 'main pot to aces; side pot to kings');
  eq(g.seats.map(p => p.stack), [150, 100, 100], 'sidepots conserve 350 chips');
  eq(g.settlement.pots.map(p => p.amount), [150, 100]);
}

// Tied odd chips go clockwise to the left of the button, exactly once.
{
  const g = setup('holdem_nl', [100, 100, 100], { ante: 1 });
  installHands(g, [['2♠', '3♠'], ['4♠', '5♠'], ['6♠', '7♠']]);
  const run = ['T♥', 'J♥', 'Q♥', 'K♥', 'A♥'], burns = ['2♦', '3♦', '4♦'];
  const reserved = new Set([...run, ...burns]);
  g.deck = g.deck.filter(c => !reserved.has(c.text)).concat([card(run[4]), card(burns[2]), card(run[3]), card(burns[1]), card(run[2]), card(run[1]), card(run[0]), card(burns[0])]);
  play(g, { type: 'fold' });
  finish(g);
  eq(g.settlement.pot, 23);
  eq(g.settlement.payouts, [0, 12, 11], 'one dead ante creates an odd shared pot');
  const result = JSON.stringify(g);
  assert.throws(() => act(g, 1, { type: 'call' }, 2000), /turn|legal/); checks++;
  eq(JSON.stringify(g), result, 'completed payout cannot be repeated');
}

// Private views reveal only recipient cards before showdown, including folded cards.
{
  const g = setup('holdem_nl', [1000, 1000, 1000]);
  for (let viewer = 0; viewer < 3; viewer++) {
    const v = publicView(g, viewer);
    eq(v.players[0].seatIndex, viewer, 'recipient rotates to YOU seat');
    ok(v.players[0].cards.every(Boolean), 'own private cards visible');
    ok(v.players.slice(1).every(p => p.cards.every(c => c === null)), 'opponent cards masked');
    for (const key of ['deck', 'discards', 'burned', 'hole']) ok(!Object.hasOwn(v, key), `no ${key} custody data in view`);
    eq(v.actor, (g.actor - viewer + 3) % 3, 'actor index rotates');
  }
  const spectator = publicView(g);
  ok(spectator.players.every(p => p.cards.every(c => c === null)), 'spectator sees no private cards');
  const recovered = JSON.parse(JSON.stringify(g));
  eq(publicView(recovered, 2), publicView(g, 2), 'serialized reconnect state preserves exact public view');
  const before = JSON.stringify(g), expired = g.deadline;
  assert.throws(() => act(g, g.actor, { type: 'call' }, expired), /expired/); checks++;
  eq(JSON.stringify(g), before, 'late action has no effect');
  ok(tick(g, expired), 'deadline auto-folds');
  ok(g.events.some(e => e.type === 'timeout'), 'timeout explicitly recorded');
}

// All-in draws and Pineapple discards stay human decisions.
for (const variant of ['pineapple', 'crazy_pineapple', 'draw5', 'deuce_triple', 'badugi']) {
  const g = setup(variant, [20, 20]);
  play(g, { type: 'raise', target: legal(g, g.actor).find(a => a.type === 'raise').maxTo });
  play(g, { type: 'call' });
  ok(['draw', 'discard'].includes(g.phase), `${variant} pauses for card decisions after all-in`);
  const first = g.actor, turn = g.turnId;
  checkCall(g, variant === 'badugi' ? 4 : 5);
  ok(g.actor !== first && g.turnId > turn, `${variant}: second player still chooses`);
  finish(g, variant === 'badugi' ? 4 : 5);
  ok(g.events.some(e => e.type === (variant.includes('pineapple') ? 'discard' : 'draw')), `${variant}: choices recorded`);
}

// Eight-handed seven-card stud must use one shared river without duplicating cards.
for (const variant of ['stud7', 'stud7_hilo', 'razz']) {
  const g = setup(variant, Array(8).fill(5000));
  finish(g);
  ok(g.sharedRiver, `${variant} common seventh at eight survivors`);
  eq(g.board.length, 1);
  ok(g.seats.every(p => p.hole.length === 6), 'six personal cards plus shared seventh');
  eq(g.seats.reduce((n, p) => n + p.stack, 0), 40000);
}

// Courchevel burns once for the entire flop: exposing the door card is not a fourth burn.
for (const variant of ['courchevel', 'courchevel8']) {
  const g = setup(variant, Array(8).fill(1000));
  eq(g.board.length, 1, 'Courchevel door card before betting');
  finish(g);
  eq(g.burnCount, 3, 'three board-street burns');
}

// Ante-all-in bring-in duty passes clockwise from the original qualifying door card.
for (const variant of ['stud7', 'razz']) for (let test = 0; test < 30; test++) {
  const g = setup(variant, [5, 100, 100]);
  const ordering = g.seats.map((p, i) => ({ i, c: p.hole[2] })).sort((a, b) => {
    const av = variant === 'razz' && a.c.val === 14 ? 1 : a.c.val;
    const bv = variant === 'razz' && b.c.val === 14 ? 1 : b.c.val;
    const suit = SUIT_ORDER[a.c.suit] - SUIT_ORDER[b.c.suit];
    return variant === 'razz' ? bv - av || -suit : av - bv || suit;
  });
  const expected = ordering[0].i === 0 ? 1 : ordering[0].i;
  eq(g.bringInSeat, expected, `${variant}: ante-all-in does not reorder bring-in by next-ranked card`);
}

// Optional high-only Stud fourth-street big bet is discrete and locks later sizing.
{
  const g = setup('stud7', [1000, 1000]);
  installHands(g, [['2♠', '3♠', 'A♣'], ['4♠', '5♠', '8♣']]);
  g.seats.forEach(p => p.up = [false, false, true]);
  const extras = ['6♠', '8♦', 'K♣'];
  g.deck = g.deck.filter(c => !extras.includes(c.text)).concat(extras.slice().reverse().map(card));
  while (g.street !== 'FOURTH') checkCall(g);
  const r = legal(g, g.actor).find(x => x.type === 'raise');
  eq(r.targets, [10, 20], 'paired exposed board offers small or big bet');
  const before = JSON.stringify(g);
  assert.throws(() => play(g, { type: 'raise', target: 15 }), /paired-board/); checks++;
  eq(JSON.stringify(g), before, 'intermediate Stud wager rejected atomically');
  play(g, { type: 'raise', target: 20 });
  ok(g.studFourthBig, 'big option locked');
  const next = legal(g, g.actor).find(x => x.type === 'raise');
  eq([next.minTo, next.maxTo], [40, 40], 'subsequent fourth-street raises use big unit');
  finish(g);
}

// Every registered variant at native capacity: maximum draws stress stock recycling.
for (const spec of Object.values(VARIANTS)) {
  const g = setup(spec.id, Array(spec.seatCap).fill(2000));
  finish(g, spec.holeCount);
  eq(g.seats.reduce((n, p) => n + p.stack, 0), 2000 * spec.seatCap, `${spec.id} exact chips`);
  eq(g.settlement.payouts.reduce((a, b) => a + b, 0), g.settlement.pot, `${spec.id} payout conservation`);
  ok(g.events.filter(e => e.type === 'draw').length === (spec.drawAfter?.length || 0) * spec.seatCap, `${spec.id} every human draw`);
}

// Seeded legal-action exploration, uneven stacks and JSON persistence after each action.
let state = 83123456;
const rand = () => { state = (Math.imul(state, 1664525) + 1013904223) >>> 0; return state / 4294967296; };
let randomizedHands = 0;
for (const spec of Object.values(VARIANTS)) for (let hand = 0; hand < 18; hand++) {
  const count = 2 + Math.floor(rand() * (spec.seatCap - 1));
  let g = setup(spec.id, Array.from({ length: count }, () => 20 + Math.floor(rand() * 750)));
  let decisions = 0;
  while (g.phase !== 'complete' && decisions++ < 350) {
    const choices = legal(g, g.actor);
    ok(choices.length > 0, 'random decision has legal action');
    const chosen = choices[Math.floor(rand() * choices.length)], action = { type: chosen.type };
    if (chosen.type === 'raise') action.target = chosen.targets ? chosen.targets[Math.floor(rand() * chosen.targets.length)] : chosen.minTo + Math.floor(rand() * (chosen.maxTo - chosen.minTo + 1));
    if (chosen.type === 'draw') action.indices = g.seats[g.actor].hole.flatMap((_, i) => rand() < .65 ? [i] : []);
    if (chosen.type === 'discard') action.indices = [Math.floor(rand() * g.seats[g.actor].hole.length)];
    play(g, action);
    g = JSON.parse(JSON.stringify(g));
    assertGame(g);
  }
  ok(g.phase === 'complete' && decisions < 350, `${spec.id} randomized hand completes`);
  randomizedHands++;
}
console.log(JSON.stringify({ ok: true, checks, registeredVariants: Object.keys(VARIANTS).length, randomizedHands }, null, 2));
