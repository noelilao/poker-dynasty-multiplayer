import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import net from 'node:net';
import {once} from 'node:events';
import {fileURLToPath} from 'node:url';
import {nativeChecksum} from '../mp-engine/career84-integrity.mjs';
const baseDir=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const enc=new TextEncoder(),hex=a=>Array.from(a,v=>v.toString(16).padStart(2,'0')).join('');
const sha=async x=>hex(new Uint8Array(await crypto.subtle.digest('SHA-256',enc.encode(x))));
async function freePort(){const s=net.createServer();s.listen(0,'127.0.0.1');await once(s,'listening');const p=s.address().port;await new Promise(r=>s.close(r));return p;}
async function delay(ms){await new Promise(r=>setTimeout(r,ms));}

test('standalone SQLite survives full process restart with immutable snapshot and pending password challenge',async()=>{
 const dir=await mkdtemp(path.join(tmpdir(),'pd841-persistence-')),port=await freePort(),base='http://127.0.0.1:'+port;
 let process=null,logs='';
 async function start(){process=spawn(globalThis.process.execPath,['mp-engine/server.mjs'],{cwd:baseDir,env:{...globalThis.process.env,PD83_DATA_DIR:dir,PD83_PORT:String(port),PD83_BIND:'127.0.0.1'},stdio:['ignore','pipe','pipe']});process.stdout.on('data',s=>logs+=s);process.stderr.on('data',s=>logs+=s);for(let i=0;i<100;i++){try{const r=await fetch(base+'/api/career84/meta');if(r.ok)return;}catch{}if(process.exitCode!==null)throw Error(logs);await delay(25);}throw Error('Server did not start: '+logs);}
 async function stop(){if(process&&process.exitCode===null){const done=once(process,'exit');process.kill('SIGTERM');await done;}process=null;}
 async function call(route,payload,token){const r=await fetch(base+route,{method:payload===undefined?'GET':'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer '+token}:{})},body:payload===undefined?undefined:JSON.stringify(payload)});return{status:r.status,data:await r.json()};}
 try{
  await start();const cred={salt:'11'.repeat(16),verifier:'22'.repeat(32),iterations:100000};let r=await call('/api/career84/create',{worldName:'Restart proof',playerName:'Host',credential:cred,recoveryKey:'aa'.repeat(32),worldSettings:{startYear:2026,startMonth:10,startDay:7,startHour:18,startMinute:0,startingCity:'vegas'}});assert.equal(r.status,201,r.data.error);const s=r.data,ch=s.view.own.character,d=new Date(ch.createdMinute*60000);
  const career={isCreated:true,_saveSchema:221,_dynastyId:ch.characterUuid,activeName:'Host',founderName:'Host',generation:1,startingYear:2026,currentYear:d.getUTCFullYear(),currentMonth:d.getUTCMonth()+1,day:d.getUTCDate(),bankroll:ch.startingBankroll,debt:0,bankDebt:0,assets:[{id:'retained_native_asset',owned:true}],world:{seed:s.view.world.seed,current:ch.startingCity},dailyLife55:{schema:1,minuteOfDay:1080},multiplayerCareer84:{schema:1,worldUuid:s.worldUuid,playerUuid:s.playerUuid,characterUuid:ch.characterUuid,worldSeed:s.view.world.seed,createdMinute:ch.createdMinute,appliedAvailabilityIds:[],appliedWalletIds:[],snapshotRevision:1}};
  const payload=JSON.stringify(career),text=JSON.stringify({game:'Poker Dynasty',backupVersion:1,snapshot:{format:'PokerDynastySnapshot',formatVersion:1,seq:1,identity:ch.characterUuid,checksum:nativeChecksum(payload),payload}});
  r=await call('/api/career84/world/'+s.worldCode,{type:'sync_snapshot',snapshot:{text,checksum:await sha(text),baseRevision:0,revision:1,slot:1},expectedRevision:s.view.world.revision,requestId:'restart_snapshot_0001'},s.sessionToken);assert.equal(r.status,200,r.data.error);
  r=await call('/api/career84/auth/challenge',{worldCode:s.worldCode,playerUuid:s.playerUuid});assert.equal(r.status,200);const nonce=r.data.nonce;
  await stop();await start();
  r=await call('/api/career84/world/'+s.worldCode,{type:'poll',includeSnapshot:true},s.sessionToken);assert.equal(r.status,200,r.data.error);assert.equal(r.data.view.own.snapshot.text,text);assert.equal(r.data.view.own.snapshotRevision,1);
  const key=await crypto.subtle.importKey('raw',Uint8Array.from(cred.verifier.match(/../g),x=>Number.parseInt(x,16)),{name:'HMAC',hash:'SHA-256'},false,['sign']);const proof=hex(new Uint8Array(await crypto.subtle.sign('HMAC',key,enc.encode(`pd84-login|${s.worldCode}|${s.playerUuid}|${nonce}`))));
  r=await call('/api/career84/auth/login',{worldCode:s.worldCode,playerUuid:s.playerUuid,nonce,proof});assert.equal(r.status,200,r.data.error);assert.equal(r.data.playerUuid,s.playerUuid);assert.notEqual(r.data.sessionToken,s.sessionToken);
  assert.equal((await call('/api/career84/world/'+s.worldCode,{type:'poll'},s.sessionToken)).status,401);
  const html=await fetch(base+'/game.html');assert.equal(html.status,200);assert.ok((await html.text()).includes('Poker Dynasty'));
 }finally{await stop();await rm(dir,{recursive:true,force:true});}
});
