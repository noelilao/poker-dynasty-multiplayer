import asyncio,subprocess,tempfile,json,secrets,sqlite3,hashlib,hmac,time,shutil,os
from pathlib import Path
import httpx
ROOT=Path(__file__).resolve().parents[1];W=ROOT/'verification';W.mkdir(exist_ok=True);ROWS=[]
def chk(name,value):
 ROWS.append({'name':name,'passed':bool(value)});print(('PASS ' if value else 'FAIL ')+name,flush=True)
 if not value:raise AssertionError(name)
async def main():
 data=tempfile.mkdtemp(prefix='pde-');proc=None;url='http://127.0.0.1:8890'
 log=open(W/'wrapper-server-test.log','w')
 def start():return subprocess.Popen(['node',str(ROOT/'mp-engine/server.mjs')],env={**os.environ,'PD83_DATA_DIR':data,'PD83_PORT':'8890','PD83_BIND':'127.0.0.1'},stdout=log,stderr=log)
 async with httpx.AsyncClient(timeout=25) as c:
  async def wait():
   for _ in range(80):
    try:
     if (await c.get(url+'/api/meta')).status_code==200:return
    except httpx.HTTPError:pass
    await asyncio.sleep(.1)
   raise TimeoutError('server did not boot')
  async def post(path,b,token=None):
   r=await c.post(url+path,json=b,headers={'Origin':'null',**({'Authorization':'Bearer '+token} if token else {})});return r,r.json()
  def rows(table):
   with sqlite3.connect(Path(data)/'rooms.sqlite') as db:return db.execute('select count(*) from '+table).fetchone()[0]
  try:
   proc=start();await wait()
   r=await c.get(url+'/api/career84/meta');m=r.json();chk('actual Career capability metadata',m['ready'] and m['capabilities']['entryReplay'] and m['capabilities']['hostTimeline'])
   r=await c.options(url+'/api/career84/create',headers={'Origin':'null','Access-Control-Request-Method':'POST','Access-Control-Request-Headers':'content-type,authorization'})
   chk('CORS preflight supports downloaded HTML origins',r.status_code==204 and r.headers['access-control-allow-origin']=='*' and 'Authorization' in r.headers['access-control-allow-headers'])
   r=await c.get(url+'/game.html');expected=(ROOT/'mp-engine/game.html').read_bytes();chk('same process serves exact updated HTML',r.status_code==200 and r.content==expected)
   chk('server HTML not aggressively cached',r.headers.get('cache-control')=='no-cache')
   cred=dict(salt=secrets.token_hex(16),iterations=100000,verifier=secrets.token_hex(32))
   body=dict(worldName='E receipt test',playerName='Host receipt',credential=cred,recoveryKey=secrets.token_hex(32),entryKey=secrets.token_hex(32),worldSettings=dict(startYear=2024,startMonth=2,startDay=29,startHour=18,startMinute=45,startingCity='manila',realSecondsPerGameMinute=3600))
   bad={**body,'worldSettings':{**body['worldSettings'],'startDay':30}}
   r,x=await post('/api/career84/create',bad);chk('server rejects nonexistent date before allocation',r.status_code==400 and rows('career_worlds')==0 and rows('career_entry_receipts')==0)
   chk('validation errors preserve CORS headers',r.headers.get('access-control-allow-origin')=='*')
   r,host=await post('/api/career84/create',body);chk('atomic first world and receipt creation',r.status_code==201 and rows('career_worlds')==1 and rows('career_entry_receipts')==1)
   chk('server stores exact chosen date/time',host['view']['world']['start']['minute']==28487205 and host['view']['clock']['minute']==28487205)
   r,x=await post('/api/career84/create',body);chk('same entry replay keeps original world/player/session',r.status_code==200 and x['entryReplayed'] and all(x[k]==host[k] for k in ['worldCode','worldUuid','playerUuid','sessionToken']) and rows('career_worlds')==1)
   responses=await asyncio.gather(*(post('/api/career84/create',body) for _ in range(8)))
   chk('eight concurrent replays allocate no duplicates',all(r.status_code==200 and x['worldUuid']==host['worldUuid'] for r,x in responses) and rows('career_entry_receipts')==1)
   r,x=await post('/api/career84/create',{**body,'worldName':'Drifted'});chk('changed-payload recovery rejected',r.status_code==409 and x['code']=='entry_conflict' and rows('career_worlds')==1)
   join=dict(worldCode=host['worldCode'],playerName='Guest receipt',credential=cred,recoveryKey=secrets.token_hex(32),entryKey=secrets.token_hex(32))
   replies=await asyncio.gather(*(post('/api/career84/join',join) for _ in range(6)))
   guest=replies[0][1];chk('six concurrent joins reserve one independent player',all(r.status_code in [200,201] and x['playerUuid']==guest['playerUuid'] for r,x in replies) and guest['playerUuid']!=host['playerUuid'])
   r,x=await post('/api/career84/world/'+host['worldCode'],{'type':'poll'},host['sessionToken']);chk('world holds exactly host and guest',len(x['view']['players'])==2 and rows('career_entry_receipts')==2)
   chk('joined character inherits exact timeline',guest['view']['own']['character']['createdMinute']==28487205)
   with sqlite3.connect(Path(data)/'rooms.sqlite') as db:
    text='\n'.join(row[0] for row in db.execute('select envelope from career_entry_receipts'))
   chk('receipt credentials encrypted at rest',host['sessionToken'] not in text and guest['sessionToken'] not in text and body['recoveryKey'] not in text)
   proc.terminate();proc.wait(timeout=8);proc=start();await wait()
   r,x=await post('/api/career84/create',body);chk('restart preserves same world receipt and key',r.status_code==200 and x['worldUuid']==host['worldUuid'] and x['sessionToken']==host['sessionToken'] and rows('career_worlds')==1)
   r,x=await post('/api/career84/join',join);chk('restart preserves guest recovery receipt',r.status_code==200 and x['playerUuid']==guest['playerUuid'])
   r,challenge=await post('/api/career84/auth/challenge',dict(worldCode=host['worldCode'],playerUuid=host['playerUuid']))
   signature=hmac.new(bytes.fromhex(cred['verifier']),f"pd84-login|{host['worldCode']}|{host['playerUuid']}|{challenge['nonce']}".encode(),hashlib.sha256).hexdigest()
   r,auth=await post('/api/career84/auth/login',dict(worldCode=host['worldCode'],playerUuid=host['playerUuid'],nonce=challenge['nonce'],proof=signature))
   chk('password proof rotates existing session',r.status_code==200 and auth['sessionToken']!=host['sessionToken'])
   r,x=await post('/api/career84/create',body);chk('stale entry replay cannot reclaim replaced session',r.status_code==409 and x['code']=='entry_session_replaced')
   r,x=await post('/api/career84/world/'+host['worldCode'],{'type':'poll'},host['sessionToken']);chk('old token denied without server failure',r.status_code==401 and r.headers.get('access-control-allow-origin')=='*')
   r,x=await post('/api/career84/world/'+host['worldCode'],{'type':'poll'},auth['sessionToken']);chk('new session world state intact',r.status_code==200 and len(x['view']['players'])==2)
   # ordinary room authority on same listener
   room_body=dict(name='Room control',entryKey=secrets.token_hex(32),settings=dict(variant='holdem_nl',maxSeats=2,sb=5,bb=10,buyin=1000,autoFillBots=False))
   r,room=await post('/api/create',room_body);chk('ordinary Multiplayer room still creates on same server',r.status_code in [200,201] and len(room.get('roomCode',''))==8)
   r,rjoin=await post('/api/join',dict(name='Room guest',roomCode=room['roomCode'],code=room['roomCode'],entryKey=secrets.token_hex(32)));chk('ordinary Multiplayer guest can join',r.status_code in [200,201] and rjoin.get('roomCode')==room['roomCode'])
   chk('room and world codes remain distinct',room['roomCode']!=host['worldCode'])
   r=await c.post(url+'/api/career84/create',content='{broken',headers={'Content-Type':'application/json','Origin':'null'});chk('malformed JSON fails safely with CORS',r.status_code==400 and r.headers.get('access-control-allow-origin')=='*')
  except Exception as e:
   ROWS.append({'name':'suite completion','passed':False,'error':str(e)});import traceback;traceback.print_exc()
  finally:
   if proc and proc.poll() is None:proc.terminate();proc.wait(timeout=10)
   log.close();shutil.rmtree(data)
   (W/'wrapper-http-results.json').write_text(json.dumps({'checks':ROWS,'passed':sum(x['passed'] for x in ROWS),'failed':sum(not x['passed'] for x in ROWS),'transport':'Actual HTTP to Node, actual SQLite, actual process restart. Test credentials generated fresh; no user data used.'},indent=2))
asyncio.run(main())
