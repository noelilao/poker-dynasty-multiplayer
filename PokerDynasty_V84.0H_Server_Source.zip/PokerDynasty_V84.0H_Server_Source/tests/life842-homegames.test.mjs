import test from 'node:test';
import assert from 'node:assert/strict';
import {fixture,C,assertHomeGame} from './life842-fixture.mjs';

function setup(three=false){
 const f=fixture(),r=f.buy('a','rowhouse'),item=f.item('a','poker_table');f.deliver();f.place('a',item,r);
 const id=f.home('a','create',{itemId:item,bb:2,buyin:100,maxSeats:6}).id;
 for(const who of three?['a','b','c']:['a','b'])f.home(who,'join',{gameId:id});
 f.touch();f.home('a','start',{gameId:id});return {f,id,r,item};
}
function move(f,id,pick){
 const g=f.w.life842.games[id],p=g.game.seats[g.game.actor];
 const v=f.homeViews(p.id).find(x=>x.id===id).roomView;
 const legal=v.table.legal;
 let m=pick?.(legal)||legal.find(x=>x.type==='check')||legal.find(x=>x.type==='call')||legal[0];
 m={...m};if(m.type==='raise')m={type:'raise',target:m.target??m.to??m.minTo};
 if(m.type==='draw')m={type:'draw',indices:[]};
 if(m.type==='discard')m={type:'discard',indices:[0]};
 f.home(p.id,'act',{gameId:id,turnId:v.table.turnId,move:m});
}
test('home cash: check/call reaches full showdown and uses native player appearance',()=>{
 const {f,id}=setup();f.p('b').profile={dna:{gender:'female',hair:3},age:35,seed:1234};
 let n=0;while(f.w.life842.games[id].game.phase!=='complete'&&n++<100)move(f,id);
 const g=f.w.life842.games[id];assert.ok(n>=4&&n<100);assert.equal(g.game.board.length,5);assert.equal(g.game.settlement.showdown,true);
 assert.equal(f.homeViews('a')[0].roomView.roster.find(x=>x.id==='b').profile.dna.gender,'female');assertHomeGame(g);
});
test('home cash: stale turn and out-of-turn commands leave table and wallets untouched',()=>{
 const {f,id}=setup(),g=f.w.life842.games[id],who=g.game.seats[g.game.actor].id,v=f.homeViews(who)[0].roomView;
 const other=who==='a'?'b':'a';let before=JSON.stringify(f.w);
 assert.throws(()=>f.home(other,'act',{gameId:id,turnId:v.table.turnId,move:{type:'fold'}}));assert.equal(JSON.stringify(f.w),before);
 move(f,id);before=JSON.stringify(f.w);assert.throws(()=>f.home(who,'act',{gameId:id,turnId:v.table.turnId,move:{type:'fold'}}));assert.equal(JSON.stringify(f.w),before);
});
test('home cash: disconnected all-in remains eligible for showdown and cash-out is conserved',()=>{
 const {f,id}=setup(true),initial=['a','b','c'].reduce((n,p)=>n+f.balance(p),0)+30000;
 const first=f.w.life842.games[id].game.seats[f.w.life842.games[id].game.actor].id;
 move(f,id,legal=>({type:'raise',to:legal.find(x=>x.type==='raise').maxTo}));
 f.p(first).away=true;
 let steps=0;while(f.w.life842.games[id].game.phase!=='complete'&&steps++<100)move(f,id);
 const g=f.w.life842.games[id];assert.ok(steps<100);assert.equal(g.game.seats.find(x=>x.id===first).folded,false);assert.equal(g.game.settlement.showdown,true);
 f.home('a','close',{gameId:id});assert.equal(['a','b','c'].reduce((n,p)=>n+f.balance(p),0),initial);assertHomeGame(f.w.life842.games[id]);
});
test('home cash: disconnected on-action seat receives grace, then legal timeout without instant cash-out',()=>{
 const {f,id}=setup(),g=f.w.life842.games[id],who=g.game.seats[g.game.actor].id,turn=g.game.turnId;
 f.p(who).away=true;f.real(20000);f.homeTick();assert.equal(f.w.life842.games[id].game.turnId,turn);
 assert.equal(f.w.life842.games[id].members[who].seated,true);
 f.real(11000);f.touch(who==='a'?'b':'a');f.homeTick();
 assert.ok(f.w.life842.games[id].game.turnId!==turn||f.w.life842.games[id].game.phase==='complete');assertHomeGame(f.w.life842.games[id]);
});
test('home cash: close request retains committed hand, table cannot be moved, final cash-out runs once',()=>{
 const {f,id,item}=setup(),before=f.balance('a')+f.balance('b'),g=f.w.life842.games[id];
 assert.throws(()=>f.run('a','store',{itemId:item}));f.home('a','close',{gameId:id});assert.notEqual(f.w.life842.games[id].status,'closed');
 let n=0;while(f.w.life842.games[id].game.phase!=='complete'&&n++<100)move(f,id);
 f.homeTick();assert.equal(f.w.life842.games[id].status,'closed');assert.equal(f.balance('a')+f.balance('b'),before+20000);
 const after=f.balance('a')+f.balance('b');f.homeTick();assert.equal(f.balance('a')+f.balance('b'),after);assertHomeGame(f.w.life842.games[id]);
});
test('home cash: loss of household access closes after hand, not by confiscating chips',()=>{
 const {f,id,r}=setup(),before=f.balance('a')+f.balance('b');
 // Model a canonical lease/title transfer observed between server ticks, not an allowed client command.
 f.w.life842.properties[r].owner='c';f.homeTick();assert.equal(f.w.life842.games[id].closing,true);
 let n=0;while(f.w.life842.games[id].game.phase!=='complete'&&n++<100)move(f,id);
 f.homeTick();assert.equal(f.w.life842.games[id].status,'closed');assert.equal(f.balance('a')+f.balance('b'),before+20000);assertHomeGame(f.w.life842.games[id]);
});
test('home cash: absent players cash out between hands and do not force another absent deal',()=>{
 const {f,id}=setup();let n=0;while(f.w.life842.games[id].game.phase!=='complete'&&n++<100)move(f,id);
 const hand=f.w.life842.games[id].hands;f.p('a').away=true;f.p('b').away=true;f.real(181000);f.homeTick();
 assert.equal(f.w.life842.games[id].hands,hand);assert.equal(f.w.life842.games[id].members.a.seated,false);assert.equal(f.w.life842.games[id].members.b.seated,false);assertHomeGame(f.w.life842.games[id]);
});
