import test from 'node:test';
import assert from 'node:assert/strict';
import { room, raw, live, host, request, command, poll, join, start, finish, ready } from './room-fixture.mjs';

const FACE = ['faceRoundness','faceWidth','faceLength','jawWidth','jawAngle','chin','cheekbones','forehead','eyeShape','eyeSize','eyeSpacing','eyeTilt','browThickness','browArch','browTilt','noseWidth','noseLength','noseBridge','mouthWidth','lips','ears'];
const BODY = ['height','shoulderWidth','neck','neckLength','torso','waist','hips','bodyMass','muscularity','posture','chestFullness'];
const ENUMS = { skinTone:7,hairStyle:13,hairColor:8,hairTexture:3,hairLength:4,facialHair:7,clothing:19,accessory:8 };
function dna() {
  return { version:2,bodySchema:2,seed:4294967295,gender:'f',expressionBase:'calm',
    ...Object.fromEntries(FACE.concat(BODY).map(key => [key, key.endsWith('Tilt') ? 0 : .5])), ...ENUMS };
}

test('full native flat DNA survives bounded transport while identity, markup and Career extras are stripped', async () => {
  const input = { version:1,name:'<script>wrong name</script>',age:100,year:1829,seed:0,dna:{ ...dna(),
    isHero:true,isPreview:true,legendId:'legend',_pixel59:'<svg onload=alert(1)>',face:{ raw:'bad' },
    ...JSON.parse('{"__proto__":{"polluted":true},"constructor":{"prototype":{"polluted":true}}}'),
  }, bank:99999999,careerState:{ bank:99999999 },isHero:true,html:'<img onerror=alert(1)>' };
  const ctx = await room({ maxSeats:2,body:{ name:'<img src=x onerror=alert(1)>Typed <b>Name</b>\u202e',profile:input } });
  const expected = { version:1,name:'Typed Name',age:100,year:1829,seed:0,dna:dna() };
  assert.deepEqual(live(ctx)[0].profile, expected); assert.equal({}.polluted, undefined);
  const guest = (await join(ctx, 'Guest', { spectator:true })).client;
  await start(ctx);
  for (const client of [host(ctx), guest]) {
    const view = (await poll(ctx, client)).view;
    assert.deepEqual(view.roster.find(p => p.id === host(ctx).id).profile, expected);
    assert.deepEqual(view.table.seats.find(p => p.id === host(ctx).id).profile, expected);
    assert.ok(!JSON.stringify(view).includes('99999999'));
  }
  assert.equal(raw(ctx).game.bankTotal, 400);
});

test('metadata shapes, nonfinite values, unsafe integers and unsupported versions reject atomically', async () => {
  const ctx = await room({ maxSeats:2 }); await start(ctx);
  const bad = [true, [], 'profile', {version:2}, {age:17}, {age:101}, {age:null}, {age:'28'}, {age:28.5}, {age:NaN}, {age:Infinity},
    {year:1828}, {year:10000}, {year:null}, {year:'2026'}, {seed:-1}, {seed:4294967296}, {seed:null}, {seed:'2'}, {seed:1.1}, {seed:Infinity},
    {dna:null}, {dna:[]}, {dna:'DNA'}, {dna:{}}, {dna:{...dna(),version:3}}, {dna:{...dna(),bodySchema:1}},
    {dna:{...dna(),gender:'female'}}, {dna:{...dna(),expressionBase:'<svg>'}}, {dna:{...dna(),seed:-1}}, {dna:{...dna(),seed:null}},
  ];
  for (const profile of bad) {
    const before = JSON.stringify(raw(ctx));
    await join(ctx, 'Invalid', { profile }, 400);
    assert.equal(JSON.stringify(raw(ctx)), before);
  }
});

test('every native scalar and enum rejects missing, out-of-range and nonnumeric values', async () => {
  const ctx = await room({ maxSeats:2 }); await start(ctx);
  let rejected = 0;
  for (const key of FACE.concat(BODY)) {
    const lo = key==='eyeTilt' ? -.35 : key==='browTilt' ? -.32 : 0;
    const hi = key==='eyeTilt' ? .35 : key==='browTilt' ? .32 : 1;
    for (const value of [lo-.001,hi+.001,null,'0.5',Infinity,undefined]) {
      const before = JSON.stringify(raw(ctx));
      await join(ctx, 'Invalid', {profile:{dna:{...dna(),[key]:value}}}, 400);
      assert.equal(JSON.stringify(raw(ctx)), before); rejected++;
    }
  }
  for (const [key,max] of Object.entries(ENUMS)) for (const value of [-1,max+1,.5,null,'0',undefined]) {
    const before = JSON.stringify(raw(ctx));
    await join(ctx, 'Invalid', {profile:{dna:{...dna(),[key]:value}}}, 400);
    assert.equal(JSON.stringify(raw(ctx)), before); rejected++;
  }
  assert.equal(rejected,240);
});

test('all valid boundary values and early/future Career years survive without numeric clamping', async () => {
  for (const high of [false,true]) {
    const d = dna(); d.seed = high ? 4294967295 : 0;
    for (const key of FACE.concat(BODY)) d[key] = key==='eyeTilt' ? (high?.35:-.35) : key==='browTilt' ? (high?.32:-.32) : high?1:0;
    for (const [key,max] of Object.entries(ENUMS)) d[key] = high?max:0;
    const ctx = await room({body:{name:'N'.repeat(70),profile:{age:high?100:18,year:high?9999:1829,seed:d.seed,dna:d}}});
    const p = live(ctx)[0].profile;
    assert.equal(p.name.length,32); assert.equal(p.year,high?9999:1829); assert.deepEqual(p.dna,d);
  }
});

test('profile limits count UTF-8 bytes before stripping arbitrary extras', async () => {
  const ctx = await room();
  for (const ignored of ['x'.repeat(4096),'😀'.repeat(1100)]) {
    const before = JSON.stringify(raw(ctx));
    const result = await join(ctx, 'Oversize', {profile:{ignored}}, 413);
    assert.equal(result.code,'profile_too_large'); assert.equal(JSON.stringify(raw(ctx)),before);
  }
  const accepted = await join(ctx, 'Small extra', {profile:{ignored:'<svg>untrusted but discarded</svg>'}});
  assert.ok(!Object.hasOwn(accepted.view.roster.find(p=>p.id===accepted.client.id).profile,'ignored'));
});

test('generated and legacy profiles are stable across recipients, snapshots and new hands', async () => {
  const ctx = await room({maxSeats:3,body:{name:'',profile:{seed:4294967295,year:2026}}});
  assert.equal(live(ctx)[0].name,'Player FFFFFFFF'); assert.equal(live(ctx)[0].profile.seed,4294967295);
  const observer = (await join(ctx,'Watcher',{spectator:true})).client;
  await start(ctx);
  const first = (await poll(ctx)).view.roster.map(p=>({id:p.id,profile:p.profile}));
  assert.ok(first.every(p=>!Object.hasOwn(p.profile,'dna')));
  const again = (await poll(ctx,observer)).view.roster.map(p=>({id:p.id,profile:p.profile})); assert.deepEqual(again,first);
  await finish(ctx,{fold:true}); await start(ctx);
  assert.deepEqual((await poll(ctx,observer)).view.roster.map(p=>({id:p.id,profile:p.profile})),first);
  delete raw(ctx).members.find(m=>m.id===host(ctx).id).profile;
  const legacy = (await poll(ctx)).view.roster.find(p=>p.id===host(ctx).id).profile;
  ctx.now += 1000;
  assert.deepEqual((await poll(ctx,observer)).view.roster.find(p=>p.id===host(ctx).id).profile,legacy);
  assert.ok(Number.isInteger(legacy.seed) && legacy.seed>=0 && legacy.seed<=4294967295);
});

test('queued and replacement profiles do not replace the old bot identity or private hand', async () => {
  const ctx = await room({maxSeats:2}); await start(ctx);
  const bot = (await poll(ctx)).view.table.seats.find(p=>p.bot);
  const guest = (await join(ctx,'New Character',{profile:{age:18,year:9999,seed:42,dna:dna()}})).client;
  await ready(ctx,guest);
  const waiting = (await poll(ctx,guest)).view;
  assert.deepEqual(waiting.table.seats.find(p=>p.id===bot.id).profile,bot.profile);
  assert.equal(waiting.roster.find(p=>p.id===guest.id).profile.seed,42);
  assert.ok(!waiting.table.seats.some(p=>p.id===guest.id));
  await finish(ctx,{fold:true}); await poll(ctx,guest); await start(ctx);
  const entered = (await poll(ctx,guest)).view;
  assert.equal(entered.table.seats[0].id,guest.id); assert.equal(entered.table.seats[0].profile.seed,42);
  assert.ok(!entered.table.seats.some(p=>p.id===bot.id));
});
