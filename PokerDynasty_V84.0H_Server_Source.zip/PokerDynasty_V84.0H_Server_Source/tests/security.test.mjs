import test from 'node:test';
import assert from 'node:assert/strict';
import { handle } from '../mp-engine/rooms.mjs';
import { VARIANTS } from '../mp-engine/cards.mjs';

class MemoryStore {
  rooms = new Map();
  conflicts = 0;
  barrier = null;
  collideNextLoads(count) {
    let release;
    const waiting = new Promise(resolve => { release = resolve; });
    this.barrier = { remaining: count, waiting, release };
  }
  async load(code) {
    const value = this.rooms.has(code) ? structuredClone(this.rooms.get(code)) : null;
    // A deterministic D1-style concurrency barrier makes the selected requests
    // read the same committed revision before any can attempt its CAS write.
    const barrier = this.barrier;
    if (barrier) {
      if (--barrier.remaining === 0) { this.barrier = null; barrier.release(); }
      else await barrier.waiting;
    }
    return value;
  }
  async create(room) { if (this.rooms.has(room.code)) return false; this.rooms.set(room.code, structuredClone(room)); return true; }
  async cas(room, revision) {
    const existing = this.rooms.get(room.code);
    if (!existing || existing.revision !== revision) { this.conflicts++; return false; }
    this.rooms.set(room.code, structuredClone(room));
    return true;
  }
  async rate() { return true; }
  async prune() {}
}

let sequence = 0;
const rid = () => 'request_' + String(++sequence).padStart(8, '0');
const request = async (ctx, path, body, token) => {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = 'Bearer ' + token;
  const response = await handle(new Request('https://poker.test' + path, { method: 'POST', headers, body: JSON.stringify(body) }), ctx.store, () => ctx.now);
  return { status: response.status, data: await response.json() };
};
async function room(options = {}) {
  const n = options.n || 2, variant = options.variant || 'holdem_nl';
  const ctx = { store: new MemoryStore(), now: 1_000_000_000, clients: [], watchers: [], code: null };
  const settings = { variant, maxSeats: n, sb: 1, bb: 2, ante: VARIANTS[variant].family === 'stud' || VARIANTS[variant].anteOnly ? 1 : 0, buyin: 200, turnSeconds: 180, allowCheats: !!options.openCards, ...options.settings };
  const created = await request(ctx, '/api/create', { name: 'Player 0', settings });
  assert.equal(created.status, 201, JSON.stringify(created.data));
  ctx.code = created.data.roomCode;
  ctx.clients.push({ id: created.data.playerId, token: created.data.token, name: 'Player 0' });
  const joins = await Promise.all(Array.from({ length: n - 1 }, (_, i) => request(ctx, '/api/join', { roomCode: ctx.code, name: 'Player ' + (i + 1) })));
  joins.forEach((joined, i) => {
    assert.equal(joined.status, 200, JSON.stringify(joined.data));
    ctx.clients.push({ id: joined.data.playerId, token: joined.data.token, name: 'Player ' + (i + 1) });
  });
  return ctx;
}
const raw = ctx => ctx.store.rooms.get(ctx.code);
const command = (ctx, client, body) => request(ctx, '/api/room/' + ctx.code, { requestId: rid(), ...body }, client.token);
const poll = (ctx, client = ctx.clients[0]) => command(ctx, client, { type: 'poll' });
async function watcher(ctx, name = 'Observer') {
  const joined = await request(ctx, '/api/join', { roomCode: ctx.code, name, spectator: true });
  assert.equal(joined.status, 200, JSON.stringify(joined.data));
  const client = { id: joined.data.playerId, token: joined.data.token, name };
  ctx.watchers.push(client); return client;
}
async function begin(ctx) {
  const ready = await Promise.all(ctx.clients.map(c => command(ctx, c, { type: 'ready', ready: true })));
  for (const answer of ready) assert.equal(answer.status, 200, JSON.stringify(answer.data));
  const started = await command(ctx, ctx.clients[0], { type: 'start' });
  assert.equal(started.status, 200, JSON.stringify(started.data));
  return started;
}
async function actCurrent(ctx, policy = 'passive') {
  const g = raw(ctx).game;
  const client = ctx.clients.find(c => c.id === g.seats[g.actor]?.id);
  assert.ok(client, 'Current actor must own a human test client');
  const view = (await poll(ctx, client)).data.view;
  const actions = view.table.legal;
  const choice = actions.find(a => a.type === 'draw' || a.type === 'discard')
    || (policy === 'fold' ? actions.find(a => a.type === 'fold') : null)
    || actions.find(a => a.type === 'check') || actions.find(a => a.type === 'call') || actions[0];
  const action = { type: choice.type };
  if (choice.type === 'draw') action.indices = [];
  if (choice.type === 'discard') action.indices = [0];
  if (choice.type === 'raise') action.target = choice.minTo;
  const response = await command(ctx, client, { type: 'action', turnId: view.table.turnId, action });
  assert.equal(response.status, 200, JSON.stringify(response.data));
  return response;
}
async function finish(ctx, policy = 'passive') {
  let guard = 0;
  while (raw(ctx).game.phase !== 'complete') {
    assert.ok(++guard < 150, 'Hand should terminate');
    await actCurrent(ctx, policy);
  }
}

function assertPrivate(ctx, payload, viewerId, open = false) {
  const g = raw(ctx).game, allowed = new Set(g.board.map(c => c.text));
  for (const p of g.seats) p.hole.forEach((c, i) => {
    if (p.id === viewerId || open || p.up[i] || (g.settlement?.showdown && p.inHand && !p.folded)) allowed.add(c.text);
  });
  const hidden = [...g.deck, ...g.discards, ...g.burned, ...g.seats.flatMap(p => p.hole)].filter(c => !allowed.has(c.text));
  const text = JSON.stringify(payload);
  for (const c of hidden) assert.ok(!text.includes(c.text), 'Hidden card text leaked: ' + c.text);
  for (const m of raw(ctx).members) if (m.tokenHash) assert.ok(!text.includes(m.tokenHash), 'Bearer digest leaked');
  const forbidden = new Set(['deck', 'discards', 'burned', 'hole', 'tokenHash', 'handEpoch', 'startStacks']);
  const walk = value => {
    if (value && typeof value === 'object') {
      if ('rank' in value && 'suit' in value) assert.ok(allowed.has(value.rank + value.suit), 'Hidden card object leaked');
      for (const [key, next] of Object.entries(value)) { assert.ok(!forbidden.has(key), 'Internal custody field leaked: ' + key); walk(next); }
    }
  };
  walk(payload);
}

test('all 25 variants: HTTP JSON exposes own private cards and public upcards only', async () => {
  for (const variant of Object.keys(VARIANTS)) {
    const ctx = await room({ variant });
    const observer = await watcher(ctx);
    await begin(ctx);
    for (const client of [...ctx.clients, observer]) {
      const answer = await poll(ctx, client);
      assert.equal(answer.status, 200);
      assertPrivate(ctx, answer.data, client.id);
      const view = answer.data.view.table;
      assert.equal(view.settings.allowCheats, false);
      assert.equal(view.youSeat, client === observer ? -1 : 0);
      assert.equal(view.seats.filter(p => p.cards.some(Boolean)).length,
        VARIANTS[variant].family === 'stud' ? 2 : client === observer ? 0 : 1);
    }
  }
});

test('HTTP privacy survives draw/discard/stud streets, folded pots and completed showdown', async () => {
  for (const variant of ['holdem_nl', 'plo8', 'crazy_pineapple', 'draw5', 'deuce_triple', 'badugi', 'stud7', 'stud7_hilo', 'razz']) {
    const ctx = await room({ n: 3, variant }), observer = await watcher(ctx);
    await begin(ctx);
    let guard = 0;
    while (raw(ctx).game.phase !== 'complete') {
      assert.ok(++guard < 100);
      for (const client of [...ctx.clients, observer]) assertPrivate(ctx, (await poll(ctx, client)).data, client.id);
      await actCurrent(ctx);
    }
    for (const client of [...ctx.clients, observer]) assertPrivate(ctx, (await poll(ctx, client)).data, client.id);
    assert.equal(raw(ctx).game.settlement.showdown, true);
  }
  const folded = await room({ n: 3 }), observer = await watcher(folded);
  await begin(folded); await finish(folded, 'fold');
  const view = (await poll(folded, observer)).data;
  assert.equal(raw(folded).game.settlement.showdown, false);
  assertPrivate(folded, view, observer.id);
  assert.ok(view.view.table.seats.every(s => s.cards.every(c => c === null)));
});

test('bearer ownership rejects impersonation, spectators and out-of-turn actions atomically', async () => {
  const ctx = await room({ n: 3 }), observer = await watcher(ctx);
  await begin(ctx);
  const g = raw(ctx).game, actor = ctx.clients.find(c => c.id === g.seats[g.actor].id), nonactor = ctx.clients.find(c => c !== actor);
  const turn = (await poll(ctx, actor)).data.view.table.turnId;
  const before = JSON.stringify(raw(ctx));
  const forged = await command(ctx, nonactor, { type: 'action', turnId: turn, playerId: actor.id, seat: g.actor, action: { type: 'call', seat: g.actor, playerId: actor.id } });
  assert.equal(forged.status, 409); assert.equal(forged.data.code, 'not_your_turn');
  assert.equal(JSON.stringify(raw(ctx)), before);
  const watched = await command(ctx, observer, { type: 'action', turnId: turn, action: { type: 'call' } });
  assert.equal(watched.status, 403); assert.equal(watched.data.code, 'spectator');
  const invalidBearer = await request(ctx, '/api/room/' + ctx.code, { type: 'poll' }, '0'.repeat(64));
  assert.equal(invalidBearer.status, 401);
  const missingBearer = await request(ctx, '/api/room/' + ctx.code, { type: 'poll' });
  assert.equal(missingBearer.status, 401);
  assert.equal(JSON.stringify(raw(ctx)), before);
});

test('duplicates are idempotent; stale turn/hand payloads and illegal wagers preserve custody', async () => {
  const ctx = await room({ n: 3 }); await begin(ctx);
  const g = raw(ctx).game, actor = ctx.clients.find(c => c.id === g.seats[g.actor].id);
  const table = (await poll(ctx, actor)).data.view.table, turnId = table.turnId;
  const raise = table.legal.find(a => a.type === 'raise'); assert.ok(raise);
  for (const target of [-1, 1.5, '100', null, 9_007_199_254_740_992, raise.maxTo + 1]) {
    const before = JSON.stringify(raw(ctx));
    const result = await command(ctx, actor, { type: 'action', turnId, action: { type: 'raise', target, deck: ['As'], chips: 10000000 } });
    assert.equal(result.status, 400); assert.equal(JSON.stringify(raw(ctx)), before);
  }
  const body = { type: 'action', requestId: rid(), turnId, action: { type: 'raise', target: raise.minTo } };
  const accepted = await command(ctx, actor, body); assert.equal(accepted.status, 200);
  const once = JSON.stringify(raw(ctx));
  const duplicate = await command(ctx, actor, body); assert.equal(duplicate.status, 200); assert.equal(duplicate.data.duplicate, true);
  assert.equal(JSON.stringify(raw(ctx)), once);
  const stale = await command(ctx, actor, { ...body, requestId: rid() });
  assert.equal(stale.status, 409); assert.equal(stale.data.code, 'stale_turn');
  assert.equal(JSON.stringify(raw(ctx)), once);
  await finish(ctx);
  const next = await command(ctx, ctx.clients[0], { type: 'next' }); assert.equal(next.status, 200);
  const oldHand = await command(ctx, actor, { ...body, requestId: rid() });
  assert.equal(oldHand.status, 409); assert.equal(oldHand.data.code, 'stale_turn');
});

test('host-only settings, readiness and immutable per-hand open-card consent', async () => {
  const ctx = await room({ n: 3 }), observer = await watcher(ctx);
  const unauthorized = await command(ctx, ctx.clients[1], { type: 'settings', settings: { allowCheats: true } });
  assert.equal(unauthorized.status, 403); assert.equal(raw(ctx).settings.allowCheats, false);
  await begin(ctx);
  const state = JSON.stringify(raw(ctx));
  for (const body of [{ type: 'settings', settings: { allowCheats: true } }, { type: 'addBot' }, { type: 'kick', playerId: ctx.clients[1].id }]) {
    const midhand = await command(ctx, ctx.clients[0], body);
    assert.equal(midhand.status, 409); assert.equal(midhand.data.code, 'hand_active');
    assert.equal(JSON.stringify(raw(ctx)), state);
  }
  await finish(ctx, 'fold');
  const open = await command(ctx, ctx.clients[0], { type: 'settings', settings: { allowCheats: true } });
  assert.equal(open.status, 200);
  assert.ok(raw(ctx).members.filter(m => !m.spectator).every(m => !m.ready));
  const oldHand = await poll(ctx, observer);
  assertPrivate(ctx, oldHand.data, observer.id);
  assert.ok(oldHand.data.view.table.seats.every(p => p.cards.every(c => c === null)), 'Enabling open cards must not unmask a previously fair hand');
  const tooEarly = await command(ctx, ctx.clients[0], { type: 'next' });
  assert.equal(tooEarly.status, 400);
  await begin(ctx);
  const exposed = (await poll(ctx, observer)).data;
  assertPrivate(ctx, exposed, observer.id, true);
  assert.ok(exposed.view.table.seats.every(p => p.cards.every(Boolean)));
  await finish(ctx, 'fold');
  const closed = await command(ctx, ctx.clients[0], { type: 'settings', settings: { allowCheats: false } }); assert.equal(closed.status, 200);
  await begin(ctx);
  const fairAgain = (await poll(ctx, observer)).data;
  assertPrivate(ctx, fairAgain, observer.id);
  assert.ok(fairAgain.view.table.seats.every(p => p.cards.every(c => c === null)));
});

test('2-, 6-, and 9-client CAS collisions retain exactly one action and a full roster', async () => {
  for (const n of [2, 6, 9]) {
    const ctx = await room({ n });
    assert.equal(raw(ctx).members.length, n);
    assert.equal(new Set(raw(ctx).members.map(m => m.id)).size, n);
    assert.equal(new Set(raw(ctx).members.map(m => m.seat)).size, n);
    ctx.store.collideNextLoads(n);
    await begin(ctx);
    assert.ok(ctx.store.conflicts > 0, 'Parallel clients should exercise actual CAS retry paths');
    const g = raw(ctx).game, actor = ctx.clients.find(c => c.id === g.seats[g.actor].id), view = (await poll(ctx, actor)).data.view;
    const type = view.table.legal.some(a => a.type === 'call') ? 'call' : 'check';
    const message = { type: 'action', turnId: view.table.turnId, requestId: rid(), action: { type } };
    const actionCount = g.events.filter(e => e.type === 'action').length;
    ctx.store.collideNextLoads(n + 3);
    const results = await Promise.all([
      command(ctx, actor, message), command(ctx, actor, message), command(ctx, actor, message),
      ...ctx.clients.map(c => poll(ctx, c)),
    ]);
    for (const answer of results) assert.equal(answer.status, 200, JSON.stringify(answer.data));
    assert.equal(raw(ctx).game.events.filter(e => e.type === 'action').length, actionCount + 1);
    const game = raw(ctx).game;
    assert.equal(game.seats.reduce((s, p) => s + p.stack, 0) + game.pot, n * 200);
    for (const c of ctx.clients) assertPrivate(ctx, (await poll(ctx, c)).data, c.id);
  }
});

test('future deck/burns stay private even with explicitly agreed open cards', async () => {
  const ctx = await room({ n: 6, openCards: true }), observer = await watcher(ctx);
  await begin(ctx);
  for (let k = 0; k < 8 && raw(ctx).game.phase !== 'complete'; k++) {
    for (const c of [...ctx.clients, observer]) assertPrivate(ctx, (await poll(ctx, c)).data, c.id, true);
    await actCurrent(ctx);
  }
});
