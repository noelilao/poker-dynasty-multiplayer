
import C from '../mp-engine/life842-core.cjs';
import {handleHome,homeTick,homeViews,assertHomeGame} from '../mp-engine/life842-homegames.mjs';
export const minute=s=>Math.floor(Date.parse(s)/60000);
export function fixture(start='2026-01-31T12:00:00Z',balance=50000000){
 let w={worldUuid:'test-world',worldCode:'TESTCODE',revision:0,seed:'test',settings:{startingCity:'vegas'},clock:{minute:minute(start),paused:false},players:['a','b','c'].map(id=>({playerUuid:id,name:'Player '+id,status:'active',character:{bound:true},wallet:{balanceCents:balance,ledger:[]},location:{city:'vegas'},lastSeen:1000000,sessionHash:'test'})),tournaments:{}};
 let seq=0,real=1000000;
 const cities={vegas:{id:'vegas',name:'Las Vegas',country:'US',start:'1905-05-15',lifeCost:1},manila:{id:'manila',name:'Manila',country:'PH',start:'1829-01-01',lifeCost:1},tokyo:{id:'tokyo',name:'Tokyo',country:'JP',start:'1829-01-01',lifeCost:1}};
 const change=(p,cents,kind,ref)=>{if(p.wallet.ledger.some(x=>x.ref===ref))throw Error('duplicate financial receipt '+ref);p.wallet.balanceCents+=cents;if(!Number.isSafeInteger(p.wallet.balanceCents)||p.wallet.balanceCents<0)throw Error('invalid wallet');p.wallet.ledger.push({cents,kind,ref});};
 const ctx={cities,nativeTitles:[],get now(){return real},connected:(p,at)=>!!p&&!p.away&&at-p.lastSeen<60000,debit:(w,p,n,k,r)=>change(p,-Math.round(n*100),k,r),credit:(w,p,n,k,r)=>change(p,Math.round(n*100),k,r)};
 C.seed(w);for(const p of w.players)C.person(w,p.playerUuid);
 const run=(who,action,args={},home=false)=>{const next=C.cp(w),p=next.players.find(x=>x.playerUuid===who),res=(home?handleHome:C.handle)(next,p,{action,requestId:'op'+(++seq),...args},ctx);next.revision++;C.validate(next);w=next;return res;};
 return {get w(){return w},ctx,get now(){return real},run,home:(who,a,b)=>run(who,a,b,true),p:id=>w.players.find(x=>x.playerUuid===id),q:id=>C.person(w,id),balance:id=>w.players.find(x=>x.playerUuid===id).wallet.balanceCents,
  advanceTo(m){const next=C.cp(w);next.clock.minute=m;C.tick(next,ctx);for(const p of next.players)if(p.availability?.until<=m)p.availability=null;w=next;C.validate(w);},
  real(ms){real+=ms;return real},touch(...ids){for(const p of w.players)if(!ids.length||ids.includes(p.playerUuid))p.lastSeen=real;},
  homeTick(){const next=C.cp(w);homeTick(next,real,ctx);w=next;},
  setBalance(id,n){this.p(id).wallet.balanceCents=n;},tick(){C.tick(w,ctx);},view(id){return C.projection(w,this.p(id),ctx)},
  buy(id='a',type='cottage',args={}){return run(id,'buy',{propertyId:this.p(id).location.city+'~'+type,propertyVersion:0,...args}).propertyId},
  offer(owner='a',tenant='b',propertyId='vegas~cottage',terms={}){return run(owner,'offer',{propertyId,unit:1,targetPlayerUuid:tenant,rent:200,deposit:400,months:3,allowSublet:true,roommates:2,...terms}).offer;},
  lease(owner='a',tenant='b',propertyId='vegas~cottage',terms={}){const o=this.offer(owner,tenant,propertyId,terms);run(tenant,'accept',{offerId:o.id});return Object.values(w.life842.leases).at(-1);},
  item(who,kind){return run(who,'buy_furniture',{kind}).itemId},
  deliver(){this.advanceTo(w.clock.minute+C.DAY*2);},
  place(who,itemId,propertyId,room='Living',x=0,y=0,rotation=0){return run(who,'place',{itemId,propertyId,unit:1,room,x,y,rotation});},
  homeViews(id){return homeViews(w,this.p(id),real,ctx);}
 };
}
export {C,handleHome,homeTick,homeViews,assertHomeGame};
