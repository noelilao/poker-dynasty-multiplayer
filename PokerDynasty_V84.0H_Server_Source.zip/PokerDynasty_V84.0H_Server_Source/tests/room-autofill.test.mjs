import test from 'node:test';
import assert from 'node:assert/strict';
import { room, raw, live, host, command, poll, ready, join, start, finish, assertCustody, assertPrivacy } from './room-fixture.mjs';

test('one ready human starts a full AI table by default; duplicate starts never add chips or bots', async () => {
  const ctx = await room({ maxSeats: 9 });
  assert.equal(raw(ctx).settings.autoFillBots, true);
  const body = { type: 'start', requestId: 'autofill_same_start' };
  ctx.store.collideNextLoads(4);
  const answers = await Promise.all(Array.from({ length: 4 }, () => command(ctx, host(ctx), body)));
  assert.equal(answers.filter(a => !a.duplicate).length, 1);
  assert.equal(raw(ctx).game.seats.length, 9); assert.equal(live(ctx).filter(m => m.bot).length, 8);
  assert.equal(raw(ctx).game.bankTotal, 1800); assert.equal(raw(ctx).game.handNo, 1);
  const state = JSON.stringify(raw(ctx));
  await command(ctx, host(ctx), body); assert.equal(JSON.stringify(raw(ctx)), state);
});

test('auto-fill is host-controlled, strictly boolean, and does not bypass seated-human readiness', async () => {
  const ctx = await room({ maxSeats: 4, settings: { autoFillBots: false } });
  await command(ctx, host(ctx), { type: 'start' }, 400);
  const guest = (await join(ctx, 'Guest')).client;
  await command(ctx, guest, { type: 'settings', settings: { autoFillBots: true } }, 403);
  await command(ctx, host(ctx), { type: 'settings', settings: { autoFillBots: 'true' } }, 400);
  await command(ctx, host(ctx), { type: 'settings', settings: { autoFillBots: true } });
  await ready(ctx); await command(ctx, host(ctx), { type: 'start' }, 400);
  assert.equal(live(ctx).filter(m => m.bot).length, 0, 'Rejected starts commit no bot funding');
  await ready(ctx, guest); await start(ctx); assert.equal(raw(ctx).game.seats.length, 4);
});

test('a between-hand human replaces a bot with a fresh ID and buy-in, never the old private hand', async () => {
  const ctx = await room({ maxSeats: 2 }); await start(ctx); await finish(ctx, { fold: true });
  const oldGame = JSON.stringify(raw(ctx).game), oldBot = raw(ctx).game.seats.find(p => p.bot);
  const joined = await join(ctx, 'Replacement'), guest = joined.client;
  assert.equal(joined.view.youWaiting, false); assert.equal(joined.view.table.youSeat, -1);
  assert.equal(joined.view.table.canAct, false); assert.equal(joined.view.roster.find(p => p.id === guest.id).stack, 200);
  assert.notEqual(guest.id, oldBot.id); assert.equal(JSON.stringify(raw(ctx).game), oldGame);
  assert.ok(joined.view.table.seats.every(p => p.cards.every(c => c === null)));
  await command(ctx, guest, { type: 'action', turnId: joined.view.table.turnId, action: { type: 'fold' } }, 409);
  await command(ctx, host(ctx), { type: 'next' }, 400);
  await ready(ctx, guest); await start(ctx);
  assert.ok(raw(ctx).game.seats.some(p => p.id === guest.id)); assert.ok(!raw(ctx).game.seats.some(p => p.id === oldBot.id));
  assert.equal(raw(ctx).game.startStacks.find((_, i) => raw(ctx).game.seats[i].id === guest.id), 200);
  const own = await poll(ctx, guest); assert.equal(own.view.table.seats[0].id, guest.id);
  assert.ok(own.view.table.seats[0].cards.every(Boolean));
});

test('queued humans ready during active hands and replace AI only in the next hand', async () => {
  const ctx = await room({ maxSeats: 3 }); await start(ctx);
  const oldIds = raw(ctx).game.seats.map(p => p.id), oldCards = JSON.stringify(raw(ctx).game.seats.map(p => p.hole));
  const joined = await join(ctx, 'Waiting'), guest = joined.client;
  assert.equal(joined.view.youWaiting, true); assert.equal(joined.view.youSeat, -1);
  await ready(ctx, guest);
  const before = JSON.stringify(raw(ctx));
  await command(ctx, guest, { type: 'action', turnId: joined.view.table.turnId, action: { type: 'call' } }, 409);
  assert.equal(JSON.stringify(raw(ctx)), before);
  assert.deepEqual(raw(ctx).game.seats.map(p => p.id), oldIds);
  assert.equal(JSON.stringify(raw(ctx).game.seats.map(p => p.hole)), oldCards);
  await finish(ctx); await poll(ctx, guest); await start(ctx);
  const view = (await poll(ctx, guest)).view;
  assert.equal(view.youWaiting, false); assert.equal(view.table.seats[0].id, guest.id);
  assert.equal(raw(ctx).game.startStacks[raw(ctx).game.seats.findIndex(p => p.id === guest.id)], 200);
});

test('unready and disconnected waiters remain queued; they do not block the current table', async () => {
  const ctx = await room({ maxSeats: 3 }); await start(ctx);
  const guest = (await join(ctx, 'Not Ready')).client;
  await finish(ctx); await start(ctx);
  assert.equal(live(ctx).find(m => m.id === guest.id).waiting, true);
  await ready(ctx, guest); await finish(ctx);
  ctx.now += 46_000; await poll(ctx); await start(ctx);
  assert.equal(live(ctx).find(m => m.id === guest.id).waiting, true);
  await poll(ctx, guest); await finish(ctx); await poll(ctx, guest); await start(ctx);
  assert.equal(live(ctx).find(m => m.id === guest.id).waiting, false);
});

test('rule changes reset queued consent and cannot expose a previous fair hand', async () => {
  const ctx = await room({ maxSeats: 2 }); await start(ctx);
  const guest = (await join(ctx, 'Waiting')).client; await ready(ctx, guest); await finish(ctx, { fold: true });
  await command(ctx, host(ctx), { type: 'settings', settings: { allowCheats: true } });
  assert.equal(live(ctx).find(m => m.id === guest.id).ready, false);
  const old = await poll(ctx, guest); assertPrivacy(ctx, old, guest);
  assert.ok(old.view.table.seats.every(p => p.cards.every(c => c === null)));
  await ready(ctx); await start(ctx);
  assert.equal(live(ctx).find(m => m.id === guest.id).waiting, true);
  assert.equal(raw(ctx).game.settings.allowCheats, true);
  await ready(ctx, guest); await finish(ctx, { fold: true }); await poll(ctx, guest); await start(ctx);
  assert.equal(live(ctx).find(m => m.id === guest.id).waiting, false);
  const open = await poll(ctx, guest); assert.ok(open.view.table.seats.every(p => p.cards.every(Boolean)));
});

test('simultaneous between-hand bot replacements reserve each human exactly one seat', async () => {
  for (const n of [2, 6, 9]) {
    const ctx = await room({ maxSeats: n }); await start(ctx); await finish(ctx, { fold: true });
    const oldGame = JSON.stringify(raw(ctx).game);
    ctx.store.collideNextLoads(n - 1);
    const joined = await Promise.all(Array.from({ length: n - 1 }, (_, i) => join(ctx, 'Replacement ' + i)));
    assert.equal(JSON.stringify(raw(ctx).game), oldGame);
    assert.equal(live(ctx).filter(m => m.bot).length, 0);
    assert.equal(live(ctx).filter(m => !m.bot).length, n);
    await join(ctx, 'Overflow', {}, 409);
    for (const answer of joined) await ready(ctx, answer.client);
    await poll(ctx); await start(ctx);
    assert.equal(raw(ctx).game.seats.filter(p => !p.bot).length, n); assertCustody(ctx);
  }
});

test('concurrent queued joins, leaves and replacement joins cannot overbook or mutate active ownership', async () => {
  const ctx = await room({ maxSeats: 9 }); await start(ctx);
  const oldIds = raw(ctx).game.seats.map(p => p.id), oldBank = raw(ctx).game.bankTotal;
  ctx.store.collideNextLoads(8);
  const first = await Promise.all(Array.from({ length: 8 }, (_, i) => join(ctx, 'Queued ' + i)));
  assert.equal(live(ctx).filter(m => m.waiting).length, 8);
  ctx.store.collideNextLoads(8);
  const leaves = first.slice(0, 4).map(({ client }) => command(ctx, client, { type: 'leave' }));
  const newcomers = Array.from({ length: 4 }, (_, i) => join(ctx, 'New Queue ' + i, {}, null));
  const results = await Promise.all([...leaves, ...newcomers]);
  for (let i = 0; i < 4; i++) if (results[i + 4].status !== 200) {
    assert.equal(results[i + 4].status, 409); await join(ctx, 'New Queue ' + i);
  }
  assert.deepEqual(raw(ctx).game.seats.map(p => p.id), oldIds); assert.equal(raw(ctx).game.bankTotal, oldBank);
  assert.equal(live(ctx).filter(m => m.waiting).length, 8);
  const active = ctx.clients.filter(c => live(ctx).some(m => m.id === c.id && m.waiting));
  ctx.store.collideNextLoads(active.length);
  await Promise.all(active.map(c => ready(ctx, c)));
  await finish(ctx); for (const c of active) await poll(ctx, c); await start(ctx);
  assert.equal(live(ctx).filter(m => m.waiting).length, 0);
  assert.equal(raw(ctx).game.seats.filter(p => !p.bot).length, 9);
});

test('a queued human can inherit hosting, ready safely and enter after the old host leaves', async () => {
  const ctx = await room({ maxSeats: 3 }); await start(ctx);
  const oldHost = host(ctx), guest = (await join(ctx, 'Next Host')).client;
  await command(ctx, oldHost, { type: 'leave' }); assert.equal(host(ctx).id, guest.id);
  await ready(ctx, guest); await finish(ctx); await start(ctx);
  assert.equal(live(ctx).find(m => m.id === guest.id).waiting, false);
  assert.ok(raw(ctx).game.seats.some(p => p.id === guest.id));
});

test('AI rebuys respect room rules and create a new hand bankroll without changing the old hand', async () => {
  for (const allowRebuys of [true, false]) {
    const ctx = await room({ maxSeats: 2, settings: { allowRebuys } }); await start(ctx); await finish(ctx, { fold: true });
    const r = raw(ctx), bot = r.members.find(m => m.bot), human = r.members.find(m => !m.bot);
    human.stack += bot.stack; bot.stack = 0;
    for (const p of r.game.seats) p.stack = r.members.find(m => m.id === p.id).stack;
    const old = JSON.stringify(r.game), bank = r.game.bankTotal;
    if (allowRebuys) {
      await start(ctx); assert.equal(raw(ctx).game.bankTotal, bank + 200);
      assert.ok(raw(ctx).chat.some(e => e.text.includes('(AI) rebought 200')));
    } else {
      await command(ctx, host(ctx), { type: 'next' }, 400);
      assert.equal(JSON.stringify(raw(ctx).game), old); assert.equal(raw(ctx).members.find(m => m.bot).stack, 0);
    }
  }
});

test('human rebuy is idempotent next-hand funding and preserves the completed hand ledger', async () => {
  const ctx = await room({ maxSeats:2 }); await start(ctx); await finish(ctx,{fold:true});
  const owner = host(ctx), member = live(ctx).find(m=>m.id===owner.id);
  assert.ok(member.stack < 200, 'Folding the heads-up small blind leaves room for a rebuy');
  const before = JSON.stringify(raw(ctx).game), oldBank = raw(ctx).game.bankTotal, amount = 200-member.stack;
  const body = {type:'rebuy',requestId:'rebuy_funding_once'};
  await command(ctx,owner,body); await command(ctx,owner,body);
  assert.equal(live(ctx).find(m=>m.id===owner.id).stack,200);
  assert.equal(JSON.stringify(raw(ctx).game),before);
  await start(ctx); assert.equal(raw(ctx).game.bankTotal,oldBank+amount);
});

test('smaller seat limits trim bots and preserve reserved-human capacity and readiness', async () => {
  const ctx = await room({ maxSeats: 9 }); await start(ctx); await finish(ctx, { fold: true });
  await command(ctx, host(ctx), { type: 'settings', settings: { variant: 'early20', maxSeats: 4 } });
  assert.equal(live(ctx).filter(m => !m.spectator && !m.waiting).length, 4);
  assert.equal(live(ctx).find(m => m.id === host(ctx).id).ready, false);
  await ready(ctx); await start(ctx); assert.equal(raw(ctx).game.seats.length, 4);
  const queued = await Promise.all([join(ctx, 'One'), join(ctx, 'Two'), join(ctx, 'Three')]);
  await finish(ctx, { fold: true });
  await command(ctx, host(ctx), { type: 'settings', settings: { maxSeats: 2 } }, 400);
  assert.equal(live(ctx).filter(m => m.waiting).length, queued.length);
});
